export interface Influencer {
  id: number;
  displayName: string;
  handle: string;
  avatar: string;
  niche: string;
  followers: string;
  avgViewers: string;
  location: string;
  verified: boolean;
  platforms: string[];
}

export const MOCK_INFLUENCERS: Influencer[] = [
  {
    id: 1,
    displayName: 'Alex Rivera',
    handle: '@alexstreamstv',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop&crop=face',
    niche: 'Electronics & tech',
    followers: '128K',
    avgViewers: '2.4K live',
    location: 'Los Angeles, CA',
    verified: true,
    platforms: ['eBay Live', 'YouTube'],
  },
  {
    id: 2,
    displayName: 'Jordan Lee',
    handle: '@jordanthrifts',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&crop=face',
    niche: 'Fashion & resale',
    followers: '89K',
    avgViewers: '1.8K live',
    location: 'Chicago, IL',
    verified: true,
    platforms: ['Whatnot', 'eBay Live'],
  },
  {
    id: 3,
    displayName: 'Sam Okonkwo',
    handle: '@samcollects',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&crop=face',
    niche: 'Collectibles & cards',
    followers: '210K',
    avgViewers: '5.1K live',
    location: 'Houston, TX',
    verified: true,
    platforms: ['Whatnot'],
  },
  {
    id: 4,
    displayName: 'Riley Chen',
    handle: '@rileyhomefinds',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&fit=crop&crop=face',
    niche: 'Home & decor',
    followers: '54K',
    avgViewers: '920 live',
    location: 'Seattle, WA',
    verified: false,
    platforms: ['eBay Live'],
  },
  {
    id: 5,
    displayName: 'Taylor Brooks',
    handle: '@taylorfitlive',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop&crop=face',
    niche: 'Sports & fitness',
    followers: '176K',
    avgViewers: '3.2K live',
    location: 'Miami, FL',
    verified: true,
    platforms: ['eBay Live', 'Instagram Live'],
  },
  {
    id: 6,
    displayName: 'Casey Morgan',
    handle: '@caseyvintage',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&h=120&fit=crop&crop=face',
    niche: 'Vintage & antiques',
    followers: '67K',
    avgViewers: '1.1K live',
    location: 'Portland, OR',
    verified: true,
    platforms: ['Whatnot'],
  },
  {
    id: 7,
    displayName: 'Morgan Patel',
    handle: '@mogamingdeals',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=120&h=120&fit=crop&crop=face',
    niche: 'Gaming & consoles',
    followers: '302K',
    avgViewers: '8.4K live',
    location: 'Austin, TX',
    verified: true,
    platforms: ['YouTube', 'Whatnot'],
  },
  {
    id: 8,
    displayName: 'Jamie Foster',
    handle: '@jamiekitchenstreams',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop&crop=face',
    niche: 'Kitchen & small appliances',
    followers: '41K',
    avgViewers: '640 live',
    location: 'Denver, CO',
    verified: false,
    platforms: ['eBay Live'],
  },
];

export function getInfluencerById(id: number): Influencer | undefined {
  return MOCK_INFLUENCERS.find((i) => i.id === id);
}
