import { useMemo, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Bell, CalendarPlus, Check, Clock } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { useSellerWorkspace } from './SellerWorkspaceContext';
import { MOCK_INFLUENCERS } from './sellerInfluencerDirectory';

export function SellerRemindersPage() {
  const { reminders, completeReminder, snoozeReminder, addReminder } = useSellerWorkspace();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [influencerId, setInfluencerId] = useState(MOCK_INFLUENCERS[0]?.id ?? 1);
  const [dueDate, setDueDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState('');

  const todayStr = new Date().toISOString().slice(0, 10);

  const sorted = useMemo(() => {
    const open = reminders.filter((r) => !r.completed);
    const done = reminders.filter((r) => r.completed);
    open.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    done.sort((a, b) => b.dueDate.localeCompare(a.dueDate));
    return [...open, ...done];
  }, [reminders]);

  const submitReminder = () => {
    const inf = MOCK_INFLUENCERS.find((i) => i.id === influencerId);
    if (!inf || !note.trim()) return;
    addReminder({
      influencerId: inf.id,
      displayName: inf.displayName,
      handle: inf.handle,
      dueDate,
      note: note.trim(),
    });
    setNote('');
    setDialogOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <Link
        to="/seller"
        className="inline-flex items-center gap-2 text-emerald-800 hover:underline text-sm font-medium mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to workspace
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Follow-up reminders</h2>
          <p className="text-gray-600 max-w-2xl">
            Never lose track of DMs, calls, or contract nudges. Snooze or complete tasks as you go (mock data, in-memory
            only).
          </p>
        </div>
        <button
          type="button"
          onClick={() => setDialogOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 shrink-0"
        >
          <CalendarPlus className="w-4 h-4" />
          Add reminder
        </button>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm divide-y divide-gray-100 dark:divide-gray-800">
        {sorted.length === 0 ? (
          <p className="p-10 text-center text-gray-500 text-sm">No reminders yet.</p>
        ) : (
          sorted.map((r) => {
            const overdue = !r.completed && r.dueDate < todayStr;
            return (
              <div
                key={r.id}
                className={`p-5 flex flex-col sm:flex-row sm:items-center gap-4 ${
                  r.completed ? 'opacity-60 bg-gray-50/50' : ''
                }`}
              >
                <div
                  className={`w-1 shrink-0 rounded-full self-stretch min-h-[48px] ${
                    r.completed ? 'bg-gray-300' : overdue ? 'bg-red-500' : 'bg-violet-500'
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold text-gray-900">{r.displayName}</p>
                    <span className="text-sm text-emerald-700">{r.handle}</span>
                    {r.completed && (
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-gray-200 text-gray-700 font-medium">
                        Done
                      </span>
                    )}
                    {!r.completed && overdue && (
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-medium">
                        Overdue
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-gray-400" />
                    Due {r.dueDate}
                  </p>
                  <p className="text-sm text-gray-700 mt-2">{r.note}</p>
                </div>
                {!r.completed && (
                  <div className="flex flex-wrap gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => completeReminder(r.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
                    >
                      <Check className="w-4 h-4" />
                      Complete
                    </button>
                    <button
                      type="button"
                      onClick={() => snoozeReminder(r.id, 3)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                      Snooze 3 days
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <div className="mt-8 bg-violet-50 border border-violet-100 rounded-xl p-5 flex gap-3">
        <Bell className="w-5 h-5 text-violet-700 shrink-0 mt-0.5" />
        <p className="text-sm text-violet-950/90">
          <strong className="font-semibold">Why reminders matter:</strong> creators often need a gentle nudge after
          viewing an invite. Pair a reminder with a status update on the Invites page so your team stays aligned.
        </p>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md bg-white text-gray-900 border-gray-200">
          <DialogHeader>
            <DialogTitle>Add follow-up reminder</DialogTitle>
            <DialogDescription className="text-gray-600">
              Pick a creator from the directory and when you want to be nudged.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Creator</label>
              <select
                value={influencerId}
                onChange={(e) => setInfluencerId(Number(e.target.value))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
              >
                {MOCK_INFLUENCERS.map((inf) => (
                  <option key={inf.id} value={inf.id}>
                    {inf.displayName} {inf.handle}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Due date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="What do you need to do?"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 resize-none"
              />
            </div>
          </div>
          <DialogFooter>
            <button
              type="button"
              onClick={() => setDialogOpen(false)}
              className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!note.trim()}
              onClick={submitReminder}
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 disabled:opacity-50"
            >
              Save reminder
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
