import type { CollabRoomState } from './CollabRoomTypes';
import { getCollabSeedForRfls } from './collabRoomMockData';

export const COLLAB_ROOM_STORAGE_KEY = 'ic-collab-room-v1';

type StoredMap = Record<string, CollabRoomState>;

function readMap(): StoredMap {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(COLLAB_ROOM_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as StoredMap;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeMap(map: StoredMap) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(COLLAB_ROOM_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore quota
  }
}

/** Normalize route param: "00003", "3", "RFLS-00003" -> 3 */
export function parseRflsIdParam(param: string | undefined): number | null {
  if (param == null || param === '') return null;
  const trimmed = param.trim();
  const withoutPrefix = trimmed.replace(/^RFLS-/i, '');
  const n = Number.parseInt(withoutPrefix, 10);
  if (!Number.isFinite(n)) return null;
  return n;
}

export function loadCollabRoom(rflsId: number): CollabRoomState {
  const map = readMap();
  const key = String(rflsId);
  const stored = map[key];
  if (stored && stored.rflsId === rflsId) {
    return stored;
  }
  return getCollabSeedForRfls(rflsId);
}

export function saveCollabRoom(state: CollabRoomState) {
  const map = readMap();
  map[String(state.rflsId)] = state;
  writeMap(map);
}
