import { useEffect, useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router';
import {
  Store,
  Search,
  LogOut,
  User,
  LayoutDashboard,
  Send,
  Heart,
  Bell,
  MessageSquare,
  Menu,
  X,
} from 'lucide-react';
import { SellerWorkspaceProvider, useSellerWorkspace } from './SellerWorkspaceContext';
import { AppFooter } from './AppFooter';
import { ThemeToggle } from './ThemeToggle';
import { SellerTierAccountHint, SellerTierBadge } from './SellerTierBadge';

function matchSellerNav(pathname: string, to: string, end?: boolean) {
  if (end) return pathname === to || pathname === `${to}/`;
  return pathname === to || pathname.startsWith(`${to}/`);
}

function SellerHeaderChrome() {
  const location = useLocation();
  const navigate = useNavigate();
  const pathname = location.pathname;
  const [showMenu, setShowMenu] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { overdueReminderCount } = useSellerWorkspace();

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const handleSignOut = () => {
    navigate('/seller/signin');
  };

  const nav = [
    { to: '/seller', label: 'Workspace', fullLabel: 'Workspace', icon: LayoutDashboard, end: true },
    { to: '/seller/find-influencers', label: 'Find', fullLabel: 'Find influencers', icon: Search, end: false },
    { to: '/seller/invites', label: 'Invites', fullLabel: 'Invites sent', icon: Send, end: false },
    { to: '/seller/favorites', label: 'Saved', fullLabel: 'Favorites', icon: Heart, end: false },
    {
      to: '/seller/reminders',
      label: 'Reminders',
      fullLabel: 'Reminders',
      icon: Bell,
      end: false,
      badge: overdueReminderCount > 0 ? overdueReminderCount : undefined,
    },
    {
      to: '/seller/negotiations',
      label: 'Pay talks',
      fullLabel: 'Payment negotiations',
      icon: MessageSquare,
      end: false,
    },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-emerald-200/50 dark:border-emerald-900/50 bg-white/80 dark:bg-gray-950/85 backdrop-blur-xl shadow-[0_1px_0_rgba(6,78,59,0.08)] dark:shadow-[0_1px_0_rgba(0,0,0,0.4)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex h-14 sm:h-16 items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <Link
              to="/seller"
              className="flex items-center gap-2.5 shrink-0 group"
              onClick={() => setMobileOpen(false)}
            >
              <div className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-white/25 transition-transform group-hover:scale-[1.02]">
                <Store className="w-4 h-4 sm:w-[18px] sm:h-[18px]" strokeWidth={2} />
              </div>
              <div className="flex flex-col leading-none min-w-0">
                <span className="font-semibold text-gray-900 dark:text-gray-100 tracking-tight text-sm sm:text-base truncate">
                  ConnectIn
                </span>
                <div className="flex items-center gap-2 flex-wrap mt-0.5">
                  <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.12em] text-emerald-600/80 font-semibold">
                    Seller portal
                  </span>
                  <SellerTierBadge />
                </div>
              </div>
            </Link>

            <nav className="hidden lg:flex flex-1 justify-center px-2 min-w-0">
              <div className="inline-flex max-w-full overflow-x-auto [scrollbar-width:thin] items-center gap-0.5 rounded-full bg-emerald-50/90 dark:bg-emerald-950/50 p-1 ring-1 ring-emerald-200/70 dark:ring-emerald-800/80 shadow-inner">
                {nav.map((item) => {
                  const Icon = item.icon;
                  const active = matchSellerNav(pathname, item.to, item.end);
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      title={item.label}
                      className={`relative flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium transition-all duration-200 whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-white dark:bg-gray-900 text-emerald-800 dark:text-emerald-200 shadow-sm ring-1 ring-emerald-200/90 dark:ring-emerald-800'
                          : 'text-emerald-900/70 dark:text-emerald-200/80 hover:text-emerald-950 dark:hover:text-emerald-100 hover:bg-white/70 dark:hover:bg-emerald-900/50'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0 opacity-90" />
                      <span>{item.label}</span>
                      {item.badge != null && (
                        <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </nav>

            <div className="lg:hidden ml-auto flex items-center gap-2 shrink-0">
              <ThemeToggle />
              <button
                type="button"
                aria-expanded={mobileOpen}
                aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
                onClick={() => setMobileOpen((o) => !o)}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-200/80 dark:border-emerald-800 bg-emerald-50/80 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-200 hover:bg-emerald-100/80 dark:hover:bg-emerald-900/60 transition-colors"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-2 shrink-0">
            <ThemeToggle />
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowMenu(!showMenu)}
                className={`flex items-center gap-2 rounded-full border border-gray-200/80 dark:border-gray-700 bg-white dark:bg-gray-900 py-1.5 pl-1.5 pr-3 shadow-sm transition-colors ${
                  showMenu ? 'ring-2 ring-emerald-200 dark:ring-emerald-800' : 'hover:border-emerald-200 dark:hover:border-emerald-800'
                }`}
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-700 to-teal-800 text-white text-xs font-bold shadow-sm">
                  SG
                </div>
                <span className="text-sm font-medium text-gray-800 dark:text-gray-200 max-w-[120px] truncate">Sports Gear Pro</span>
              </button>
              {showMenu && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl border border-gray-200/80 dark:border-gray-700 bg-white dark:bg-gray-900 py-2 text-gray-800 dark:text-gray-200 shadow-xl shadow-gray-200/50 dark:shadow-black/40 z-50">
                  <div className="px-4 py-2.5 border-b border-gray-100 dark:border-gray-800 space-y-2">
                    <p className="text-xs text-gray-500 dark:text-gray-400">Signed in as seller</p>
                    <SellerTierAccountHint />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      handleSignOut();
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {mobileOpen && (
          <div className="lg:hidden border-t border-emerald-100/80 dark:border-emerald-900/50 py-3">
            <div className="flex flex-col gap-1 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 p-2 ring-1 ring-emerald-200/60 dark:ring-emerald-900/60">
              {nav.map((item) => {
                const Icon = item.icon;
                const active = matchSellerNav(pathname, item.to, item.end);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={`flex items-center justify-between gap-2 rounded-xl px-3 py-3 text-sm font-medium transition-colors ${
                      active
                        ? 'bg-white dark:bg-gray-900 text-emerald-900 dark:text-emerald-100 shadow-sm ring-1 ring-emerald-200 dark:ring-emerald-800'
                        : 'text-emerald-900/80 dark:text-emerald-200/90 hover:bg-white/80 dark:hover:bg-emerald-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-5 h-5 shrink-0 opacity-90" />
                      {item.fullLabel}
                    </span>
                    {item.badge != null && (
                      <span className="min-w-[22px] h-[22px] px-1.5 rounded-full bg-rose-500 text-white text-[11px] font-bold flex items-center justify-center">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                handleSignOut();
              }}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-gray-900 py-3 text-sm font-medium text-rose-600 dark:text-rose-400 shadow-sm"
            >
              <LogOut className="w-4 h-4" />
              Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

export function SellerLayout() {
  return (
    <SellerWorkspaceProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-gray-950">
        <SellerHeaderChrome />
        <main className="flex-1 overflow-auto dark:bg-gray-950">
          <Outlet />
        </main>
        <AppFooter variant="seller" />
      </div>
    </SellerWorkspaceProvider>
  );
}
