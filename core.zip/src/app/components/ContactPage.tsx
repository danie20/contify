import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Mail, Send, CheckCircle, Headphones } from 'lucide-react';

export function ContactPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  return (
    <div className="max-w-2xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-primary)] hover:underline mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to dashboard
      </Link>

      <div className="flex items-center gap-3 mb-2">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300">
          <Mail className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 tracking-tight">Contact</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Reach the ConnectIn team (demo — nothing is sent)</p>
        </div>
      </div>

      <p className="text-gray-600 dark:text-gray-400 mt-4 mb-6">
        Questions about RFLS, negotiations, or your account? Fill out the form below. In this prototype, submit only
        shows a confirmation — no email is delivered.
      </p>
      <p className="text-sm text-gray-600 dark:text-gray-400 mb-8">
        <Link
          to="/support"
          className="inline-flex items-center gap-1.5 font-medium text-[var(--color-primary)] hover:underline"
        >
          <Headphones className="w-4 h-4 shrink-0" />
          Browse FAQs on Support first — many answers are already there.
        </Link>
      </p>

      {sent ? (
        <div className="rounded-2xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50 dark:bg-emerald-950/40 p-8 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 mb-4">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-semibold text-emerald-950 dark:text-emerald-100 mb-2">Message recorded (mock)</h2>
          <p className="text-sm text-emerald-900/90 dark:text-emerald-200/90 mb-6 max-w-md mx-auto">
            Thanks, {form.name || 'there'}. In a real app we would email you a copy and route this to support.
          </p>
          <button
            type="button"
            onClick={() => {
              setSent(false);
              setForm({ name: '', email: '', subject: '', message: '' });
            }}
            className="text-sm font-medium text-[var(--color-primary)] hover:underline"
          >
            Send another message
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 sm:p-8 shadow-sm space-y-5">
          <div>
            <label htmlFor="contact-name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Name
            </label>
            <input
              id="contact-name"
              name="name"
              required
              value={form.name}
              onChange={handleChange}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-3 py-2.5 text-sm bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30"
              placeholder="Your name"
            />
          </div>
          <div>
            <label htmlFor="contact-email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Email
            </label>
            <input
              id="contact-email"
              name="email"
              type="email"
              required
              value={form.email}
              onChange={handleChange}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-3 py-2.5 text-sm bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="contact-subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Topic
            </label>
            <select
              id="contact-subject"
              name="subject"
              required
              value={form.subject}
              onChange={handleChange}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30 bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100"
            >
              <option value="">Choose a topic</option>
              <option value="rfls">RFLS &amp; applications</option>
              <option value="payments">Payments & negotiations</option>
              <option value="account">Account & login</option>
              <option value="technical">Technical issue</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label htmlFor="contact-message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Message
            </label>
            <textarea
              id="contact-message"
              name="message"
              required
              rows={5}
              value={form.message}
              onChange={handleChange}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-3 py-2.5 text-sm bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30 resize-y min-h-[120px]"
              placeholder="Describe your question or issue…"
            />
          </div>
          <button
            type="submit"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--color-primary)] text-white px-6 py-3 text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Send className="w-4 h-4" />
            Send message
          </button>
        </form>
      )}

      <div className="mt-10 pt-8 border-t border-gray-200 dark:border-gray-800">
        <p className="text-xs text-gray-500 dark:text-gray-500 uppercase tracking-wide font-semibold mb-3">Demo contact (not functional)</p>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          <strong className="text-gray-800 dark:text-gray-200">support@connectin.demo</strong>
          <br />
          Mon–Fri, 9am–6pm PT — placeholder for mockups and stakeholder reviews.
        </p>
      </div>
    </div>
  );
}
