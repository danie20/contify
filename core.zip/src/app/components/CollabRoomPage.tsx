import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router';
import {
  ArrowLeft,
  CalendarClock,
  CheckSquare,
  Film,
  FolderOpen,
  LayoutGrid,
  MessageCircle,
  Plus,
  Send,
  Sparkles,
} from 'lucide-react';
import type { CollabChatMessage, CollabRoomState, CollabParticipant } from './CollabRoomTypes';
import { loadCollabRoom, parseRflsIdParam, saveCollabRoom } from './CollabRoomStorage';

type TabId = 'checklist' | 'run' | 'assets' | 'deadlines' | 'chat';

function newId() {
  return `x-${Math.random().toString(36).slice(2, 11)}`;
}

export function CollabRoomPage() {
  const { rflsId: rflsParam } = useParams<{ rflsId: string }>();
  const location = useLocation();
  const isSeller = location.pathname.startsWith('/seller/');

  const rflsId = useMemo(() => parseRflsIdParam(rflsParam), [rflsParam]);

  const [tab, setTab] = useState<TabId>('checklist');
  const [room, setRoom] = useState<CollabRoomState | null>(null);
  const [chatDraft, setChatDraft] = useState('');

  useEffect(() => {
    if (rflsId == null) {
      setRoom(null);
      return;
    }
    setRoom(loadCollabRoom(rflsId));
  }, [rflsId]);

  const persist = useCallback((next: CollabRoomState) => {
    setRoom(next);
    saveCollabRoom(next);
  }, []);

  const selfSender: CollabParticipant = isSeller ? 'seller' : 'influencer';
  const selfLabel = isSeller ? room?.sellerName ?? 'Seller' : room?.influencerName ?? 'Creator';

  const handleSendChat = () => {
    if (!room || !chatDraft.trim()) return;
    const msg: CollabChatMessage = {
      id: newId(),
      sender: selfSender,
      authorLabel: selfLabel,
      content: chatDraft.trim(),
      createdAt: new Date().toISOString(),
    };
    persist({ ...room, chat: [...room.chat, msg] });
    setChatDraft('');
  };

  const rflsLabel =
    rflsId != null ? `RFLS-${String(rflsId).padStart(5, '0')}` : 'RFLS';

  const backTo = isSeller ? '/seller' : '/application-status';
  const ringClass = isSeller ? 'ring-emerald-500/30' : 'ring-[var(--color-primary)]/30';

  if (rflsId == null) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <p className="text-gray-600 dark:text-gray-400">Invalid RFLS id in URL.</p>
        <Link to={backTo} className="mt-4 inline-flex text-sm font-medium text-emerald-700 hover:underline">
          ← Back
        </Link>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <p className="text-gray-500">Loading…</p>
      </div>
    );
  }

  const tabs: { id: TabId; label: string; icon: typeof CheckSquare }[] = [
    { id: 'checklist', label: 'Checklist', icon: CheckSquare },
    { id: 'run', label: 'Run of show', icon: Film },
    { id: 'assets', label: 'Assets & links', icon: FolderOpen },
    { id: 'deadlines', label: 'Deadlines', icon: CalendarClock },
    { id: 'chat', label: 'Chat', icon: MessageCircle },
  ];

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 pb-24">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Link
            to={backTo}
            className={`inline-flex items-center gap-1.5 text-sm font-medium mb-3 ${
              isSeller ? 'text-emerald-700 hover:text-emerald-800' : 'text-[var(--color-primary)] hover:opacity-90'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            {isSeller ? 'Seller workspace' : 'RFLS status'}
          </Link>
          <div className="flex flex-wrap items-center gap-2 gap-y-1">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">Live Collab Room</h1>
            <span
              className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold tabular-nums ring-1 ${ringClass} bg-white/80 dark:bg-gray-900/80`}
            >
              {rflsLabel}
            </span>
            {room.platform && (
              <span className="text-xs text-gray-500 dark:text-gray-400">{room.platform}</span>
            )}
          </div>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 max-w-2xl">
            Shared workspace for this deal — checklist, run-of-show, assets, deadlines, and chat. Edits save in this
            browser (demo).
          </p>
          <div className="mt-3 flex flex-wrap gap-2 text-sm">
            <span className="inline-flex items-center gap-1 rounded-lg bg-gray-100 dark:bg-gray-800 px-2.5 py-1">
              <span className="text-gray-500">Seller</span>
              <span className="font-medium text-gray-900 dark:text-gray-100">{room.sellerName}</span>
            </span>
            <span className="inline-flex items-center gap-1 rounded-lg bg-gray-100 dark:bg-gray-800 px-2.5 py-1">
              <span className="text-gray-500">Creator</span>
              <span className="font-medium text-gray-900 dark:text-gray-100">{room.influencerName}</span>
            </span>
          </div>
        </div>
        <div
          className={`rounded-2xl border px-4 py-3 text-xs sm:text-sm shrink-0 ${
            isSeller
              ? 'border-emerald-200 bg-emerald-50/90 text-emerald-950 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-100'
              : 'border-blue-200 bg-blue-50/90 text-blue-950 dark:border-blue-900 dark:bg-blue-950/35 dark:text-blue-100'
          }`}
        >
          <div className="flex items-center gap-2 font-semibold">
            <Sparkles className="w-4 h-4 shrink-0" />
            {isSeller ? 'Seller view' : 'Creator view'}
          </div>
          <p className="mt-1 opacity-90">
            Chat messages post as <strong>{selfLabel}</strong>. Open the other portal to simulate the other side.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-200 dark:border-gray-800 pb-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition-colors ${
                active
                  ? isSeller
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-[var(--color-primary)] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-4 h-4 opacity-90" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'checklist' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <CheckSquare className="w-5 h-5 opacity-80" />
              Pre-live checklist
            </h2>
            <button
              type="button"
              onClick={() => {
                const label = window.prompt('New checklist item');
                if (!label?.trim()) return;
                persist({
                  ...room,
                  checklist: [...room.checklist, { id: newId(), label: label.trim(), done: false }],
                });
              }}
              className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-medium text-white ${
                isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[var(--color-primary)] hover:opacity-95'
              }`}
            >
              <Plus className="w-4 h-4" />
              Add item
            </button>
          </div>
          <ul className="space-y-2">
            {room.checklist.map((item) => (
              <li
                key={item.id}
                className="flex items-start gap-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-4 py-3"
              >
                <input
                  type="checkbox"
                  checked={item.done}
                  onChange={() => {
                    persist({
                      ...room,
                      checklist: room.checklist.map((c) =>
                        c.id === item.id ? { ...c, done: !c.done } : c,
                      ),
                    });
                  }}
                  className="mt-1 h-4 w-4 rounded border-gray-300"
                />
                <span className={`flex-1 text-sm ${item.done ? 'line-through text-gray-400' : ''}`}>
                  {item.label}
                </span>
                <button
                  type="button"
                  className="text-xs text-red-600 hover:underline"
                  onClick={() =>
                    persist({
                      ...room,
                      checklist: room.checklist.filter((c) => c.id !== item.id),
                    })
                  }
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === 'run' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Film className="w-5 h-5 opacity-80" />
              Run of show
            </h2>
            <button
              type="button"
              onClick={() =>
                persist({
                  ...room,
                  runOfShow: [
                    ...room.runOfShow,
                    { id: newId(), startTime: '', segment: 'New segment', notes: '' },
                  ],
                })
              }
              className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-medium text-white ${
                isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[var(--color-primary)] hover:opacity-95'
              }`}
            >
              <Plus className="w-4 h-4" />
              Add row
            </button>
          </div>
          <div className="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800/80 text-left text-xs uppercase tracking-wide text-gray-500">
                <tr>
                  <th className="px-3 py-2 font-medium">Time</th>
                  <th className="px-3 py-2 font-medium">Segment</th>
                  <th className="px-3 py-2 font-medium">Notes</th>
                  <th className="px-3 py-2 w-16" />
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {room.runOfShow.map((row) => (
                  <tr key={row.id} className="bg-white dark:bg-gray-900">
                    <td className="px-3 py-2 align-top">
                      <input
                        value={row.startTime}
                        onChange={(e) =>
                          persist({
                            ...room,
                            runOfShow: room.runOfShow.map((r) =>
                              r.id === row.id ? { ...r, startTime: e.target.value } : r,
                            ),
                          })
                        }
                        className="w-full min-w-[4rem] rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1"
                        placeholder="0:00"
                      />
                    </td>
                    <td className="px-3 py-2 align-top">
                      <input
                        value={row.segment}
                        onChange={(e) =>
                          persist({
                            ...room,
                            runOfShow: room.runOfShow.map((r) =>
                              r.id === row.id ? { ...r, segment: e.target.value } : r,
                            ),
                          })
                        }
                        className="w-full rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1"
                      />
                    </td>
                    <td className="px-3 py-2 align-top">
                      <input
                        value={row.notes}
                        onChange={(e) =>
                          persist({
                            ...room,
                            runOfShow: room.runOfShow.map((r) =>
                              r.id === row.id ? { ...r, notes: e.target.value } : r,
                            ),
                          })
                        }
                        className="w-full rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1"
                      />
                    </td>
                    <td className="px-3 py-2 align-top">
                      <button
                        type="button"
                        className="text-xs text-red-600 hover:underline"
                        onClick={() =>
                          persist({
                            ...room,
                            runOfShow: room.runOfShow.filter((r) => r.id !== row.id),
                          })
                        }
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'assets' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <FolderOpen className="w-5 h-5 opacity-80" />
              Assets & links
            </h2>
            <button
              type="button"
              onClick={() =>
                persist({
                  ...room,
                  assets: [...room.assets, { id: newId(), name: 'New asset', url: 'https://' }],
                })
              }
              className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-medium text-white ${
                isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[var(--color-primary)] hover:opacity-95'
              }`}
            >
              <Plus className="w-4 h-4" />
              Add link
            </button>
          </div>
          <ul className="space-y-3">
            {room.assets.length === 0 && (
              <li className="text-sm text-gray-500">No assets yet — add links to briefs, sheets, or folders.</li>
            )}
            {room.assets.map((a) => (
              <li
                key={a.id}
                className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-4 py-3"
              >
                <input
                  value={a.name}
                  onChange={(e) =>
                    persist({
                      ...room,
                      assets: room.assets.map((x) =>
                        x.id === a.id ? { ...x, name: e.target.value } : x,
                      ),
                    })
                  }
                  className="flex-1 rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1 text-sm font-medium"
                />
                <input
                  value={a.url}
                  onChange={(e) =>
                    persist({
                      ...room,
                      assets: room.assets.map((x) =>
                        x.id === a.id ? { ...x, url: e.target.value } : x,
                      ),
                    })
                  }
                  className="flex-[2] rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1 text-sm text-[var(--color-primary)]"
                  placeholder="https://"
                />
                <button
                  type="button"
                  className="text-xs text-red-600 hover:underline shrink-0"
                  onClick={() =>
                    persist({
                      ...room,
                      assets: room.assets.filter((x) => x.id !== a.id),
                    })
                  }
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === 'deadlines' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <CalendarClock className="w-5 h-5 opacity-80" />
              Deadlines
            </h2>
            <button
              type="button"
              onClick={() =>
                persist({
                  ...room,
                  deadlines: [
                    ...room.deadlines,
                    {
                      id: newId(),
                      label: 'New milestone',
                      dueDate: new Date().toISOString().slice(0, 10),
                      done: false,
                    },
                  ],
                })
              }
              className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-medium text-white ${
                isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[var(--color-primary)] hover:opacity-95'
              }`}
            >
              <Plus className="w-4 h-4" />
              Add deadline
            </button>
          </div>
          <ul className="space-y-2">
            {room.deadlines.map((d) => (
              <li
                key={d.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-4 py-3"
              >
                <input
                  type="checkbox"
                  checked={d.done}
                  onChange={() =>
                    persist({
                      ...room,
                      deadlines: room.deadlines.map((x) =>
                        x.id === d.id ? { ...x, done: !x.done } : x,
                      ),
                    })
                  }
                  className="h-4 w-4 rounded border-gray-300"
                />
                <input
                  value={d.label}
                  onChange={(e) =>
                    persist({
                      ...room,
                      deadlines: room.deadlines.map((x) =>
                        x.id === d.id ? { ...x, label: e.target.value } : x,
                      ),
                    })
                  }
                  className="flex-1 min-w-[8rem] rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1 text-sm"
                />
                <input
                  type="date"
                  value={d.dueDate}
                  onChange={(e) =>
                    persist({
                      ...room,
                      deadlines: room.deadlines.map((x) =>
                        x.id === d.id ? { ...x, dueDate: e.target.value } : x,
                      ),
                    })
                  }
                  className="rounded border border-gray-200 dark:border-gray-700 bg-transparent px-2 py-1 text-sm"
                />
                <button
                  type="button"
                  className="text-xs text-red-600 hover:underline"
                  onClick={() =>
                    persist({
                      ...room,
                      deadlines: room.deadlines.filter((x) => x.id !== d.id),
                    })
                  }
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === 'chat' && (
        <section className="flex flex-col gap-4 min-h-[420px]">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <MessageCircle className="w-5 h-5 opacity-80" />
            Deal chat
          </h2>
          <div className="flex-1 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50/80 dark:bg-gray-900/50 p-4 space-y-3 max-h-[340px] overflow-y-auto">
            {room.chat.map((m) => {
              const isSelf =
                (m.sender === 'influencer' && !isSeller) || (m.sender === 'seller' && isSeller);
              const isSys = m.sender === 'system';
              return (
                <div
                  key={m.id}
                  className={`flex flex-col gap-0.5 ${isSelf ? 'items-end' : 'items-start'} ${
                    isSys ? 'items-center' : ''
                  }`}
                >
                  <div
                    className={`max-w-[92%] rounded-2xl px-3 py-2 text-sm ${
                      isSys
                        ? 'bg-gray-200/90 dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-center text-xs'
                        : isSelf
                          ? isSeller
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[var(--color-primary)] text-white'
                          : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {!isSys && (
                      <p className="text-[10px] font-semibold uppercase tracking-wide opacity-80 mb-1">
                        {m.authorLabel}
                      </p>
                    )}
                    <p className="whitespace-pre-wrap">{m.content}</p>
                    <p className={`text-[10px] mt-1 opacity-70 ${isSys ? '' : ''}`}>
                      {new Date(m.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <textarea
              value={chatDraft}
              onChange={(e) => setChatDraft(e.target.value)}
              rows={2}
              placeholder="Message the other party…"
              className="flex-1 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 px-3 py-2 text-sm"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendChat();
                }
              }}
            />
            <button
              type="button"
              onClick={handleSendChat}
              className={`inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2 text-sm font-semibold text-white shrink-0 ${
                isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[var(--color-primary)] hover:opacity-95'
              }`}
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </div>
        </section>
      )}

      <div className="mt-10 flex items-center gap-2 text-xs text-gray-500">
        <LayoutGrid className="w-3.5 h-3.5" />
        Collab room id <code className="rounded bg-gray-100 dark:bg-gray-800 px-1">{rflsLabel}</code> — stored under{' '}
        <code className="rounded bg-gray-100 dark:bg-gray-800 px-1">localStorage</code>
      </div>
    </div>
  );
}
