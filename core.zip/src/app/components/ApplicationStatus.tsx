import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import {
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  Video,
  Mail,
  FileText,
  Calendar,
  TrendingUp,
  MessageSquare,
  Ban,
  LayoutGrid,
} from 'lucide-react';
import { SellerTierPill } from './SellerTierBadge';
import { mockSellerTierForDisplay } from './sellerTierMock';

interface Application {
  id: number;
  sellerName: string;
  sellerAvatar: string;
  platform: string;
  status: 'submitted' | 'in-review' | 'need-info' | 'approved' | 'rejected' | 'withdrawn';
  submittedDate: string;
  lastUpdated: string;
  proposedRate: number;
  timeline: TimelineEvent[];
  rejectionReason?: string;
  requestedInfo?: string;
  hasNegotiation?: boolean;
}

interface TimelineEvent {
  stage: string;
  status: 'completed' | 'in-progress' | 'pending';
  date?: string;
  duration: number;
  startDay: number;
}

const mockApplications: Application[] = [
  {
    id: 1,
    sellerName: 'Premium Electronics Store',
    sellerAvatar: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    status: 'in-review',
    submittedDate: '2026-05-01',
    lastUpdated: '2026-05-02',
    proposedRate: 200,
    hasNegotiation: true,
    timeline: [
      { stage: 'Submitted', status: 'completed', date: '2026-05-01', duration: 1, startDay: 0 },
      { stage: 'Initial Review', status: 'in-progress', date: '2026-05-02', duration: 3, startDay: 1 },
      { stage: 'Seller Review', status: 'pending', duration: 4, startDay: 4 },
      { stage: 'Final Decision', status: 'pending', duration: 2, startDay: 8 },
    ],
  },
  {
    id: 2,
    sellerName: 'Fashion Forward Boutique',
    sellerAvatar: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    status: 'need-info',
    submittedDate: '2026-04-28',
    lastUpdated: '2026-05-01',
    proposedRate: 175,
    hasNegotiation: true,
    requestedInfo: 'Please provide additional information about your previous fashion streaming experience and engagement metrics for fashion-related content.',
    timeline: [
      { stage: 'Submitted', status: 'completed', date: '2026-04-28', duration: 1, startDay: 0 },
      { stage: 'Initial Review', status: 'completed', date: '2026-04-29', duration: 2, startDay: 1 },
      { stage: 'Need Information', status: 'in-progress', date: '2026-05-01', duration: 5, startDay: 3 },
      { stage: 'Final Decision', status: 'pending', duration: 2, startDay: 8 },
    ],
  },
  {
    id: 3,
    sellerName: 'Sports Gear Pro',
    sellerAvatar: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    status: 'approved',
    submittedDate: '2026-04-20',
    lastUpdated: '2026-04-28',
    proposedRate: 225,
    timeline: [
      { stage: 'Submitted', status: 'completed', date: '2026-04-20', duration: 1, startDay: 0 },
      { stage: 'Initial Review', status: 'completed', date: '2026-04-21', duration: 2, startDay: 1 },
      { stage: 'Seller Review', status: 'completed', date: '2026-04-24', duration: 4, startDay: 3 },
      { stage: 'Approved', status: 'completed', date: '2026-04-28', duration: 1, startDay: 7 },
    ],
  },
  {
    id: 4,
    sellerName: 'Home Decor Haven',
    sellerAvatar: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    status: 'rejected',
    submittedDate: '2026-04-15',
    lastUpdated: '2026-04-22',
    proposedRate: 150,
    rejectionReason: 'Your audience demographic does not align with our target market. We focus on audiences aged 35-55, while your primary audience is 18-25. We encourage you to reapply if your audience demographics shift.',
    timeline: [
      { stage: 'Submitted', status: 'completed', date: '2026-04-15', duration: 1, startDay: 0 },
      { stage: 'Initial Review', status: 'completed', date: '2026-04-16', duration: 2, startDay: 1 },
      { stage: 'Seller Review', status: 'completed', date: '2026-04-19', duration: 3, startDay: 3 },
      { stage: 'Rejected', status: 'completed', date: '2026-04-22', duration: 1, startDay: 6 },
    ],
  },
];

export function ApplicationStatus() {
  const navigate = useNavigate();
  const [selectedApp, setSelectedApp] = useState<Application | null>(mockApplications[0]);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawReason, setWithdrawReason] = useState('');

  const handleWithdrawProposal = () => {
    setShowWithdrawModal(false);
    setWithdrawReason('');
    // Update application status to withdrawn
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted':
      case 'in-review':
        return <Clock className="w-5 h-5 text-blue-500" />;
      case 'need-info':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'withdrawn':
        return <Ban className="w-5 h-5 text-gray-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted':
      case 'in-review':
        return 'bg-blue-100 text-blue-800';
      case 'need-info':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'withdrawn':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'submitted':
        return 'Submitted';
      case 'in-review':
        return 'In Review';
      case 'need-info':
        return 'Need More Information';
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Not Approved';
      case 'withdrawn':
        return 'Withdrawn';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-6">
        <h2 className="text-2xl mb-2">RFLS status tracker</h2>
        <p className="text-gray-600">Monitor the progress of your RFLS submissions</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start gap-3">
          <MessageSquare className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="text-sm mb-1">RFLS & negotiation integration</h4>
            <p className="text-sm text-gray-700">
              Your negotiation actions (Accept, Counter Offer, Decline) automatically update your RFLS status.
              Accepting an offer moves the RFLS to "Approved" status, while declining updates it to "Not Approved".
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-3">My RFLS</h3>
          {mockApplications.map((app) => (
            <div
              key={app.id}
              onClick={() => setSelectedApp(app)}
              className={`bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-4 cursor-pointer transition-all ${
                selectedApp?.id === app.id
                  ? 'ring-2 ring-[var(--color-primary)]'
                  : 'hover:shadow-md'
              }`}
            >
              <div className="flex items-start gap-3 mb-3">
                <img
                  src={app.sellerAvatar}
                  alt={app.sellerName}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h4 className="text-sm truncate">{app.sellerName}</h4>
                    <SellerTierPill tier={mockSellerTierForDisplay(app.sellerName, app.id)} />
                  </div>
                  <span className={`text-xs px-2 py-1 rounded ${getStatusColor(app.status)}`}>
                    {getStatusLabel(app.status)}
                  </span>
                </div>
              </div>
              <div className="text-xs text-gray-500">
                <p>Submitted: {app.submittedDate}</p>
                <p>Updated: {app.lastUpdated}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-2">
          {selectedApp ? (
            <div className="space-y-6">
              <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedApp.sellerAvatar}
                      alt={selectedApp.sellerName}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h3 className="text-xl">{selectedApp.sellerName}</h3>
                        <SellerTierPill tier={mockSellerTierForDisplay(selectedApp.sellerName, selectedApp.id)} />
                      </div>
                      <p className="text-sm text-gray-600">{selectedApp.platform}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-2">
                      {getStatusIcon(selectedApp.status)}
                      <span className={`px-3 py-1 rounded text-sm ${getStatusColor(selectedApp.status)}`}>
                        {getStatusLabel(selectedApp.status)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">Proposed: ${selectedApp.proposedRate}/stream</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 dark:bg-gray-950 p-3 rounded border border-transparent dark:border-gray-800">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Submitted</div>
                    <div className="text-sm">{selectedApp.submittedDate}</div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-950 p-3 rounded border border-transparent dark:border-gray-800">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Last Updated</div>
                    <div className="text-sm">{selectedApp.lastUpdated}</div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-950 p-3 rounded border border-transparent dark:border-gray-800">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">RFLS ID</div>
                    <div className="text-sm">RFLS-{selectedApp.id.toString().padStart(5, '0')}</div>
                  </div>
                </div>

                {selectedApp.status === 'need-info' && selectedApp.requestedInfo && (
                  <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-2">Additional Information Requested</h4>
                        <p className="text-sm text-gray-700 mb-4">{selectedApp.requestedInfo}</p>
                        <div className="bg-white dark:bg-gray-950 border border-yellow-300 dark:border-yellow-700 rounded p-3 mb-4">
                          <p className="text-xs text-gray-600 mb-2">📎 You can provide this information through:</p>
                          <ul className="text-xs text-gray-700 space-y-1 list-disc list-inside">
                            <li>Negotiation chat (with file attachments)</li>
                            <li>Schedule a Zoom call for detailed discussion</li>
                            <li>Send via email with supporting documents</li>
                          </ul>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                          {selectedApp.hasNegotiation && (
                            <button
                              onClick={() => navigate('/negotiations')}
                              className="flex items-center gap-2 bg-[var(--color-primary)] text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm"
                            >
                              <MessageSquare className="w-4 h-4" />
                              Respond via Chat
                            </button>
                          )}
                          <button className="flex items-center gap-2 border-2 border-[var(--color-primary)] text-[var(--color-primary)] px-4 py-2 rounded hover:bg-blue-50 transition-colors text-sm">
                            <Video className="w-4 h-4" />
                            Schedule Zoom Call
                          </button>
                          <button className="flex items-center gap-2 border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 transition-colors text-sm">
                            <Mail className="w-4 h-4" />
                            Email Response
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {selectedApp.status === 'approved' && (
                  <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-2">Congratulations! Your RFLS has been approved</h4>
                        <p className="text-sm text-gray-700 mb-4">
                          The seller has accepted your live-streaming request. Next steps: Contract signing and campaign planning.
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <Link
                            to={`/collab/${selectedApp.id}`}
                            className="flex items-center gap-2 bg-violet-600 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm"
                          >
                            <LayoutGrid className="w-4 h-4" />
                            Open Collab Room
                          </Link>
                          <button className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm">
                            <FileText className="w-4 h-4" />
                            View Contract
                          </button>
                          <button className="flex items-center gap-2 bg-[var(--color-primary)] text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm">
                            <Calendar className="w-4 h-4" />
                            Schedule Kickoff
                          </button>
                          <button className="flex items-center gap-2 border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 transition-colors text-sm">
                            <MessageSquare className="w-4 h-4" />
                            Message Seller
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {selectedApp.status === 'rejected' && selectedApp.rejectionReason && (
                  <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <XCircle className="w-5 h-5 text-red-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-2">RFLS not approved</h4>
                        <p className="text-sm text-gray-700 mb-4">{selectedApp.rejectionReason}</p>
                        <div className="flex gap-2">
                          <button className="flex items-center gap-2 border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 transition-colors text-sm">
                            <Mail className="w-4 h-4" />
                            Request Feedback
                          </button>
                          <button className="flex items-center gap-2 bg-[var(--color-primary)] text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm">
                            <FileText className="w-4 h-4" />
                            Submit new RFLS
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {selectedApp.status === 'withdrawn' && (
                  <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <Ban className="w-5 h-5 text-gray-600 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-2">RFLS withdrawn</h4>
                        <p className="text-sm text-gray-700">
                          You have withdrawn this RFLS. The seller has been notified.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {selectedApp.hasNegotiation && (selectedApp.status === 'in-review' || selectedApp.status === 'need-info') && (
                  <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mb-6">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <MessageSquare className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm mb-2">Active Negotiation</h4>
                          <p className="text-sm text-gray-700">
                            You have an ongoing payment negotiation with this seller.
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => navigate('/negotiations')}
                        className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm whitespace-nowrap"
                      >
                        View Negotiation →
                      </button>
                    </div>
                  </div>
                )}

                {(selectedApp.status === 'submitted' || selectedApp.status === 'in-review' || selectedApp.status === 'need-info') && (
                  <div className="flex justify-end">
                    <button
                      onClick={() => setShowWithdrawModal(true)}
                      className="flex items-center gap-2 text-red-600 hover:text-red-700 text-sm"
                    >
                      <Ban className="w-4 h-4" />
                      Withdraw RFLS
                    </button>
                  </div>
                )}
              </div>

              <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6">
                <h3 className="text-lg mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Application Timeline
                </h3>

                <div className="mb-6">
                  <div className="flex items-center gap-4 mb-2">
                    <span className="text-sm text-gray-600">Progress</span>
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${
                          selectedApp.status === 'approved'
                            ? 'bg-green-500'
                            : selectedApp.status === 'rejected'
                            ? 'bg-red-500'
                            : 'bg-blue-500'
                        }`}
                        style={{
                          width: `${
                            (selectedApp.timeline.filter((t) => t.status === 'completed').length /
                              selectedApp.timeline.length) *
                            100
                          }%`,
                        }}
                      ></div>
                    </div>
                    <span className="text-sm">
                      {selectedApp.timeline.filter((t) => t.status === 'completed').length}/
                      {selectedApp.timeline.length}
                    </span>
                  </div>
                </div>

                <div className="space-y-1 mb-6">
                  {selectedApp.timeline.map((event, index) => (
                    <div key={index} className="relative">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-3 w-48">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              event.status === 'completed'
                                ? 'bg-green-500'
                                : event.status === 'in-progress'
                                ? 'bg-blue-500 animate-pulse'
                                : 'bg-gray-300'
                            }`}
                          ></div>
                          <span className="text-sm">{event.stage}</span>
                        </div>
                        <div className="flex-1 relative h-8 bg-gray-100 rounded">
                          <div
                            className={`absolute top-0 h-full rounded ${
                              event.status === 'completed'
                                ? 'bg-green-500'
                                : event.status === 'in-progress'
                                ? 'bg-blue-500'
                                : 'bg-gray-300'
                            }`}
                            style={{
                              left: `${(event.startDay / 10) * 100}%`,
                              width: `${(event.duration / 10) * 100}%`,
                            }}
                          >
                            {event.status === 'in-progress' && (
                              <div className="absolute inset-0 bg-blue-600 opacity-30 animate-pulse"></div>
                            )}
                          </div>
                        </div>
                        <div className="w-24 text-sm text-gray-600">
                          {event.date || `Day ${event.startDay + 1}-${event.startDay + event.duration}`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span>Completed</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span>In Progress</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
                        <span>Pending</span>
                      </div>
                    </div>
                    <div className="text-gray-500">
                      Est. completion: {
                        selectedApp.status === 'approved' || selectedApp.status === 'rejected'
                          ? 'Completed'
                          : '3-5 business days'
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-8 text-center text-gray-400">
              <FileText className="w-16 h-16 mx-auto mb-4" />
              <p>Select an RFLS to view details</p>
            </div>
          )}
        </div>
      </div>

      {showWithdrawModal && selectedApp && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow-xl max-w-md w-full p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Ban className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl">Withdraw RFLS</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Are you sure you want to withdraw your RFLS to {selectedApp.sellerName}? This action cannot be undone.
            </p>
            <div className="mb-6">
              <label className="block text-sm mb-2">Reason for Withdrawal (Optional)</label>
              <textarea
                value={withdrawReason}
                onChange={(e) => setWithdrawReason(e.target.value)}
                rows={3}
                placeholder="Let the seller know why you're withdrawing..."
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mb-6 flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-yellow-800">
                Withdrawing this RFLS will close any active negotiations and notify the seller immediately.
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowWithdrawModal(false);
                  setWithdrawReason('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleWithdrawProposal}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded hover:opacity-90"
              >
                Confirm Withdrawal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
