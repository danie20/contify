import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Lock, Mail, Eye, EyeOff, LogIn, Store } from 'lucide-react';
import { AppFooter } from './AppFooter';
import { SocialSignInButtons } from './SocialSignInButtons';
import { ThemeToggle } from './ThemeToggle';

export function SellerSignIn() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const done = localStorage.getItem('ic-seller-onboarding-complete') === 'true';
      navigate(done ? '/seller' : '/seller/onboarding');
    } catch {
      navigate('/seller/onboarding');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setFormData({ ...formData, [e.target.name]: value });
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-emerald-50/40 to-teal-50 dark:from-gray-950 dark:via-emerald-950/30 dark:to-gray-900 relative">
      <div className="absolute top-4 right-4 z-20 sm:top-6 sm:right-6">
        <ThemeToggle />
      </div>
      <div className="flex flex-1 items-center justify-center p-6 pt-16 sm:pt-6">
        <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-600 text-white mb-3 shadow-lg">
            <Store className="w-7 h-7" />
          </div>
          <h1 className="text-3xl text-[var(--color-primary)] mb-1">ConnectIn</h1>
          <p className="text-emerald-800/80 text-sm font-medium uppercase tracking-wide">Seller portal</p>
          <p className="text-gray-600 dark:text-gray-400 text-sm mt-2">Find creators and invite them to your live shows</p>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl p-8 border border-emerald-100/80 dark:border-emerald-900/50">
          <div className="text-center mb-6">
            <h2 className="text-2xl mb-2 dark:text-gray-100">Seller sign in</h2>
            <p className="text-gray-600 dark:text-gray-400 text-sm">Use your seller account to search and invite influencers</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm mb-2">Business email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="seller@yourstore.com"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600/40 focus:border-emerald-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600/40 focus:border-emerald-600"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleChange}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <span className="text-sm text-gray-600">Remember me</span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 text-white py-3 rounded-lg hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 font-medium"
            >
              <LogIn className="w-5 h-5" />
              Sign in to seller portal
            </button>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200 dark:border-gray-700" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400">
                  Or continue with
                </span>
              </div>
            </div>
            <SocialSignInButtons variant="seller" className="mt-4" />
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
            <p className="text-sm text-gray-600">
              Are you an influencer?{' '}
              <Link to="/signin" className="text-[var(--color-primary)] font-medium hover:underline">
                Influencer sign in
              </Link>
            </p>
          </div>
        </div>

        <p className="text-center text-xs text-gray-500 mt-6">
          Mock flow — any email and password will continue to the invite tools.
        </p>
        </div>
      </div>
      <AppFooter variant="seller" />
    </div>
  );
}
