import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';
import { Crown, Sparkles, Store, Users } from 'lucide-react';
import {
  getSellerTierBadgeDisplay,
  getStoredSellerMembership,
  type BusinessTier,
  type StoredSellerMembership,
} from './SellerOnboarding';

function formatUsd(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

const tierGlyph: Record<BusinessTier, typeof Users> = {
  consumer: Users,
  small: Store,
  mid: Sparkles,
  large: Crown,
};

/** Static tier pill for mock sellers in influencer flows (Discover, RFLS, negotiations, etc.). */
export function SellerTierPill({
  tier,
  className = '',
}: {
  tier: BusinessTier;
  className?: string;
}) {
  const { shortLabel, className: tierClass } = getSellerTierBadgeDisplay(tier);
  const Glyph = tierGlyph[tier];
  return (
    <span
      title={`Seller tier: ${shortLabel}`}
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] sm:text-xs font-semibold tracking-tight shrink-0 ${tierClass} ${className}`}
    >
      <Glyph
        className={`w-2.5 h-2.5 sm:w-3 sm:h-3 shrink-0 ${tier === 'large' ? 'text-white/95 drop-shadow-sm' : 'opacity-90'}`}
        aria-hidden
      />
      {shortLabel}
    </span>
  );
}

type Variant = 'header' | 'inline';

/**
 * Tier badge from completed seller onboarding (localStorage). Renders nothing if no stored plan.
 */
export function SellerTierBadge({ variant = 'header' }: { variant?: Variant }) {
  const { pathname } = useLocation();
  const [plan, setPlan] = useState<StoredSellerMembership | null>(() => getStoredSellerMembership());

  useEffect(() => {
    setPlan(getStoredSellerMembership());
  }, [pathname]);

  if (!plan) return null;

  const { shortLabel, className } = getSellerTierBadgeDisplay(plan.tier);
  const Glyph = tierGlyph[plan.tier];
  const cadence = plan.billingInterval === 'annual' ? 'Annual' : 'Monthly';
  const title = `${shortLabel} tier · ${cadence} · ${formatUsd(plan.amountUsd)}${
    plan.billingInterval === 'annual' ? '/yr' : '/mo'
  } (demo)`;

  if (variant === 'inline') {
    return (
      <span
        title={title}
        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold tracking-tight ${className}`}
      >
        <Glyph
          className={`w-3.5 h-3.5 shrink-0 ${plan.tier === 'large' ? 'text-white/95' : 'opacity-90'}`}
          aria-hidden
        />
        {shortLabel}
      </span>
    );
  }

  return (
    <span
      title={title}
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] sm:text-[11px] font-semibold tracking-tight ${className}`}
    >
      <Glyph
        className={`w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 ${plan.tier === 'large' ? 'text-white/95' : 'opacity-90'}`}
        aria-hidden
      />
      {shortLabel}
    </span>
  );
}

/** Profile menu row — only renders after onboarding has stored a membership tier. */
export function SellerTierAccountHint() {
  const { pathname } = useLocation();
  const [hasTier, setHasTier] = useState(() => getStoredSellerMembership() !== null);

  useEffect(() => {
    setHasTier(getStoredSellerMembership() !== null);
  }, [pathname]);

  if (!hasTier) return null;

  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-gray-500 dark:text-gray-400">Tier</span>
      <SellerTierBadge variant="inline" />
    </div>
  );
}
