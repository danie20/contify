import { Link } from 'react-router';
import { ArrowLeft, Send } from 'lucide-react';
import { useSellerWorkspace, type InviteStatus } from './SellerWorkspaceContext';

function formatShort(iso: string) {
  try {
    return new Date(iso).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function SellerInvitesPage() {
  const { sentInvites, setInviteStatus } = useSellerWorkspace();
  const sorted = [...sentInvites].sort((a, b) => b.sentAt.localeCompare(a.sentAt));

  return (
    <div className="max-w-7xl mx-auto p-6">
      <Link
        to="/seller"
        className="inline-flex items-center gap-2 text-emerald-800 hover:underline text-sm font-medium mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to workspace
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Invites sent</h2>
          <p className="text-gray-600 max-w-2xl">
            Full history of collaboration invites. Update status as you hear back (mock — for your workflow and demos
            only). When a creator is ready to discuss rates, continue in{' '}
            <Link to="/seller/negotiations" className="text-emerald-700 font-medium hover:underline">
              Payment talks
            </Link>{' '}
            (mirrors the influencer-side negotiation screen).
          </p>
        </div>
        <Link
          to="/seller/find-influencers"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 shrink-0"
        >
          <Send className="w-4 h-4" />
          New invite
        </Link>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-700">
              <tr>
                <th className="px-4 py-3 font-semibold">Creator</th>
                <th className="px-4 py-3 font-semibold">Campaign</th>
                <th className="px-4 py-3 font-semibold">Sent</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold min-w-[200px]">Message preview</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {sorted.map((inv) => (
                <tr key={inv.id} className="hover:bg-gray-50/80 align-top">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <img src={inv.avatar} alt="" className="w-9 h-9 rounded-full object-cover border border-gray-100" />
                      <div>
                        <p className="font-medium text-gray-900">{inv.displayName}</p>
                        <p className="text-xs text-emerald-700">{inv.handle}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-700 max-w-[180px]">
                    {inv.campaign || <span className="text-gray-400">—</span>}
                  </td>
                  <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{formatShort(inv.sentAt)}</td>
                  <td className="px-4 py-3">
                    <select
                      value={inv.status}
                      onChange={(e) => setInviteStatus(inv.id, e.target.value as InviteStatus)}
                      className="border border-gray-200 dark:border-gray-600 rounded-lg px-2 py-1.5 text-xs font-medium bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
                    >
                      <option value="pending">Pending</option>
                      <option value="viewed">Viewed</option>
                      <option value="accepted">Accepted</option>
                      <option value="declined">Declined</option>
                    </select>
                  </td>
                  <td className="px-4 py-3 text-gray-600 max-w-xs">
                    <p className="line-clamp-2 text-xs">{inv.message}</p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {sorted.length === 0 && (
          <p className="p-10 text-center text-gray-500 text-sm">No invites yet.</p>
        )}
      </div>
    </div>
  );
}
