import { Link } from 'react-router';
import { ArrowLeft, Headphones, Mail, BookOpen, Clock, CheckCircle2 } from 'lucide-react';

const faqs = [
  {
    q: 'How long does RFLS review take?',
    a: 'Most requests get an initial response within 2–3 business days. Complex deals or missing details can add a few extra days — check RFLS status for live updates (mock in this demo).',
  },
  {
    q: 'I was countered in negotiations. What now?',
    a: 'You can accept, send a counter, or decline. If you need time, use Reminders (sellers) or your own notes. Nothing is final until both sides accept in the payment negotiation flow.',
  },
  {
    q: 'A seller asked for more information. Where do I upload files?',
    a: 'In Payment negotiations, use the message box and paperclip to attach PDFs, images, or documents. The same thread is visible to the seller in their portal.',
  },
  {
    q: 'How do I end a partnership or withdraw an RFLS?',
    a: 'From RFLS status, use withdraw or decline where available. If you are already in contract, follow the offboarding terms in your agreement (mock — not shown here).',
  },
];

export function SupportPage() {
  return (
    <div className="max-w-4xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-primary)] hover:underline mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to dashboard
      </Link>

      <div className="flex items-center gap-3 mb-2">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300">
          <Headphones className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 tracking-tight">Support</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">FAQs, response times, and where to get more help</p>
        </div>
      </div>

      <p className="text-gray-600 dark:text-gray-400 mt-4 mb-8 max-w-2xl">
        This is a mock support hub for the hackweek demo. In production, this would connect to your help center and
        ticket system.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-10">
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-gray-500 text-xs font-medium uppercase tracking-wide mb-1">
            <Clock className="w-3.5 h-3.5" />
            Target first reply
          </div>
          <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">Under 24h</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Business days (demo SLA)</p>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-gray-500 text-xs font-medium uppercase tracking-wide mb-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Self‑serve
          </div>
          <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">Help center</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            <Link to="/help" className="text-[var(--color-primary)] hover:underline font-medium">
              RFLS to contract guide
            </Link>
          </p>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-gray-500 text-xs font-medium uppercase tracking-wide mb-1">
            <Mail className="w-3.5 h-3.5" />
            Still stuck?
          </div>
          <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">Contact</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            <Link to="/contact" className="text-[var(--color-primary)] hover:underline font-medium">
              Send a message
            </Link>
          </p>
        </div>
      </div>

      <section className="mb-10">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-violet-600 dark:text-violet-400" />
          Frequently asked questions
        </h2>
        <div className="space-y-3">
          {faqs.map((item) => (
            <details
              key={item.q}
              className="group rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4 shadow-sm open:ring-1 open:ring-gray-200 dark:open:ring-gray-700 [&_summary::-webkit-details-marker]:hidden"
            >
              <summary className="cursor-pointer list-none font-medium text-gray-900 dark:text-gray-100 flex items-center justify-between gap-2 marker:content-none">
                <span>{item.q}</span>
                <span className="text-gray-400 text-sm group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="mt-3 text-sm text-gray-600 dark:text-gray-400 leading-relaxed border-t border-gray-100 dark:border-gray-800 pt-3">{item.a}</p>
            </details>
          ))}
        </div>
      </section>

      <div className="rounded-xl border border-violet-200 dark:border-violet-900/60 bg-violet-50/80 dark:bg-violet-950/40 p-5">
        <p className="text-sm text-violet-950 dark:text-violet-100">
          <strong className="font-semibold">Tip:</strong> Many payout and eligibility questions are answered faster from{' '}
          <Link to="/help" className="underline font-medium">
            Help
          </Link>{' '}
          and{' '}
          <Link to="/negotiations" className="underline font-medium">
            Negotiations
          </Link>{' '}
          than by email — check those first.
        </p>
      </div>
    </div>
  );
}
