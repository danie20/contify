import { Link } from 'react-router';

const focusRing =
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 rounded-sm';

export function AppFooter({ variant = 'default' }: { variant?: 'default' | 'seller' }) {
  const isSeller = variant === 'seller';

  const shell = isSeller
    ? 'border-emerald-200/80 dark:border-emerald-900/60 bg-gradient-to-b from-emerald-950/[0.04] via-emerald-950/[0.05] to-emerald-950/[0.08] dark:from-emerald-950/30 dark:via-emerald-950/40 dark:to-emerald-950/50 shadow-[0_-1px_0_rgba(16,185,129,0.12)] dark:shadow-[0_-1px_0_rgba(16,185,129,0.2)]'
    : 'border-slate-200/90 dark:border-gray-800 bg-slate-50/90 dark:bg-gray-950/95 shadow-[0_-8px_30px_-18px_rgba(15,23,42,0.12)] dark:shadow-[0_-8px_30px_-18px_rgba(0,0,0,0.45)]';

  const brand = isSeller
    ? 'text-emerald-950 hover:text-emerald-800 dark:text-emerald-100 dark:hover:text-emerald-50'
    : 'text-slate-900 hover:text-slate-700 dark:text-gray-100 dark:hover:text-white';

  const tagline = isSeller ? 'text-emerald-800/65 dark:text-emerald-200/70' : 'text-slate-500 dark:text-gray-400';

  const heading = isSeller
    ? 'text-emerald-900/55 dark:text-emerald-300/80'
    : 'text-slate-500 dark:text-gray-500';

  const link = isSeller
    ? `${focusRing} focus-visible:ring-emerald-500/40 text-emerald-900/85 hover:text-emerald-950 dark:text-emerald-100/90 dark:hover:text-white transition-colors`
    : `${focusRing} focus-visible:ring-slate-400/50 text-slate-600 hover:text-slate-900 dark:text-gray-400 dark:hover:text-gray-100 transition-colors`;

  const divider = isSeller ? 'border-emerald-200/60 dark:border-emerald-900/50' : 'border-slate-200/80 dark:border-gray-800';

  const copyright = isSeller ? 'text-emerald-800/45 dark:text-emerald-400/50' : 'text-slate-400 dark:text-gray-500';

  return (
    <footer className={`mt-auto border-t ${shell}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 lg:py-12">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,280px)_1fr] lg:gap-16 xl:gap-24">
          <div className="space-y-3">
            <Link
              to="/"
              className={`inline-block text-lg font-semibold tracking-tight ${brand}`}
            >
              ConnectIn
            </Link>
            <p className={`text-sm leading-relaxed max-w-sm ${tagline}`}>
              Connect brands and creators. Demo build — legal pages use placeholder text.
            </p>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:gap-12 md:grid-cols-3 md:gap-10">
            <div>
              <h3
                className={`text-[11px] font-semibold uppercase tracking-[0.14em] ${heading}`}
              >
                Help
              </h3>
              <ul className="mt-4 space-y-3">
                <li>
                  <Link to="/help" className={`text-sm font-medium ${link}`}>
                    Help center
                  </Link>
                </li>
                <li>
                  <Link to="/support" className={`text-sm font-medium ${link}`}>
                    Support
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3
                className={`text-[11px] font-semibold uppercase tracking-[0.14em] ${heading}`}
              >
                Contact
              </h3>
              <ul className="mt-4 space-y-3">
                <li>
                  <Link to="/contact" className={`text-sm font-medium ${link}`}>
                    Contact us
                  </Link>
                </li>
              </ul>
            </div>

            <div className="col-span-2 md:col-span-1">
              <h3
                className={`text-[11px] font-semibold uppercase tracking-[0.14em] ${heading}`}
              >
                Legal
              </h3>
              <ul className="mt-4 space-y-3">
                <li>
                  <Link to="/terms" className={`text-sm font-medium ${link}`}>
                    User agreement
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className={`text-sm font-medium ${link}`}>
                    Privacy policy
                  </Link>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <div className={`mt-10 pt-8 border-t ${divider}`}>
          <p className={`text-center text-xs sm:text-left leading-relaxed ${copyright}`}>
            © {new Date().getFullYear()} ConnectIn. Hackweek demo.
          </p>
        </div>
      </div>
    </footer>
  );
}
