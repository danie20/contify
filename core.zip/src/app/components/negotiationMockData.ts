/** Shared mock threads for influencer vs seller payment negotiation demos (same message shape, both parties named). */

export interface Attachment {
  id: string;
  name: string;
  type: 'pdf' | 'image' | 'document';
  size: string;
  url: string;
}

export interface NegotiationMessage {
  id: number;
  sender: 'influencer' | 'seller';
  content: string;
  timestamp: string;
  isOffer?: boolean;
  offerAmount?: number;
  isInfoRequest?: boolean;
  attachments?: Attachment[];
}

export interface Negotiation {
  id: number;
  rflsId?: number;
  sellerName: string;
  sellerVerified: boolean;
  sellerAvatar: string;
  influencerName: string;
  influencerHandle: string;
  influencerAvatar: string;
  status: 'pending' | 'active' | 'accepted' | 'declined';
  proposedRate: number;
  counterRate?: number;
  paymentType: string;
  startDate: string;
  messages: NegotiationMessage[];
  needsInfo?: boolean;
  infoRequest?: string;
}

/** Logged-in influencer's negotiations with various sellers (influencer app). */
export const INFLUENCER_NEGOTIATIONS: Negotiation[] = [
  {
    id: 1,
    rflsId: 1,
    sellerName: 'Premium Electronics Store',
    sellerVerified: true,
    sellerAvatar: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=100&h=100&fit=crop',
    influencerName: 'Alex Rivera',
    influencerHandle: '@alexstreamstv',
    influencerAvatar:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    status: 'active',
    proposedRate: 150,
    counterRate: 175,
    paymentType: 'Per Stream + Commission',
    startDate: '2026-05-15',
    messages: [
      {
        id: 1,
        sender: 'seller',
        content:
          "Hi! We'd love to work with you. Based on your follower count, we can offer $150 per stream plus 5% commission.",
        timestamp: '2026-05-01 10:30',
        isOffer: true,
        offerAmount: 150,
      },
      {
        id: 2,
        sender: 'influencer',
        content:
          "Thanks for the offer! Given my engagement rate and streaming experience, I was thinking $175 per stream would be more appropriate.",
        timestamp: '2026-05-01 14:20',
        isOffer: true,
        offerAmount: 175,
      },
      {
        id: 3,
        sender: 'seller',
        content: "That's reasonable. Let's discuss the commission structure as well.",
        timestamp: '2026-05-02 09:15',
      },
    ],
  },
  {
    id: 2,
    rflsId: 2,
    sellerName: 'Fashion Forward Boutique',
    sellerVerified: true,
    sellerAvatar: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=100&h=100&fit=crop',
    influencerName: 'Alex Rivera',
    influencerHandle: '@alexstreamstv',
    influencerAvatar:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    status: 'active',
    proposedRate: 175,
    counterRate: 200,
    paymentType: 'Flat Rate + Commission',
    startDate: '2026-05-10',
    needsInfo: true,
    infoRequest:
      'Please provide your previous fashion streaming portfolio and engagement metrics for fashion-related content.',
    messages: [
      {
        id: 1,
        sender: 'seller',
        content: 'Thank you for your proposal. We need some additional information before proceeding with the payment terms.',
        timestamp: '2026-04-28 10:30',
      },
      {
        id: 2,
        sender: 'seller',
        content:
          "Please provide your previous fashion streaming portfolio and engagement metrics for fashion-related content. Also, share any brand partnerships you've had in the fashion industry.",
        timestamp: '2026-04-28 10:32',
        isInfoRequest: true,
      },
      {
        id: 3,
        sender: 'influencer',
        content:
          "I've attached my streaming portfolio from the last 6 months and detailed analytics showing engagement rates. I've also included brand collaboration case studies.",
        timestamp: '2026-04-29 14:15',
        attachments: [
          {
            id: '1',
            name: 'Fashion_Streaming_Portfolio_Q1_2026.pdf',
            type: 'pdf',
            size: '2.4 MB',
            url: '#',
          },
          {
            id: '2',
            name: 'Engagement_Analytics_Report.pdf',
            type: 'pdf',
            size: '1.8 MB',
            url: '#',
          },
          {
            id: '3',
            name: 'Brand_Collaboration_Screenshots.jpg',
            type: 'image',
            size: '856 KB',
            url: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=400&h=300&fit=crop',
          },
        ],
      },
    ],
  },
  {
    id: 3,
    rflsId: 3,
    sellerName: 'Collectibles Warehouse',
    sellerVerified: true,
    sellerAvatar: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=100&h=100&fit=crop',
    influencerName: 'Alex Rivera',
    influencerHandle: '@alexstreamstv',
    influencerAvatar:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    status: 'active',
    proposedRate: 125,
    counterRate: 150,
    paymentType: 'Commission Only',
    startDate: '2026-05-20',
    needsInfo: true,
    infoRequest:
      'Please provide proof of your previous collectibles streaming experience and viewer demographics. We need to verify your audience matches our collector community.',
    messages: [
      {
        id: 1,
        sender: 'seller',
        content:
          'Thanks for your interest! Before we discuss payment, we need to understand your experience with collectibles streaming.',
        timestamp: '2026-04-30 11:20',
      },
      {
        id: 2,
        sender: 'seller',
        content:
          'Please provide proof of your previous collectibles streaming experience and viewer demographics. We need to verify your audience matches our collector community.',
        timestamp: '2026-04-30 11:22',
        isInfoRequest: true,
      },
    ],
  },
];

/** Sports Gear Pro (seller portal) — payment talks with creators who accepted / moved to terms. */
export const SELLER_SPORTS_GEAR_NEGOTIATIONS: Negotiation[] = [
  {
    id: 101,
    rflsId: 1204,
    sellerName: 'Sports Gear Pro',
    sellerVerified: true,
    sellerAvatar: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=100&h=100&fit=crop',
    influencerName: 'Taylor Brooks',
    influencerHandle: '@taylorfitlive',
    influencerAvatar:
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face',
    status: 'active',
    proposedRate: 200,
    counterRate: 225,
    paymentType: 'Per Stream + Commission',
    startDate: '2026-05-18',
    messages: [
      {
        id: 1,
        sender: 'seller',
        content:
          "Thanks for accepting our invite! We're excited to feature our outlet running line. We're proposing $200 per stream plus 6% commission on attributed sales.",
        timestamp: '2026-05-02 11:00',
        isOffer: true,
        offerAmount: 200,
      },
      {
        id: 2,
        sender: 'influencer',
        content:
          'Appreciate the offer. Given my average live viewers in fitness and last quarter’s conversion on similar collabs, I’d need $225 base to make the slots work.',
        timestamp: '2026-05-02 16:40',
        isOffer: true,
        offerAmount: 225,
      },
      {
        id: 3,
        sender: 'seller',
        content:
          'Understood. We can stretch to $215 if we cap at 5 streams in May — does that work for your calendar?',
        timestamp: '2026-05-03 09:05',
        isOffer: true,
        offerAmount: 215,
      },
    ],
  },
  {
    id: 102,
    rflsId: 1198,
    sellerName: 'Sports Gear Pro',
    sellerVerified: true,
    sellerAvatar: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=100&h=100&fit=crop',
    influencerName: 'Morgan Patel',
    influencerHandle: '@mogamingdeals',
    influencerAvatar:
      'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop&crop=face',
    status: 'active',
    proposedRate: 180,
    counterRate: 195,
    paymentType: 'Flat rate + bonus on sell-through',
    startDate: '2026-05-22',
    needsInfo: true,
    infoRequest:
      'Please confirm you can carry 12 SKU bundles per stream and share two reference VODs from similar sports-tech streams.',
    messages: [
      {
        id: 1,
        sender: 'seller',
        content:
          'Great to connect after your invite response. We want to lock payment before we ship sample units.',
        timestamp: '2026-05-01 08:15',
      },
      {
        id: 2,
        sender: 'seller',
        content:
          'Please confirm you can carry 12 SKU bundles per stream and share two reference VODs from similar sports-tech streams.',
        timestamp: '2026-05-01 08:18',
        isInfoRequest: true,
      },
      {
        id: 3,
        sender: 'influencer',
        content: 'Attached two VOD links and my typical run-of-show for multi-SKU drops. Happy to do 12 SKUs with a runner.',
        timestamp: '2026-05-01 19:22',
      },
      {
        id: 4,
        sender: 'influencer',
        content: 'On rate: $195 flat per stream matches my last sports-tech partnership.',
        timestamp: '2026-05-01 19:24',
        isOffer: true,
        offerAmount: 195,
      },
    ],
  },
];
