import { useEffect, useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router';
import {
  Users,
  Search,
  MessageSquare,
  UserPlus,
  LogOut,
  Settings,
  Bell,
  TrendingUp,
  Menu,
  X,
  Sparkles,
  LifeBuoy,
  Headphones,
  Mail,
} from 'lucide-react';
import { AppFooter } from './AppFooter';
import { ThemeToggle } from './ThemeToggle';

function matchNav(pathname: string, path: string) {
  if (path === '/') return pathname === '/' || pathname === '';
  return pathname === path || pathname.startsWith(`${path}/`);
}

export function RootLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const pathname = location.pathname;
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    setMobileNavOpen(false);
  }, [pathname]);

  const navItems = [
    { path: '/', label: 'Dashboard', icon: Users },
    { path: '/discover', label: 'Discover', icon: Search },
    { path: '/application-status', label: 'RFLS status', icon: TrendingUp },
    { path: '/negotiations', label: 'Negotiations', icon: MessageSquare },
  ];

  const handleSignOut = () => {
    navigate('/signin');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 border-b border-gray-200/90 dark:border-gray-800/80 bg-white/80 dark:bg-gray-950/85 backdrop-blur-xl shadow-[0_1px_0_rgba(15,23,42,0.06)] dark:shadow-[0_1px_0_rgba(0,0,0,0.35)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex h-14 sm:h-16 items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <Link
                to="/"
                className="flex items-center gap-2.5 shrink-0 group"
                onClick={() => setMobileNavOpen(false)}
              >
                <div className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-500/20 ring-1 ring-white/20 transition-transform group-hover:scale-[1.02]">
                  <Sparkles className="w-4 h-4 sm:w-[18px] sm:h-[18px]" strokeWidth={2} />
                </div>
                <div className="flex flex-col leading-none min-w-0">
                  <span className="font-semibold text-gray-900 dark:text-gray-100 tracking-tight text-sm sm:text-base truncate">
                    ConnectIn
                  </span>
                  <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.12em] text-gray-400 dark:text-gray-500 font-medium mt-0.5 hidden sm:block">
                    Creator workspace
                  </span>
                </div>
              </Link>

              <div className="lg:hidden ml-auto flex items-center gap-2">
                <ThemeToggle />
                <button
                  type="button"
                  aria-expanded={mobileNavOpen}
                  aria-label={mobileNavOpen ? 'Close menu' : 'Open menu'}
                  onClick={() => setMobileNavOpen((o) => !o)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                >
                  {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <nav className="hidden lg:flex flex-1 justify-center px-4 min-w-0">
              <div className="inline-flex items-center gap-0.5 rounded-full bg-gray-100/90 dark:bg-gray-900/90 p-1 ring-1 ring-gray-200/60 dark:ring-gray-700/80 shadow-inner">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = matchNav(pathname, item.path);
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      title={item.label}
                      className={`flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-medium transition-all duration-200 whitespace-nowrap ${
                        active
                          ? 'bg-white dark:bg-gray-800 text-[var(--color-primary)] shadow-sm ring-1 ring-gray-200/80 dark:ring-gray-600'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-white/60 dark:hover:bg-gray-800/80'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'opacity-100' : 'opacity-70'}`} />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </nav>

            <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-gray-200/80 dark:border-gray-700/80">
              <ThemeToggle />
              <button
                type="button"
                className="relative flex h-10 w-10 items-center justify-center rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white transition-colors"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-gray-950" />
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className={`flex h-10 items-center gap-2 rounded-full pl-1 pr-2.5 py-1 transition-colors ${
                    showUserMenu
                      ? 'bg-gray-100 dark:bg-gray-800 ring-2 ring-gray-200 dark:ring-gray-600'
                      : ['/onboarding', '/help', '/support', '/contact', '/terms', '/privacy'].includes(
                          pathname,
                        )
                        ? 'ring-2 ring-[var(--color-primary)]/25 bg-gray-50 dark:bg-gray-900'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-gray-700 to-gray-900 text-white text-xs font-semibold shadow-sm">
                    JI
                  </div>
                  <span className="text-sm font-medium text-gray-800 dark:text-gray-200 max-w-[100px] truncate hidden xl:inline">
                    John
                  </span>
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 rounded-2xl border border-gray-200/80 dark:border-gray-700 bg-white dark:bg-gray-900 py-2 text-gray-800 dark:text-gray-200 shadow-xl shadow-gray-200/50 dark:shadow-black/40 z-50">
                    <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100">John Influencer</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">john@example.com</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        navigate('/onboarding');
                      }}
                      className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <UserPlus className="w-4 h-4 text-gray-500 dark:text-gray-400 mt-0.5 shrink-0" />
                      <span>
                        <span className="block text-sm font-medium text-gray-900 dark:text-gray-100">Onboarding</span>
                        <span className="block text-xs text-gray-500 dark:text-gray-400 mt-0.5 leading-snug">
                          One-time profile &amp; stream setup — edit anytime
                        </span>
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        navigate('/help');
                      }}
                      className="w-full flex items-start gap-3 px-4 py-2.5 text-left hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <LifeBuoy className="w-4 h-4 text-gray-500 dark:text-gray-400 mt-0.5 shrink-0" />
                      <span>
                        <span className="block text-sm font-medium text-gray-900 dark:text-gray-100">Help</span>
                        <span className="block text-xs text-gray-500 dark:text-gray-400 mt-0.5">RFLS to contract &amp; how it works</span>
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        navigate('/support');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <Headphones className="w-4 h-4 text-gray-500 dark:text-gray-400 shrink-0" />
                      Support
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        navigate('/contact');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <Mail className="w-4 h-4 text-gray-500 dark:text-gray-400 shrink-0" />
                      Contact
                    </button>
                    <button
                      type="button"
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <Settings className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                      Settings
                    </button>
                    <div className="my-1.5 border-t border-gray-100 dark:border-gray-800" />
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        handleSignOut();
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {mobileNavOpen && (
            <div className="lg:hidden border-t border-gray-100 dark:border-gray-800 py-3">
              <div className="flex flex-col gap-1 rounded-2xl bg-gray-50/90 dark:bg-gray-900/90 p-2 ring-1 ring-gray-200/60 dark:ring-gray-700/80">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = matchNav(pathname, item.path);
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-colors ${
                        active
                          ? 'bg-white dark:bg-gray-800 text-[var(--color-primary)] shadow-sm ring-1 ring-gray-200 dark:ring-gray-600'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-white/80 dark:hover:bg-gray-800/80'
                      }`}
                    >
                      <Icon className="w-5 h-5 shrink-0 opacity-80" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
              <div className="mt-3 flex items-center justify-between gap-3 px-1">
                <button
                  type="button"
                  className="relative flex flex-1 items-center justify-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 py-3 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm"
                >
                  <Bell className="w-4 h-4" />
                  Alerts
                  <span className="absolute top-2.5 right-3 h-2 w-2 rounded-full bg-rose-500" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileNavOpen(false);
                    navigate('/onboarding');
                  }}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 py-3 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm"
                >
                  <UserPlus className="w-4 h-4" />
                  Onboarding
                </button>
              </div>
              <div className="mt-3 grid grid-cols-1 gap-2">
                <Link
                  to="/help"
                  onClick={() => setMobileNavOpen(false)}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/80 dark:bg-indigo-950/50 py-3 text-sm font-medium text-indigo-900 dark:text-indigo-200 shadow-sm"
                >
                  <LifeBuoy className="w-4 h-4 shrink-0" />
                  Help
                </Link>
                <div className="grid grid-cols-2 gap-2">
                  <Link
                    to="/support"
                    onClick={() => setMobileNavOpen(false)}
                    className="flex items-center justify-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 py-3 text-sm font-medium text-gray-800 dark:text-gray-200 shadow-sm"
                  >
                    <Headphones className="w-4 h-4 shrink-0" />
                    Support
                  </Link>
                  <Link
                    to="/contact"
                    onClick={() => setMobileNavOpen(false)}
                    className="flex items-center justify-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 py-3 text-sm font-medium text-gray-800 dark:text-gray-200 shadow-sm"
                  >
                    <Mail className="w-4 h-4 shrink-0" />
                    Contact
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 overflow-auto bg-gray-50 dark:bg-gray-950">
        <Outlet />
      </main>
      <AppFooter />
    </div>
  );
}
