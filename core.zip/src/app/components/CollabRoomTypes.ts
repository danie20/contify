/** Live Collab Room — shared workspace state per RFLS (client-side demo). */

export type CollabParticipant = 'influencer' | 'seller';

/** Chat sender includes automated ConnectIn notices (demo). */
export type CollabMessageSender = CollabParticipant | 'system';

export interface ChecklistItem {
  id: string;
  label: string;
  done: boolean;
}

export interface RunOfShowRow {
  id: string;
  startTime: string;
  segment: string;
  notes: string;
}

export interface AssetRow {
  id: string;
  name: string;
  url: string;
}

export interface DeadlineRow {
  id: string;
  label: string;
  dueDate: string;
  done: boolean;
}

export interface CollabChatMessage {
  id: string;
  sender: CollabMessageSender;
  authorLabel: string;
  content: string;
  createdAt: string;
}

export interface CollabRoomState {
  rflsId: number;
  sellerName: string;
  influencerName: string;
  platform?: string;
  checklist: ChecklistItem[];
  runOfShow: RunOfShowRow[];
  assets: AssetRow[];
  deadlines: DeadlineRow[];
  chat: CollabChatMessage[];
}
