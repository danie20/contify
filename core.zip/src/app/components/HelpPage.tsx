import { Link } from 'react-router';
import { ArrowLeft, BookOpen, LifeBuoy } from 'lucide-react';

export function HelpPage() {
  return (
    <div className="max-w-4xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-primary)] hover:underline mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to dashboard
      </Link>

      <div className="flex items-center gap-3 mb-2">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
          <LifeBuoy className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 tracking-tight">Help</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">How the platform works for creators</p>
        </div>
      </div>

      <p className="text-gray-600 dark:text-gray-400 mt-4 mb-8 max-w-2xl">
        From your first RFLS to a signed deal and live show, here is the end-to-end flow on ConnectIn.
      </p>

      <section className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-6 sm:p-8 dark:from-blue-950/40 dark:to-purple-950/40 dark:border-blue-900/50">
        <div className="flex items-start gap-3 mb-6">
          <BookOpen className="w-6 h-6 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">How it works: RFLS to contract</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Request for live streaming (RFLS) through contract and going live in four steps.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white dark:bg-gray-900/90 rounded-xl p-5 shadow-sm border border-gray-200/90 dark:border-gray-700">
            <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center mb-3 text-lg font-semibold">
              1
            </div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-1">Submit RFLS</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              Connect with a seller and submit your live-streaming request
            </p>
          </div>
          <div className="bg-white dark:bg-gray-900/90 rounded-xl p-5 shadow-sm border border-gray-200/90 dark:border-gray-700">
            <div className="w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center mb-3 text-lg font-semibold">
              2
            </div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-1">Review process</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              Track your RFLS status through initial and seller review stages
            </p>
          </div>
          <div className="bg-white dark:bg-gray-900/90 rounded-xl p-5 shadow-sm border border-gray-200/90 dark:border-gray-700">
            <div className="w-10 h-10 bg-yellow-500 text-white rounded-full flex items-center justify-center mb-3 text-lg font-semibold">
              3
            </div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-1">Negotiate terms</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              Accept, counter, or decline payment proposals from sellers
            </p>
          </div>
          <div className="bg-white dark:bg-gray-900/90 rounded-xl p-5 shadow-sm border border-gray-200/90 dark:border-gray-700">
            <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center mb-3 text-lg font-semibold">
              4
            </div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-1">Contract &amp; stream</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              Sign contract and begin your streaming partnership
            </p>
          </div>
        </div>
      </section>

      <div className="mt-10 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5 shadow-sm">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">Related</h3>
        <ul className="space-y-2 text-sm">
          <li>
            <Link to="/discover" className="text-[var(--color-primary)] hover:underline font-medium">
              Discover sellers
            </Link>
            <span className="text-gray-500 dark:text-gray-400"> — find partners to send an RFLS</span>
          </li>
          <li>
            <Link to="/application-status" className="text-[var(--color-primary)] hover:underline font-medium">
              RFLS status
            </Link>
            <span className="text-gray-500 dark:text-gray-400"> — see where your applications stand</span>
          </li>
          <li>
            <Link to="/negotiations" className="text-[var(--color-primary)] hover:underline font-medium">
              Negotiations
            </Link>
            <span className="text-gray-500 dark:text-gray-400"> — discuss rates and payment terms</span>
          </li>
          <li>
            <Link to="/support" className="text-[var(--color-primary)] hover:underline font-medium">
              Support
            </Link>
            <span className="text-gray-500 dark:text-gray-400"> — FAQs and guidance</span>
          </li>
          <li>
            <Link to="/contact" className="text-[var(--color-primary)] hover:underline font-medium">
              Contact
            </Link>
            <span className="text-gray-500 dark:text-gray-400"> — message the team (demo form)</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
