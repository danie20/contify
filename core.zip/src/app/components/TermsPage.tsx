import { Link } from 'react-router';
import { ArrowLeft } from 'lucide-react';

export function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto p-6 pb-16 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-primary)] hover:underline mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to home
      </Link>
      <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-2">User agreement</h1>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Last updated: May 4, 2026 · Placeholder for demo purposes only</p>

      <div className="prose prose-sm max-w-none text-gray-700 dark:text-gray-300 space-y-4">
        <p>
          This User Agreement (&quot;Agreement&quot;) is placeholder text for the ConnectIn hackweek prototype.
          It does not constitute legal advice and is not binding.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">1. Service</h2>
        <p>
          The platform connects influencers and sellers for live-stream commerce collaborations. Features, availability,
          and fees may change during beta or demo phases.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">2. Your account</h2>
        <p>
          You are responsible for accurate profile information, securing your credentials, and activity under your
          account. You must comply with applicable marketplace and streaming platform rules.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">3. Content &amp; conduct</h2>
        <p>
          You grant a limited license to display content needed to operate the service. Harassment, fraud, or illegal
          activity may result in suspension (described here for illustration only).
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">4. Payment &amp; contracts</h2>
        <p>
          Payment terms are negotiated between parties. ConnectIn may facilitate workflows but final commercial
          terms are between you and your partner unless otherwise stated in a future production agreement.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">5. Limitation of liability</h2>
        <p>
          To the maximum extent permitted by law, the demo service is provided &quot;as is&quot; without warranties.
          These provisions are illustrative placeholders.
        </p>
        <p className="text-sm text-gray-500 pt-4">
          Questions? See{' '}
          <Link to="/contact" className="text-[var(--color-primary)] hover:underline font-medium">
            Contact
          </Link>{' '}
          or{' '}
          <Link to="/help" className="text-[var(--color-primary)] hover:underline font-medium">
            Help
          </Link>
          .
        </p>
      </div>
    </div>
  );
}
