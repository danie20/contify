import { Link } from 'react-router';
import { ArrowLeft } from 'lucide-react';

export function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto p-6 pb-16 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-primary)] hover:underline mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to home
      </Link>
      <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Privacy policy</h1>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Last updated: May 4, 2026 · Placeholder for demo purposes only</p>

      <div className="prose prose-sm max-w-none text-gray-700 dark:text-gray-300 space-y-4">
        <p>
          This Privacy Policy describes how ConnectIn would handle information in a production environment.
          This page is <strong>mock content</strong> for the hackweek demo.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">Information we would collect</h2>
        <p>
          Examples include account details (name, email), profile and streaming preferences, RFLS and negotiation
          metadata, and usage analytics to improve the product.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">How we would use it</h2>
        <p>
          To operate the service, match influencers with sellers, send notifications, comply with law, and improve
          security and reliability.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">Sharing</h2>
        <p>
          Data might be shared with service providers (hosting, email), marketplace partners when required to complete
          a collaboration, or when legally required. No sale of personal data is implied by this demo.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">Your choices</h2>
        <p>
          In a full product you would access, correct, or delete certain data through settings or support. Retention
          periods would be documented per jurisdiction.
        </p>
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 pt-2">Contact</h2>
        <p>
          For this prototype, use{' '}
          <Link to="/contact" className="text-[var(--color-primary)] hover:underline font-medium">
            Contact
          </Link>{' '}
          for questions about this placeholder policy.
        </p>
      </div>
    </div>
  );
}
