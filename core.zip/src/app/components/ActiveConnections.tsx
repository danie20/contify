import { useMemo, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Search, Video, BadgeCheck } from 'lucide-react';
import { SellerTierPill } from './SellerTierBadge';
import { mockSellerTierForDisplay } from './sellerTierMock';

interface LiveStreamingConnection {
  id: number;
  sellerName: string;
  sellerAvatar: string;
  platform: string;
  streamingApprovedDate: string;
  contractRef: string;
}

const mockLiveStreamingConnections: LiveStreamingConnection[] = [
  {
    id: 1,
    sellerName: 'Premium Electronics Store',
    sellerAvatar: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-04-12',
    contractRef: 'CNT-2026-1042',
  },
  {
    id: 2,
    sellerName: 'Fashion Forward Boutique',
    sellerAvatar: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-04-18',
    contractRef: 'CNT-2026-1088',
  },
  {
    id: 3,
    sellerName: 'Collectibles Warehouse',
    sellerAvatar: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-04-22',
    contractRef: 'CNT-2026-1101',
  },
  {
    id: 4,
    sellerName: 'Sports Gear Pro',
    sellerAvatar: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-04-25',
    contractRef: 'CNT-2026-1114',
  },
  {
    id: 5,
    sellerName: 'Vintage Treasures',
    sellerAvatar: 'https://images.unsplash.com/photo-1567016376408-0226e4d0c1ea?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-04-26',
    contractRef: 'CNT-2026-1120',
  },
  {
    id: 6,
    sellerName: 'Home Decor Haven',
    sellerAvatar: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-04-28',
    contractRef: 'CNT-2026-1127',
  },
  {
    id: 7,
    sellerName: 'TechVault Outlet',
    sellerAvatar: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-04-29',
    contractRef: 'CNT-2026-1133',
  },
  {
    id: 8,
    sellerName: 'Urban Streetwear Co.',
    sellerAvatar: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-04-30',
    contractRef: 'CNT-2026-1139',
  },
  {
    id: 9,
    sellerName: 'Gaming Legends Shop',
    sellerAvatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-01',
    contractRef: 'CNT-2026-1144',
  },
  {
    id: 10,
    sellerName: 'Organic Beauty Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-01',
    contractRef: 'CNT-2026-1146',
  },
  {
    id: 11,
    sellerName: 'Outdoor Adventure Supply',
    sellerAvatar: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-02',
    contractRef: 'CNT-2026-1150',
  },
  {
    id: 12,
    sellerName: 'Luxury Watch Exchange',
    sellerAvatar: 'https://images.unsplash.com/photo-1523170335258-fad8b3b473ae?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-02',
    contractRef: 'CNT-2026-1152',
  },
  {
    id: 13,
    sellerName: 'Pet Paradise Store',
    sellerAvatar: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-02',
    contractRef: 'CNT-2026-1153',
  },
  {
    id: 14,
    sellerName: 'Artisan Coffee Roasters',
    sellerAvatar: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-03',
    contractRef: 'CNT-2026-1158',
  },
  {
    id: 15,
    sellerName: 'Kids Toy Universe',
    sellerAvatar: 'https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-03',
    contractRef: 'CNT-2026-1159',
  },
  {
    id: 16,
    sellerName: 'Handmade Jewelry Loft',
    sellerAvatar: 'https://images.unsplash.com/photo-1515562141207-7a88e7f8516f?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-03',
    contractRef: 'CNT-2026-1161',
  },
  {
    id: 17,
    sellerName: 'Fitness Essentials Hub',
    sellerAvatar: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-03',
    contractRef: 'CNT-2026-1162',
  },
  {
    id: 18,
    sellerName: 'Retro Vinyl & Audio',
    sellerAvatar: 'https://images.unsplash.com/photo-1461360228754-6e81c478b866?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1166',
  },
  {
    id: 19,
    sellerName: 'Smart Home Direct',
    sellerAvatar: 'https://images.unsplash.com/photo-1558002038-1055907df827?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1168',
  },
  {
    id: 20,
    sellerName: 'Board Game Bazaar',
    sellerAvatar: 'https://images.unsplash.com/photo-1610890716171-6b1c8e6e9c0b?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1169',
  },
  {
    id: 21,
    sellerName: 'Sneakerhead Archive',
    sellerAvatar: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1171',
  },
  {
    id: 22,
    sellerName: 'Eco Living Marketplace',
    sellerAvatar: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1172',
  },
  {
    id: 23,
    sellerName: 'Camera Gear Pro Shop',
    sellerAvatar: 'https://images.unsplash.com/photo-1516035069371-29a1b244ccff?w=100&h=100&fit=crop',
    platform: 'eBay Live',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1174',
  },
  {
    id: 24,
    sellerName: 'Craft Beer Collective',
    sellerAvatar: 'https://images.unsplash.com/photo-1532634922-8fe0b757fb13?w=100&h=100&fit=crop',
    platform: 'Whatnot',
    streamingApprovedDate: '2026-05-04',
    contractRef: 'CNT-2026-1175',
  },
];

export function ActiveConnections() {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return mockLiveStreamingConnections;
    return mockLiveStreamingConnections.filter(
      (c) =>
        c.sellerName.toLowerCase().includes(q) ||
        c.platform.toLowerCase().includes(q) ||
        c.contractRef.toLowerCase().includes(q),
    );
  }, [searchTerm]);

  return (
    <div className="max-w-7xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-[var(--color-primary)] hover:opacity-80 mb-6 text-sm font-medium"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to dashboard
      </Link>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-2xl mb-2">Active connections</h2>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl">
            Sellers who have fully approved you for sponsored live streams under an active contract. These
            partnerships are cleared to go live on the listed platforms.
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-green-50 dark:bg-green-950/40 border border-green-200 dark:border-green-900/60 px-4 py-2 text-green-800 dark:text-green-300 text-sm">
          <Video className="w-4 h-4 shrink-0" />
          <span>
            <strong>{mockLiveStreamingConnections.length}</strong> approved for live streaming
          </span>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-4 mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by seller, platform, or contract…"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
              <tr>
                <th className="px-6 py-3 font-semibold text-gray-700 dark:text-gray-300">Seller</th>
                <th className="px-6 py-3 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                <th className="px-6 py-3 font-semibold text-gray-700 dark:text-gray-300">Live streaming approved</th>
                <th className="px-6 py-3 font-semibold text-gray-700 dark:text-gray-300">Contract</th>
                <th className="px-6 py-3 font-semibold text-gray-700 dark:text-gray-300">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtered.map((row) => (
                <tr key={row.id} className="hover:bg-gray-50/80 dark:hover:bg-gray-800/50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={row.sellerAvatar}
                        alt=""
                        className="w-10 h-10 rounded-full object-cover border border-gray-100"
                      />
                      <span className="flex flex-wrap items-center gap-2 font-medium text-gray-900 dark:text-gray-100">
                        {row.sellerName}
                        <SellerTierPill tier={mockSellerTierForDisplay(row.sellerName, row.id)} />
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-700 dark:text-gray-300">{row.platform}</td>
                  <td className="px-6 py-4 text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.streamingApprovedDate}</td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-400 font-mono text-xs">{row.contractRef}</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 rounded-full bg-green-100 text-green-800 px-2.5 py-0.5 text-xs font-medium">
                      <BadgeCheck className="w-3.5 h-3.5" />
                      Live approved
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="px-6 py-12 text-center text-gray-500">No connections match your search.</div>
        )}
      </div>
    </div>
  );
}
