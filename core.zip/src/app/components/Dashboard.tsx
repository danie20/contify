import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router';
import {
  TrendingUp,
  DollarSign,
  Users,
  Star,
  Calendar,
  Clock,
  Radio,
  Plus,
  Trash2,
  RotateCcw,
  ChevronDown,
} from 'lucide-react';
import { SellerTierPill } from './SellerTierBadge';
import { mockSellerTierForDisplay } from './sellerTierMock';

interface StreamSlot {
  id: string;
  date: string;
  title: string;
  partner: string;
  platform: string;
  start: string;
  end: string;
  status: 'confirmed' | 'tentative';
}

const STREAM_SCHEDULE_STORAGE_KEY = 'ic-live-stream-schedule-v1';

const DEFAULT_STREAMS: StreamSlot[] = [
  {
    id: '1',
    date: '2026-05-06',
    title: 'Sneaker outlet stream',
    partner: 'Sports Gear Pro',
    platform: 'eBay Live',
    start: '2:00 PM',
    end: '4:00 PM PT',
    status: 'confirmed',
  },
  {
    id: '2',
    date: '2026-05-09',
    title: 'Gadget drops & open box',
    partner: 'Premium Electronics Store',
    platform: 'Whatnot',
    start: '11:00 AM',
    end: '1:30 PM PT',
    status: 'confirmed',
  },
  {
    id: '3',
    date: '2026-05-12',
    title: 'Spring styles try-on',
    partner: 'Fashion Forward Boutique',
    platform: 'eBay Live',
    start: '4:30 PM',
    end: '6:00 PM PT',
    status: 'tentative',
  },
  {
    id: '4',
    date: '2026-05-18',
    title: 'Vintage jewelry showcase',
    partner: 'Vintage Treasures',
    platform: 'Whatnot',
    start: '6:00 PM',
    end: '8:00 PM PT',
    status: 'tentative',
  },
];

function loadStreamsFromStorage(): StreamSlot[] {
  try {
    const raw = localStorage.getItem(STREAM_SCHEDULE_STORAGE_KEY);
    if (!raw) return DEFAULT_STREAMS;
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || parsed.length === 0) return DEFAULT_STREAMS;
    return [...(parsed as StreamSlot[])].sort((a, b) => a.date.localeCompare(b.date));
  } catch {
    return DEFAULT_STREAMS;
  }
}

function streamDayParts(isoDate: string) {
  const d = new Date(`${isoDate}T12:00:00`);
  return {
    month: d.toLocaleDateString('en-US', { month: 'short' }),
    day: d.getDate().toString(),
    weekday: d.toLocaleDateString('en-US', { weekday: 'short' }),
  };
}

const emptyForm = {
  date: '',
  title: '',
  partner: '',
  platform: '',
  start: '',
  end: '',
  status: 'confirmed' as StreamSlot['status'],
};

export function Dashboard() {
  const [streams, setStreams] = useState<StreamSlot[]>(loadStreamsFromStorage);
  const [form, setForm] = useState(emptyForm);
  const [manualCalendarOpen, setManualCalendarOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(STREAM_SCHEDULE_STORAGE_KEY, JSON.stringify(streams));
  }, [streams]);

  const addStream = (e: FormEvent) => {
    e.preventDefault();
    if (!form.date.trim() || !form.title.trim()) return;
    const slot: StreamSlot = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `manual-${Date.now()}`,
      date: form.date,
      title: form.title.trim(),
      partner: form.partner.trim() || 'Partner TBD',
      platform: form.platform.trim() || 'TBD',
      start: form.start.trim() || 'TBD',
      end: form.end.trim() || 'TBD',
      status: form.status,
    };
    setStreams((prev) => [...prev, slot].sort((a, b) => a.date.localeCompare(b.date)));
    setForm(emptyForm);
  };

  const removeStream = (id: string) => {
    setStreams((prev) => prev.filter((s) => s.id !== id));
  };

  const resetToDemo = () => {
    setStreams(DEFAULT_STREAMS);
    localStorage.removeItem(STREAM_SCHEDULE_STORAGE_KEY);
  };

  const stats = [
    { label: 'Active Connections', value: '24', icon: Users, color: 'bg-blue-500', link: '/active-connections' },
    { label: 'Pending Applications', value: '4', icon: TrendingUp, color: 'bg-green-500', link: '/application-status' },
    { label: 'Active Negotiations', value: '8', icon: DollarSign, color: 'bg-purple-500', link: '/negotiations' },
    { label: 'Average Rating', value: '4.8', icon: Star, color: 'bg-yellow-500', link: null },
  ];

  return (
    <div className="max-w-7xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <div className="mb-8">
        <h2 className="text-2xl mb-2">Welcome to ConnectIn</h2>
        <p className="text-gray-600 dark:text-gray-400">Connect with verified sellers and grow your streaming business</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const content = (
            <>
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-3xl mb-1">{stat.value}</div>
              <div className="text-gray-600 dark:text-gray-400 text-sm">{stat.label}</div>
            </>
          );

          return stat.link ? (
            <Link
              key={stat.label}
              to={stat.link}
              className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer"
            >
              {content}
            </Link>
          ) : (
            <div key={stat.label} className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6">
              {content}
            </div>
          );
        })}
      </div>

      <div className="mb-8 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Live stream schedule</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5 max-w-xl">
                Upcoming sponsored shows — demo list plus any streams you add below (saved in this browser).
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                <Link to="/active-connections" className="text-[var(--color-primary)] hover:underline font-medium">
                  Active connections
                </Link>
                <span className="text-gray-400 dark:text-gray-600"> · </span>
                <Link to="/negotiations" className="text-[var(--color-primary)] hover:underline font-medium">
                  Payment terms
                </Link>
              </p>
            </div>
          </div>
          <div className="flex shrink-0 flex-col gap-2 sm:items-end">
            <button
              type="button"
              disabled
              className="inline-flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/80 px-4 py-2.5 text-sm font-medium text-gray-400 dark:text-gray-500 cursor-not-allowed"
              title="Coming soon"
            >
              Sync to calendar (soon)
            </button>
            <p className="text-[11px] text-gray-400 text-right max-w-[200px]">
              Google / Outlook export will live here in a future release.
            </p>
          </div>
        </div>

        <div className="mt-5 border-t border-gray-100 dark:border-gray-800 pt-5 space-y-3">
          {streams.map((slot) => {
            const { month, day, weekday } = streamDayParts(slot.date);
            return (
              <div
                key={slot.id}
                className="flex flex-col gap-3 rounded-xl border border-gray-100 dark:border-gray-800 bg-gray-50/60 dark:bg-gray-900/40 p-4 sm:flex-row sm:items-center sm:gap-4"
              >
                <div className="flex h-[72px] w-[72px] shrink-0 flex-col items-center justify-center rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-950 shadow-sm">
                  <span className="text-[10px] font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">{month}</span>
                  <span className="text-2xl font-bold tabular-nums text-gray-900 dark:text-gray-100 leading-none my-0.5">{day}</span>
                  <span className="text-[11px] font-medium text-gray-500 dark:text-gray-400">{weekday}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 gap-y-1">
                    <p className="font-medium text-gray-900 dark:text-gray-100">{slot.title}</p>
                    <span
                      className={`text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full ${
                        slot.status === 'confirmed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {slot.status === 'confirmed' ? 'Confirmed' : 'Tentative'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="inline-flex flex-wrap items-center gap-2">
                      {slot.partner}
                      <SellerTierPill tier={mockSellerTierForDisplay(slot.partner, Number(slot.id))} />
                    </span>
                    <span className="text-gray-500 dark:text-gray-500">· {slot.platform}</span>
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 shrink-0 text-gray-400" />
                      {slot.start} – {slot.end}
                    </span>
                    <span className="inline-flex items-center gap-1 text-rose-600/90">
                      <Radio className="w-3.5 h-3.5 shrink-0" />
                      Live
                    </span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => removeStream(slot.id)}
                  className="self-start sm:self-center shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-950 px-3 py-2 text-xs font-medium text-gray-600 dark:text-gray-400 hover:bg-red-50 dark:hover:bg-red-950/40 hover:border-red-200 hover:text-red-700 transition-colors"
                  aria-label={`Remove ${slot.title}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remove
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-6 rounded-xl border border-dashed border-gray-200 dark:border-gray-700 bg-gray-50/80 dark:bg-gray-900/50 overflow-hidden">
          <button
            type="button"
            id="manual-calendar-toggle"
            aria-expanded={manualCalendarOpen}
            aria-controls="manual-calendar-panel"
            onClick={() => setManualCalendarOpen((o) => !o)}
            className="w-full flex items-center gap-3 p-4 sm:p-5 text-left hover:bg-gray-100/50 dark:hover:bg-gray-800/50 transition-colors"
          >
            <ChevronDown
              className={`w-5 h-5 shrink-0 text-gray-500 transition-transform duration-200 ${
                manualCalendarOpen ? 'rotate-0' : '-rotate-90'
              }`}
              aria-hidden
            />
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300">
              <Plus className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Add calendar details manually</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                {manualCalendarOpen
                  ? 'Entries are stored locally in your browser and sorted by date.'
                  : 'Expand to add streams or reset the demo list.'}
              </p>
            </div>
          </button>

          {manualCalendarOpen && (
            <div
              id="manual-calendar-panel"
              role="region"
              aria-labelledby="manual-calendar-toggle"
              className="border-t border-gray-200/80 dark:border-gray-800 px-4 pb-4 sm:px-5 sm:pb-5 pt-4"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end mb-4">
                <button
                  type="button"
                  onClick={resetToDemo}
                  className="inline-flex w-full sm:w-auto items-center justify-center gap-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-950 px-3 py-2 text-xs font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reset to demo list
                </button>
              </div>

          <form onSubmit={addStream} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Date</span>
                <input
                  type="date"
                  required
                  value={form.date}
                  onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
              <label className="block sm:col-span-2">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Stream title</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Holiday toy haul"
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Partner / seller</span>
                <input
                  type="text"
                  placeholder="Optional"
                  value={form.partner}
                  onChange={(e) => setForm((f) => ({ ...f, partner: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Platform</span>
                <input
                  type="text"
                  placeholder="e.g. Whatnot"
                  value={form.platform}
                  onChange={(e) => setForm((f) => ({ ...f, platform: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Status</span>
                <select
                  value={form.status}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, status: e.target.value as StreamSlot['status'] }))
                  }
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                >
                  <option value="confirmed">Confirmed</option>
                  <option value="tentative">Tentative</option>
                </select>
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Start time</span>
                <input
                  type="text"
                  placeholder="e.g. 2:00 PM"
                  value={form.start}
                  onChange={(e) => setForm((f) => ({ ...f, start: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">End time</span>
                <input
                  type="text"
                  placeholder="e.g. 4:00 PM PT"
                  value={form.end}
                  onChange={(e) => setForm((f) => ({ ...f, end: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 dark:bg-gray-950 shadow-sm focus:border-[var(--color-primary)] focus:ring-1 focus:ring-[var(--color-primary)]"
                />
              </label>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--color-primary)] px-4 py-2.5 text-sm font-medium text-white hover:opacity-90 transition-opacity"
              >
                <Plus className="w-4 h-4" />
                Add to schedule
              </button>
              <span className="text-xs text-gray-400">Requires date and title.</span>
            </div>
          </form>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6">
          <h3 className="text-lg mb-4 dark:text-gray-100">Quick Actions</h3>
          <div className="space-y-3">
            <Link
              to="/discover"
              className="block bg-[var(--color-primary)] text-white px-4 py-3 rounded hover:opacity-90 transition-opacity text-center"
            >
              Discover New Sellers
            </Link>
            <Link
              to="/application-status"
              className="block border-2 border-[var(--color-primary)] text-[var(--color-primary)] px-4 py-3 rounded hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-center"
            >
              Track RFLS status
            </Link>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6">
          <h3 className="text-lg mb-4 dark:text-gray-100">Recent Activity</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3 pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
              <div>
                <p className="text-sm dark:text-gray-200">RFLS approved by Sports Gear Pro</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3 pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
              <div>
                <p className="text-sm dark:text-gray-200">Counter offer sent to Premium Electronics</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">5 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 mt-2"></div>
              <div>
                <p className="text-sm dark:text-gray-200">New RFLS submitted to Fashion Forward Boutique</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">1 day ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
