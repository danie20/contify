import { useMemo, useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router';
import { BadgeCheck, DollarSign, Calendar, TrendingUp, MessageCircle, Send, CheckCircle, XCircle, AlertTriangle, Paperclip, FileText, Image, X, Download, AlertCircle, LayoutGrid } from 'lucide-react';
import type { Negotiation } from './negotiationMockData';
import { SellerTierPill } from './SellerTierBadge';
import { mockSellerTierForDisplay } from './sellerTierMock';
import {
  INFLUENCER_NEGOTIATIONS,
  SELLER_SPORTS_GEAR_NEGOTIATIONS,
} from './negotiationMockData';

type ActionType = 'accept' | 'counter' | 'decline' | null;

export function Negotiations({ mode = 'influencer' }: { mode?: 'influencer' | 'seller' }) {
  const navigate = useNavigate();
  const isSeller = mode === 'seller';
  const negotiations = useMemo(
    () => (isSeller ? SELLER_SPORTS_GEAR_NEGOTIATIONS : INFLUENCER_NEGOTIATIONS),
    [isSeller],
  );
  const selfSender: 'influencer' | 'seller' = isSeller ? 'seller' : 'influencer';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedNegotiation, setSelectedNegotiation] = useState<Negotiation | null>(
    () => (isSeller ? SELLER_SPORTS_GEAR_NEGOTIATIONS[0] : INFLUENCER_NEGOTIATIONS[1]) ?? null,
  );
  const [newMessage, setNewMessage] = useState('');
  const [showActionModal, setShowActionModal] = useState(false);
  const [actionType, setActionType] = useState<ActionType>(null);
  const [counterOfferAmount, setCounterOfferAmount] = useState('');
  const [declineReason, setDeclineReason] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setAttachments([...attachments, ...files]);
    }
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleSendMessage = () => {
    if ((newMessage.trim() || attachments.length > 0) && selectedNegotiation) {
      // In real app, would send message with attachments to server
      setNewMessage('');
      setAttachments([]);
    }
  };

  const getFileIcon = (type: string) => {
    const lowerType = type.toLowerCase();
    if (lowerType === 'pdf' || lowerType.includes('pdf')) return FileText;
    if (lowerType === 'image' || lowerType.startsWith('image/')) return Image;
    return FileText;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleActionClick = (type: ActionType) => {
    setActionType(type);
    if (type === 'counter' && selectedNegotiation) {
      setCounterOfferAmount(selectedNegotiation.counterRate?.toString() || selectedNegotiation.proposedRate.toString());
    }
    setShowActionModal(true);
  };

  const handleConfirmAction = () => {
    const afterPath = isSeller ? '/seller/invites' : '/application-status';
    if (actionType === 'accept') {
      navigate(afterPath);
    } else if (actionType === 'counter') {
      setShowActionModal(false);
      setActionType(null);
      setCounterOfferAmount('');
    } else if (actionType === 'decline') {
      navigate(afterPath);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'active':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const ringClass = isSeller ? 'ring-2 ring-emerald-600' : 'ring-2 ring-[var(--color-primary)]';

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div
        className={`mb-4 rounded-lg border px-4 py-3 text-sm ${
          isSeller
            ? 'border-emerald-200 bg-emerald-50 text-emerald-950'
            : 'border-blue-200 bg-blue-50 text-blue-950'
        }`}
      >
        {isSeller ? (
          <>
            <strong className="font-semibold">Same workflow, creator view:</strong> open the influencer app’s{' '}
            <Link to="/negotiations" className="underline font-medium">
              Payment negotiations
            </Link>{' '}
            to see the mirrored thread (mock data is separate per side for this demo).
          </>
        ) : (
          <>
            <strong className="font-semibold">Seller mirror:</strong> Sports Gear Pro (and other sellers) manage
            payment terms in the{' '}
            <Link to="/seller/negotiations" className="underline font-medium">
              seller portal → Payment negotiations
            </Link>
            .
          </>
        )}
      </div>

      <div className="mb-6">
        <h2 className="text-2xl mb-2">Payment negotiations</h2>
        <p className="text-gray-600">
          {isSeller
            ? 'Agree rates and structure with creators you invited (Sports Gear Pro mock).'
            : 'Manage your payment terms with sellers.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-3">
            {isSeller ? 'Creators in negotiation' : 'Active negotiations'}
          </h3>
          {negotiations.map((negotiation) => (
            <div
              key={negotiation.id}
              onClick={() => setSelectedNegotiation(negotiation)}
              className={`bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-4 cursor-pointer transition-all ${
                selectedNegotiation?.id === negotiation.id ? ringClass : 'hover:shadow-md'
              }`}
            >
              <div className="flex items-start gap-3 mb-2">
                <img
                  src={isSeller ? negotiation.influencerAvatar : negotiation.sellerAvatar}
                  alt={isSeller ? negotiation.influencerName : negotiation.sellerName}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-x-1 gap-y-1 mb-1">
                    <h4 className="text-sm truncate">
                      {isSeller ? negotiation.influencerName : negotiation.sellerName}
                    </h4>
                    {(isSeller ? true : negotiation.sellerVerified) && (
                      <BadgeCheck className="w-4 h-4 text-blue-500 flex-shrink-0" />
                    )}
                    {!isSeller && (
                      <SellerTierPill tier={mockSellerTierForDisplay(negotiation.sellerName, negotiation.id)} />
                    )}
                  </div>
                  {!isSeller && (
                    <span
                      className={`text-xs px-2 py-1 rounded ${getStatusColor(negotiation.status)}`}
                    >
                      {negotiation.status.charAt(0).toUpperCase() + negotiation.status.slice(1)}
                    </span>
                  )}
                  {isSeller && (
                    <p className="text-xs text-emerald-700 truncate">{negotiation.influencerHandle}</p>
                  )}
                  {isSeller && (
                    <span
                      className={`inline-block mt-1 text-xs px-2 py-1 rounded ${getStatusColor(negotiation.status)}`}
                    >
                      {negotiation.status.charAt(0).toUpperCase() + negotiation.status.slice(1)}
                    </span>
                  )}
                </div>
              </div>
              <div className="text-sm text-gray-600 mt-2">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  <span>${negotiation.proposedRate}/stream</span>
                </div>
              </div>
              {negotiation.needsInfo && (
                <div className="mt-2 flex items-center gap-1 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                  <AlertCircle className="w-3 h-3" />
                  <span>Info Needed</span>
                </div>
              )}
              {negotiation.rflsId && (
                <div className="mt-2 text-xs text-gray-500">
                  RFLS-{negotiation.rflsId.toString().padStart(5, '0')}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="lg:col-span-2">
          {selectedNegotiation ? (
            <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow">
              <div className="border-b border-gray-200 p-4">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={isSeller ? selectedNegotiation.influencerAvatar : selectedNegotiation.sellerAvatar}
                      alt={isSeller ? selectedNegotiation.influencerName : selectedNegotiation.sellerName}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h3>
                          {isSeller ? selectedNegotiation.influencerName : selectedNegotiation.sellerName}
                        </h3>
                        {(isSeller || selectedNegotiation.sellerVerified) && (
                          <BadgeCheck className="w-5 h-5 text-blue-500" />
                        )}
                        {!isSeller && (
                          <SellerTierPill
                            tier={mockSellerTierForDisplay(
                              selectedNegotiation.sellerName,
                              selectedNegotiation.id,
                            )}
                          />
                        )}
                      </div>
                      {isSeller && (
                        <p className="text-sm text-emerald-700 mt-0.5">{selectedNegotiation.influencerHandle}</p>
                      )}
                      <span
                        className={`inline-block mt-1 text-xs px-2 py-1 rounded ${getStatusColor(
                          selectedNegotiation.status,
                        )}`}
                      >
                        {selectedNegotiation.status.charAt(0).toUpperCase() +
                          selectedNegotiation.status.slice(1)}
                      </span>
                    </div>
                  </div>
                  {selectedNegotiation.rflsId && (
                    <div className="flex flex-wrap items-center justify-end gap-2 shrink-0">
                      <Link
                        to={
                          isSeller
                            ? `/seller/collab/${selectedNegotiation.rflsId}`
                            : `/collab/${selectedNegotiation.rflsId}`
                        }
                        className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-semibold text-white shadow-sm ${
                          isSeller ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-violet-600 hover:bg-violet-700'
                        }`}
                      >
                        <LayoutGrid className="w-4 h-4" />
                        Collab room
                      </Link>
                      <button
                        type="button"
                        onClick={() => navigate(isSeller ? '/seller/invites' : '/application-status')}
                        className={`text-sm hover:underline ${
                          isSeller ? 'text-emerald-700' : 'text-[var(--color-primary)]'
                        }`}
                      >
                        {isSeller ? 'View invite / RFLS context →' : 'View RFLS status →'}
                      </button>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="flex items-center gap-2 text-gray-600 mb-1">
                      <DollarSign className="w-4 h-4" />
                      <span className="text-sm">{isSeller ? 'Latest on table' : 'Your rate'}</span>
                    </div>
                    <div className="text-xl">${selectedNegotiation.counterRate || selectedNegotiation.proposedRate}</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="flex items-center gap-2 text-gray-600 mb-1">
                      <TrendingUp className="w-4 h-4" />
                      <span className="text-sm">Payment Type</span>
                    </div>
                    <div className="text-sm">{selectedNegotiation.paymentType}</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="flex items-center gap-2 text-gray-600 mb-1">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm">Start Date</span>
                    </div>
                    <div className="text-sm">{selectedNegotiation.startDate}</div>
                  </div>
                </div>

                {selectedNegotiation.needsInfo && selectedNegotiation.infoRequest && (
                  <div className="mt-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-1">
                          {isSeller ? 'Your information request' : 'Information requested by seller'}
                        </h4>
                        <p className="text-sm text-gray-700 mb-3">{selectedNegotiation.infoRequest}</p>
                        {isSeller ? (
                          <p className="text-xs text-yellow-800">
                            Waiting on {selectedNegotiation.influencerName}. You can add a nudge in the message box
                            below or set a follow-up from{' '}
                            <Link to="/seller/reminders" className="underline font-medium">
                              Reminders
                            </Link>
                            .
                          </p>
                        ) : (
                          <>
                            <div className="bg-white dark:bg-gray-950 border border-yellow-300 dark:border-yellow-700 rounded p-3 mb-3">
                              <p className="text-xs text-gray-600 mb-2">💡 Quick response template:</p>
                              <ul className="text-xs text-gray-700 space-y-1 list-disc list-inside">
                                <li>Attach portfolio/analytics PDFs</li>
                                <li>Include screenshot evidence</li>
                                <li>Provide specific metrics & numbers</li>
                                <li>Reference previous partnerships</li>
                              </ul>
                            </div>
                            <p className="text-xs text-yellow-700">
                              💡 Use the message box below to respond and attach your supporting documents (PDFs,
                              images, reports).
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 h-96 overflow-y-auto">
                {selectedNegotiation.messages.length > 0 ? (
                  <div className="space-y-4">
                    {selectedNegotiation.messages.map((message) => {
                      const fromSelf = message.sender === selfSender;
                      return (
                      <div
                        key={message.id}
                        className={`flex ${fromSelf ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-md ${
                            fromSelf
                              ? isSeller
                                ? 'bg-emerald-600 text-white'
                                : 'bg-[var(--color-primary)] text-white'
                              : message.isInfoRequest
                              ? 'bg-yellow-50 border-2 border-yellow-300'
                              : 'bg-gray-100'
                          } rounded-lg p-3`}
                        >
                          {message.isInfoRequest && (
                            <div className="flex items-center gap-2 mb-2">
                              <AlertCircle className="w-4 h-4 text-yellow-600" />
                              <span className="text-xs bg-yellow-200 text-yellow-800 px-2 py-0.5 rounded">
                                Info Request
                              </span>
                            </div>
                          )}
                          {message.isOffer && (
                            <div className="flex items-center gap-2 mb-2 text-sm">
                              <DollarSign className="w-4 h-4" />
                              <span>Offer: ${message.offerAmount}/stream</span>
                            </div>
                          )}
                          <p className="text-sm">{message.content}</p>

                          {message.attachments && message.attachments.length > 0 && (
                            <div className="mt-3 space-y-2">
                              {message.attachments.map((attachment) => {
                                const Icon = getFileIcon(attachment.type);
                                return (
                                  <div
                                    key={attachment.id}
                                    className={`flex items-center gap-3 p-2 rounded ${
                                      fromSelf
                                        ? isSeller
                                          ? 'bg-white/20'
                                          : 'bg-white/20'
                                        : 'bg-white border border-gray-200'
                                    }`}
                                  >
                                    {attachment.type === 'image' ? (
                                      <img
                                        src={attachment.url}
                                        alt={attachment.name}
                                        className="w-12 h-12 rounded object-cover"
                                      />
                                    ) : (
                                      <div
                                        className={`w-10 h-10 rounded flex items-center justify-center ${
                                          fromSelf ? 'bg-white/30' : 'bg-gray-100'
                                        }`}
                                      >
                                        <Icon className="w-5 h-5" />
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <p className="text-xs truncate">{attachment.name}</p>
                                      <p
                                        className={`text-xs ${
                                          fromSelf ? 'text-white/70' : 'text-gray-500'
                                        }`}
                                      >
                                        {attachment.size}
                                      </p>
                                    </div>
                                    <a
                                      href={attachment.url}
                                      download={attachment.name}
                                      className={`p-1 rounded hover:bg-white/20 transition-colors`}
                                    >
                                      <Download className="w-4 h-4" />
                                    </a>
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          <p
                            className={`text-xs mt-2 ${
                              fromSelf ? 'text-white/70' : 'text-gray-500'
                            }`}
                          >
                            {message.timestamp}
                          </p>
                        </div>
                      </div>
                    );
                    })}
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <div className="text-center">
                      <MessageCircle className="w-12 h-12 mx-auto mb-2" />
                      <p>No messages yet. Start the conversation!</p>
                    </div>
                  </div>
                )}
              </div>

              {selectedNegotiation.status !== 'accepted' && selectedNegotiation.status !== 'declined' && (
                <div className="border-t border-gray-200 p-4">
                  {attachments.length > 0 && (
                    <div className="mb-3 p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2 text-sm text-gray-600">
                        <Paperclip className="w-4 h-4" />
                        <span>Attachments ({attachments.length})</span>
                      </div>
                      <div className="space-y-2">
                        {attachments.map((file, index) => {
                          const Icon = getFileIcon(file.type);
                          return (
                            <div
                              key={index}
                              className="flex items-center gap-3 p-2 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-700 rounded"
                            >
                              <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center">
                                <Icon className="w-4 h-4 text-gray-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm truncate">{file.name}</p>
                                <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                              </div>
                              <button
                                onClick={() => handleRemoveAttachment(index)}
                                className="p-1 hover:bg-gray-100 rounded transition-colors"
                              >
                                <X className="w-4 h-4 text-gray-500" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  <div className="flex gap-2 mb-3">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                      title="Attach files"
                    >
                      <Paperclip className="w-5 h-5 text-gray-600" />
                    </button>
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder={
                        isSeller
                          ? 'Message the creator (rates, logistics, counter details)…'
                          : 'Type your message… (attach documents, images, or PDFs)'
                      }
                      className={`flex-1 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 ${
                        isSeller ? 'focus:ring-emerald-600' : 'focus:ring-[var(--color-primary)]'
                      }`}
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() && attachments.length === 0}
                      className={`text-white px-4 py-2 rounded hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed ${
                        isSeller ? 'bg-emerald-600' : 'bg-[var(--color-primary)]'
                      }`}
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">
                    {isSeller
                      ? '💡 Share rate cards, bundle sheets, or policy PDFs — same negotiation thread the creator sees in their app.'
                      : '💡 Attach portfolio PDFs, analytics reports, or screenshots to support your negotiation'}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleActionClick('accept')}
                      className="flex-1 bg-green-500 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm flex items-center justify-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Accept Terms
                    </button>
                    <button
                      onClick={() => handleActionClick('counter')}
                      className="flex-1 bg-yellow-500 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm flex items-center justify-center gap-2"
                    >
                      <DollarSign className="w-4 h-4" />
                      Counter Offer
                    </button>
                    <button
                      onClick={() => handleActionClick('decline')}
                      className="flex-1 bg-red-500 text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm flex items-center justify-center gap-2"
                    >
                      <XCircle className="w-4 h-4" />
                      Decline
                    </button>
                  </div>
                </div>
              )}

              {selectedNegotiation.status === 'accepted' && (
                <div className="border-t border-gray-200 p-4 bg-green-50">
                  <div className="flex items-center gap-3 text-green-800">
                    <CheckCircle className="w-5 h-5" />
                    <p className="text-sm">
                      {isSeller
                        ? 'You accepted these terms. A draft contract will be generated for you and the creator (mock).'
                        : 'You have accepted this proposal. Contract details will be sent to your email.'}
                    </p>
                  </div>
                </div>
              )}

              {selectedNegotiation.status === 'declined' && (
                <div className="border-t border-gray-200 p-4 bg-red-50">
                  <div className="flex items-center gap-3 text-red-800">
                    <XCircle className="w-5 h-5" />
                    <p className="text-sm">
                      {isSeller
                        ? 'You declined this proposal. The creator is notified in their negotiation thread (mock).'
                        : 'You have declined this proposal.'}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-8 text-center text-gray-400">
              <MessageCircle className="w-16 h-16 mx-auto mb-4" />
              <p>Select a negotiation to view details</p>
            </div>
          )}
        </div>
      </div>

      {showActionModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow-xl max-w-md w-full p-6">
            {actionType === 'accept' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="text-xl">Accept Proposal</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  {isSeller
                    ? 'Accepting locks the current terms for this mock flow and returns you to invites so you can track next steps.'
                    : 'Are you sure you want to accept this proposal? This will update your RFLS status to "Approved" and proceed with contract signing.'}
                </p>
                <div className="bg-gray-50 p-4 rounded mb-6">
                  <div className="text-sm text-gray-600 mb-2">Agreement details</div>
                  <div className="space-y-1 text-sm">
                    <p>
                      <strong>{isSeller ? 'Creator:' : 'Seller:'}</strong>{' '}
                      {isSeller ? selectedNegotiation?.influencerName : selectedNegotiation?.sellerName}
                    </p>
                    {isSeller && (
                      <>
                        <p>
                          <strong>Handle:</strong> {selectedNegotiation?.influencerHandle}
                        </p>
                        <p>
                          <strong>Your store:</strong> {selectedNegotiation?.sellerName}
                        </p>
                      </>
                    )}
                    <p><strong>Rate:</strong> ${selectedNegotiation?.counterRate || selectedNegotiation?.proposedRate}/stream</p>
                    <p><strong>Payment Type:</strong> {selectedNegotiation?.paymentType}</p>
                    <p><strong>Start Date:</strong> {selectedNegotiation?.startDate}</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowActionModal(false);
                      setActionType(null);
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmAction}
                    className="flex-1 px-4 py-2 bg-green-500 text-white rounded hover:opacity-90"
                  >
                    Confirm Accept
                  </button>
                </div>
              </>
            )}

            {actionType === 'counter' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-yellow-600" />
                  </div>
                  <h3 className="text-xl">Submit Counter Offer</h3>
                </div>
                <p className="text-gray-600 mb-4">
                  Enter your counter offer amount and provide a justification.
                </p>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm mb-2">Counter Offer Amount ($)</label>
                    <input
                      type="number"
                      value={counterOfferAmount}
                      onChange={(e) => setCounterOfferAmount(e.target.value)}
                      placeholder="200"
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2">Justification</label>
                    <textarea
                      rows={3}
                      placeholder="Explain why this rate is more appropriate..."
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                    />
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowActionModal(false);
                      setActionType(null);
                      setCounterOfferAmount('');
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmAction}
                    className="flex-1 px-4 py-2 bg-yellow-500 text-white rounded hover:opacity-90"
                  >
                    Send Counter Offer
                  </button>
                </div>
              </>
            )}

            {actionType === 'decline' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <XCircle className="w-6 h-6 text-red-600" />
                  </div>
                  <h3 className="text-xl">Decline Proposal</h3>
                </div>
                <p className="text-gray-600 mb-4">
                  {isSeller
                    ? 'Declining will end this negotiation thread for the mock demo and notify the creator’s view.'
                    : 'Are you sure you want to decline this proposal? This action will update your RFLS status.'}
                </p>
                <div className="mb-6">
                  <label className="block text-sm mb-2">Reason for Declining (Optional)</label>
                  <textarea
                    value={declineReason}
                    onChange={(e) => setDeclineReason(e.target.value)}
                    rows={3}
                    placeholder={isSeller ? 'Optional feedback to the creator…' : 'Provide feedback to the seller…'}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                  />
                </div>
                <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mb-6 flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">
                    {isSeller
                      ? 'This will notify the creator and close this negotiation thread.'
                      : 'This will notify the seller and close this negotiation thread.'}
                  </p>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowActionModal(false);
                      setActionType(null);
                      setDeclineReason('');
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmAction}
                    className="flex-1 px-4 py-2 bg-red-500 text-white rounded hover:opacity-90"
                  >
                    Confirm Decline
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
