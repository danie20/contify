import { Link } from 'react-router';
import { ArrowLeft, Heart, Trash2, Send } from 'lucide-react';
import { useSellerWorkspace } from './SellerWorkspaceContext';

export function SellerFavoritesPage() {
  const { favorites, updateFavoriteNote, removeFavorite, hasActiveInviteTo } = useSellerWorkspace();

  return (
    <div className="max-w-7xl mx-auto p-6">
      <Link
        to="/seller"
        className="inline-flex items-center gap-2 text-emerald-800 hover:underline text-sm font-medium mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to workspace
      </Link>

      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">Favorite creators</h2>
        <p className="text-gray-600 max-w-2xl">
          Shortlist influencers for future campaigns. Notes are private to this mock session. Remove a favorite or jump
          to send an invite when you are ready.
        </p>
      </div>

      {favorites.length === 0 ? (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-dashed border-gray-200 dark:border-gray-700 p-12 text-center">
          <Heart className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-600 mb-4">No saved creators yet.</p>
          <Link
            to="/seller/find-influencers"
            className="text-emerald-700 font-medium hover:underline"
          >
            Browse directory and tap the heart on a card
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {favorites.map((f) => {
            const hasActive = hasActiveInviteTo(f.influencerId);
            return (
              <div
                key={f.influencerId}
                className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 flex flex-col gap-4"
              >
                <div className="flex gap-4">
                  <img
                    src={f.avatar}
                    alt=""
                    className="w-14 h-14 rounded-full object-cover border border-gray-100 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-gray-900">{f.displayName}</h3>
                    <p className="text-sm text-emerald-700">{f.handle}</p>
                    <p className="text-sm text-gray-600 mt-1">{f.niche}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeFavorite(f.influencerId)}
                    className="text-gray-400 hover:text-red-600 p-2 rounded-lg hover:bg-red-50 shrink-0"
                    title="Remove from favorites"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1">Internal note</label>
                  <textarea
                    value={f.note}
                    onChange={(e) => updateFavoriteNote(f.influencerId, e.target.value)}
                    placeholder="Why we like them, fit, rate expectations…"
                    rows={3}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 resize-none"
                  />
                </div>
                <div className="flex gap-2 pt-1">
                  <Link
                    to="/seller/find-influencers"
                    className="flex-1 text-center py-2.5 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    View in directory
                  </Link>
                  {hasActive ? (
                    <span className="flex-1 text-center py-2.5 rounded-lg bg-gray-100 text-sm text-gray-500 cursor-default">
                      Invite in progress
                    </span>
                  ) : (
                    <Link
                      to="/seller/find-influencers"
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
                    >
                      <Send className="w-4 h-4" />
                      Send invite
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
