import { useState } from 'react';
import {
  User,
  Camera,
  Check,
  Crown,
  Star,
  Zap,
  TrendingUp,
  MessageSquare,
  Shield,
  Award,
} from 'lucide-react';

type OnboardingStep = 'profile' | 'subscription' | 'complete';

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  interval: string;
  icon: typeof Crown;
  color: string;
  features: string[];
  recommended?: boolean;
}

const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'basic',
    name: 'Basic',
    price: 0,
    interval: 'month',
    icon: User,
    color: 'gray',
    features: [
      'Up to 5 seller connections',
      'Basic analytics',
      'Email support',
      'Monthly payment processing',
    ],
  },
  {
    id: 'pro',
    name: 'Professional',
    price: 29,
    interval: 'month',
    icon: Star,
    color: 'blue',
    recommended: true,
    features: [
      'Unlimited seller connections',
      'Advanced analytics & insights',
      'Priority support',
      'Weekly payment processing',
      'Featured profile listing',
      'Negotiation templates',
    ],
  },
  {
    id: 'elite',
    name: 'Elite',
    price: 99,
    interval: 'month',
    icon: Crown,
    color: 'purple',
    features: [
      'Everything in Professional',
      'Dedicated account manager',
      '24/7 priority support',
      'Daily payment processing',
      'Premium badge',
      'Exclusive seller partnerships',
      'Custom contract templates',
      'Revenue optimization insights',
    ],
  },
];

export function InfluencerOnboarding() {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('profile');
  const [selectedPlan, setSelectedPlan] = useState<string>('pro');
  const [profileData, setProfileData] = useState({
    displayName: '',
    bio: '',
    profileImage: '',
    specialties: [] as string[],
  });

  const specialtyOptions = [
    'Product Reviews',
    'Unboxing',
    'Fashion Hauls',
    'Tech Demos',
    'Collectibles',
    'Live Sales',
    'Q&A Sessions',
    'Tutorial Streams',
  ];

  const handleSpecialtyToggle = (specialty: string) => {
    setProfileData({
      ...profileData,
      specialties: profileData.specialties.includes(specialty)
        ? profileData.specialties.filter((s) => s !== specialty)
        : [...profileData.specialties, specialty],
    });
  };

  const handleProfileSubmit = () => {
    setCurrentStep('subscription');
  };

  const handleSubscriptionComplete = () => {
    setCurrentStep('complete');
  };

  if (currentStep === 'complete') {
    return (
      <div className="max-w-3xl mx-auto p-6">
        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl mb-2">Welcome to ConnectIn!</h2>
          <p className="text-gray-600 mb-6">
            Your profile has been created and you're all set to start connecting with sellers.
          </p>
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="text-lg mb-4">Next Steps</h3>
            <div className="space-y-3 text-left">
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <p className="text-sm">Complete your profile details</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm">Browse and connect with verified sellers</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MessageSquare className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <p className="text-sm">Start negotiating payment terms</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="text-sm">Submit applications to streaming platforms</p>
                </div>
              </div>
            </div>
          </div>
          <button
            onClick={() => (window.location.href = '/')}
            className="bg-[var(--color-primary)] text-white px-8 py-3 rounded hover:opacity-90 transition-opacity"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (currentStep === 'subscription') {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-8 text-center">
          <h2 className="text-2xl mb-2">Choose Your Membership Plan</h2>
          <p className="text-gray-600">Select the plan that best fits your influencer journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {subscriptionPlans.map((plan) => {
            const Icon = plan.icon;
            const isSelected = selectedPlan === plan.id;
            const colorClasses = {
              gray: 'border-gray-300',
              blue: 'border-blue-500',
              purple: 'border-purple-500',
            };

            return (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className={`bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow-lg cursor-pointer transition-all ${
                  isSelected ? `ring-4 ring-${plan.color}-500/50` : ''
                } ${plan.recommended ? 'border-2 border-blue-500' : 'border-2 border-transparent'}`}
              >
                {plan.recommended && (
                  <div className="bg-blue-500 text-white text-center py-1 text-sm rounded-t-lg">
                    Recommended
                  </div>
                )}
                <div className="p-6">
                  <div
                    className={`w-12 h-12 bg-${plan.color}-100 rounded-lg flex items-center justify-center mb-4`}
                  >
                    <Icon className={`w-6 h-6 text-${plan.color}-600`} />
                  </div>
                  <h3 className="text-xl mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-3xl">${plan.price}</span>
                    <span className="text-gray-500">/{plan.interval}</span>
                  </div>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    className={`w-full py-2 rounded transition-all ${
                      isSelected
                        ? 'bg-[var(--color-primary)] text-white'
                        : 'border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {isSelected ? 'Selected' : 'Select Plan'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-between">
          <button
            onClick={() => setCurrentStep('profile')}
            className="px-6 py-3 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
          >
            Back
          </button>
          <button
            onClick={handleSubscriptionComplete}
            className="bg-[var(--color-primary)] text-white px-8 py-3 rounded hover:opacity-90 transition-opacity"
          >
            Complete Setup
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-2xl mb-2">Create Your Influencer Profile</h2>
        <p className="text-gray-600">Let sellers know who you are and what you specialize in</p>
      </div>

      <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-6">
        <div>
          <label className="block text-sm mb-2">Profile Picture</label>
          <div className="flex items-center gap-4">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              {profileData.profileImage ? (
                <img
                  src={profileData.profileImage}
                  alt="Profile"
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <User className="w-12 h-12 text-gray-400" />
              )}
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
              <Camera className="w-4 h-4" />
              Upload Photo
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm mb-2">
            Display Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={profileData.displayName}
            onChange={(e) => setProfileData({ ...profileData, displayName: e.target.value })}
            placeholder="How you want sellers to see you"
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
          />
        </div>

        <div>
          <label className="block text-sm mb-2">
            Bio <span className="text-red-500">*</span>
          </label>
          <textarea
            value={profileData.bio}
            onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
            rows={4}
            placeholder="Tell sellers about your streaming style, audience, and what makes you unique..."
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
          />
          <p className="text-sm text-gray-500 mt-1">
            {profileData.bio.length}/500 characters
          </p>
        </div>

        <div>
          <label className="block text-sm mb-2">
            Stream Specialties <span className="text-red-500">*</span>
          </label>
          <p className="text-sm text-gray-500 mb-3">Select all that apply</p>
          <div className="grid grid-cols-2 gap-3">
            {specialtyOptions.map((specialty) => (
              <label
                key={specialty}
                className={`flex items-center gap-3 p-3 border-2 rounded cursor-pointer transition-all ${
                  profileData.specialties.includes(specialty)
                    ? 'border-[var(--color-primary)] bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <input
                  type="checkbox"
                  checked={profileData.specialties.includes(specialty)}
                  onChange={() => handleSpecialtyToggle(specialty)}
                  className="w-4 h-4"
                />
                <span className="text-sm">{specialty}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="text-sm mb-1">Profile Verification</h4>
              <p className="text-sm text-gray-600">
                After completing your profile, you'll be able to verify your identity and social
                media accounts to build trust with sellers.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button className="px-6 py-3 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            Save Draft
          </button>
          <button
            onClick={handleProfileSubmit}
            disabled={!profileData.displayName || !profileData.bio || profileData.specialties.length === 0}
            className="bg-[var(--color-primary)] text-white px-8 py-3 rounded hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue to Membership
          </button>
        </div>
      </div>
    </div>
  );
}
