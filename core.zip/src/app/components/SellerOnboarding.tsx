import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Check,
  CreditCard,
  Globe,
  Layers,
  Package,
  Plus,
  Radio,
  Shield,
  Sparkles,
  Store,
  Target,
  Users,
} from 'lucide-react';

export const SELLER_ONBOARDING_STORAGE_KEY = 'ic-seller-onboarding-complete';

export function isSellerOnboardingComplete() {
  try {
    return localStorage.getItem(SELLER_ONBOARDING_STORAGE_KEY) === 'true';
  } catch {
    return false;
  }
}

type StepId = 'tier' | 'profile' | 'operations' | 'goals' | 'membership' | 'review';

export type BusinessTier = 'consumer' | 'small' | 'mid' | 'large';

/** Saved when onboarding completes; drives seller tier badging in the app shell. */
export type StoredSellerMembership = {
  tier: BusinessTier;
  billingInterval: 'monthly' | 'annual';
  amountUsd: number;
  updatedAt?: string;
};

export function getStoredSellerMembership(): StoredSellerMembership | null {
  try {
    const raw = localStorage.getItem(SELLER_MEMBERSHIP_STORAGE_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw) as Partial<StoredSellerMembership>;
    if (o.tier !== 'consumer' && o.tier !== 'small' && o.tier !== 'mid' && o.tier !== 'large') return null;
    if (o.billingInterval !== 'monthly' && o.billingInterval !== 'annual') return null;
    if (typeof o.amountUsd !== 'number' || !Number.isFinite(o.amountUsd)) return null;
    return {
      tier: o.tier,
      billingInterval: o.billingInterval,
      amountUsd: o.amountUsd,
      updatedAt: typeof o.updatedAt === 'string' ? o.updatedAt : undefined,
    };
  } catch {
    return null;
  }
}

/** Short label + pill styles for the tier badge (trend-forward naming + gradients). */
export function getSellerTierBadgeDisplay(tier: BusinessTier) {
  const label: Record<BusinessTier, string> = {
    consumer: 'Solo',
    small: 'Studio',
    mid: 'Pro',
    large: 'Elite',
  };
  const className: Record<BusinessTier, string> = {
    consumer:
      'bg-gradient-to-br from-zinc-100 to-zinc-200/90 text-zinc-900 ring-1 ring-zinc-300/70 shadow-sm dark:from-zinc-800 dark:to-zinc-900 dark:text-zinc-100 dark:ring-zinc-600/60',
    small:
      'bg-gradient-to-br from-sky-400/25 via-cyan-400/20 to-teal-400/25 text-teal-950 ring-1 ring-teal-400/45 shadow-sm dark:from-sky-900/50 dark:via-cyan-950/40 dark:to-teal-950/50 dark:text-cyan-50 dark:ring-teal-500/35',
    mid: 'bg-gradient-to-br from-emerald-400/30 via-teal-400/25 to-emerald-500/20 text-emerald-950 ring-1 ring-emerald-400/50 shadow-sm dark:from-emerald-900/55 dark:to-teal-950/50 dark:text-emerald-50 dark:ring-emerald-500/40',
    large:
      'bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 text-white ring-0 shadow-md shadow-fuchsia-500/30 dark:from-violet-500 dark:via-fuchsia-600 dark:to-pink-500 dark:shadow-fuchsia-500/25',
  };
  return { shortLabel: label[tier], className: className[tier] };
}

/** Monthly membership by business tier (USD). */
export const SELLER_MEMBERSHIP_MONTHLY_USD: Record<BusinessTier, number> = {
  consumer: 49,
  small: 199,
  mid: 499,
  large: 999,
};

/** Annual membership for tiers that offer it (USD). Mid/large only. */
export const SELLER_MEMBERSHIP_ANNUAL_USD: Partial<Record<BusinessTier, number>> = {
  mid: 4999,
  large: 9999,
};

export const SELLER_MEMBERSHIP_STORAGE_KEY = 'ic-seller-membership';

/** Full onboarding snapshot saved when the flow completes (demo — browser localStorage). */
export const SELLER_ONBOARDING_SNAPSHOT_KEY = 'ic-seller-onboarding-snapshot';

function formatUsd(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

function getMembershipChargeUsd(t: BusinessTier | null, interval: 'monthly' | 'annual'): number | null {
  if (!t) return null;
  if (interval === 'annual') {
    const y = SELLER_MEMBERSHIP_ANNUAL_USD[t];
    return y ?? null;
  }
  return SELLER_MEMBERSHIP_MONTHLY_USD[t];
}

/** Resolved plan for storage / review (consumer & small are always monthly). */
export function resolveSellerMembership(
  tier: BusinessTier | null,
  preferAnnual: boolean,
): { interval: 'monthly' | 'annual'; amountUsd: number } | null {
  if (!tier) return null;
  if (tier === 'consumer' || tier === 'small') {
    return { interval: 'monthly', amountUsd: SELLER_MEMBERSHIP_MONTHLY_USD[tier] };
  }
  if (preferAnnual) {
    const y = SELLER_MEMBERSHIP_ANNUAL_USD[tier];
    if (y != null) return { interval: 'annual', amountUsd: y };
  }
  return { interval: 'monthly', amountUsd: SELLER_MEMBERSHIP_MONTHLY_USD[tier] };
}

const tierCards: {
  id: BusinessTier;
  title: string;
  subtitle: string;
}[] = [
  {
    id: 'consumer',
    title: 'Individual / consumer seller',
    subtitle: 'Side hustle, closet sales, garage or event sales',
  },
  {
    id: 'small',
    title: 'Small retailer',
    subtitle: 'Tight team, one or two marketplaces',
  },
  {
    id: 'mid',
    title: 'Mid-market',
    subtitle: 'Dedicated ecommerce + live commerce team',
  },
  {
    id: 'large',
    title: 'Large / enterprise',
    subtitle: 'Multi-brand, regional or national retail',
  },
];

/** Individual sellers — in-person or informal sale settings (multi-select). */
const consumerSaleContextOptions = ['Garage sale', 'Event sale', 'Move-out sale'];
const categoryOptions = ['Fashion', 'Electronics', 'Collectibles', 'Home', 'Sports', 'Beauty', 'General merchandise'];
const livePlatformOptions = ['eBay Live', 'Whatnot', 'TikTok Live', 'Instagram Live', 'YouTube Live', 'Amazon Live'];

function toggleInList(list: string[], value: string) {
  return list.includes(value) ? list.filter((x) => x !== value) : [...list, value];
}

export function SellerOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState<StepId>('tier');
  const [tier, setTier] = useState<BusinessTier | null>(null);
  const [brandName, setBrandName] = useState('');
  const [legalEntityName, setLegalEntityName] = useState('');
  /** Individual sellers often have no site — use this instead of requiring a URL. */
  const [sellingDescription, setSellingDescription] = useState('');
  const [consumerSaleContexts, setConsumerSaleContexts] = useState<string[]>([]);
  const [website, setWebsite] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');
  const [categories, setCategories] = useState<string[]>([]);
  const [categoryInput, setCategoryInput] = useState('');
  const [country, setCountry] = useState('United States');
  const [timezone, setTimezone] = useState(() =>
    Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Los_Angeles',
  );
  const [gmvBand, setGmvBand] = useState('');
  const [catalogBand, setCatalogBand] = useState('');
  const [livePlatforms, setLivePlatforms] = useState<string[]>([]);
  const [soloStreamer, setSoloStreamer] = useState(true);
  const [teamRoles, setTeamRoles] = useState({ marketing: false, ops: false, finance: false });
  const [primaryGoal, setPrimaryGoal] = useState('');
  const [brandGuidelinesNote, setBrandGuidelinesNote] = useState('');
  const [billingEmail, setBillingEmail] = useState('');
  const [complianceBusiness, setComplianceBusiness] = useState(false);
  const [complianceTerms, setComplianceTerms] = useState(false);
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'annual'>('monthly');
  const [membershipFeeAcknowledged, setMembershipFeeAcknowledged] = useState(false);

  useEffect(() => {
    if (tier === 'consumer' || tier === 'small') setBillingInterval('monthly');
  }, [tier]);

  const steps: StepId[] = ['tier', 'profile', 'operations', 'goals', 'membership', 'review'];
  const stepIndex = steps.indexOf(step);

  const goNext = () => {
    const i = stepIndex;
    if (i < steps.length - 1) setStep(steps[i + 1]);
  };
  const goBack = () => {
    const i = stepIndex;
    if (i > 0) setStep(steps[i - 1]);
  };

  const canAdvanceTier = tier !== null;
  const consumerSellingOk =
    tier !== 'consumer' ||
    sellingDescription.trim().length > 0 ||
    consumerSaleContexts.length > 0 ||
    website.trim().length > 0;
  const canAdvanceProfile = brandName.trim().length > 0 && consumerSellingOk;
  const canAdvanceOperations =
    livePlatforms.length > 0 && (soloStreamer || teamRoles.marketing || teamRoles.ops || teamRoles.finance);
  const canAdvanceGoals = primaryGoal !== '' && complianceTerms;

  const resolvedMembership = resolveSellerMembership(
    tier,
    billingInterval === 'annual',
  );

  const canAdvanceMembership = membershipFeeAcknowledged && resolvedMembership !== null;

  const finish = () => {
    try {
      localStorage.setItem(SELLER_ONBOARDING_STORAGE_KEY, 'true');
      const plan = resolveSellerMembership(tier, billingInterval === 'annual');
      if (plan) {
        localStorage.setItem(
          SELLER_MEMBERSHIP_STORAGE_KEY,
          JSON.stringify({
            tier,
            billingInterval: plan.interval,
            amountUsd: plan.amountUsd,
            updatedAt: new Date().toISOString(),
          }),
        );
      }
      localStorage.setItem(
        SELLER_ONBOARDING_SNAPSHOT_KEY,
        JSON.stringify({
          tier,
          brandName: brandName.trim(),
          legalEntityName: legalEntityName.trim() || undefined,
          sellingDescription: tier === 'consumer' ? sellingDescription.trim() || undefined : undefined,
          consumerSaleContexts: tier === 'consumer' && consumerSaleContexts.length > 0 ? consumerSaleContexts : undefined,
          website: website.trim() || undefined,
          additionalNotes: additionalNotes.trim() || undefined,
          categories,
          country,
          timezone,
          livePlatforms,
          primaryGoal,
          updatedAt: new Date().toISOString(),
        }),
      );
    } catch {
      /* ignore */
    }
    navigate('/seller');
  };

  const showLegal = tier === 'mid' || tier === 'large';
  const showBrandGuidelines = tier === 'mid' || tier === 'large';
  const showBillingEmail = tier === 'large';

  return (
    <div className="max-w-3xl mx-auto p-6 pb-16 text-gray-900 dark:text-gray-100">
      <div className="flex items-center gap-3 mb-8">
        <Link
          to="/seller"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Skip for now
        </Link>
      </div>

      <div className="flex items-center gap-2 mb-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/25">
          <Store className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Seller onboarding</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Tailored for solo sellers through large retail — demo only, saved in this browser when you finish.
          </p>
        </div>
      </div>

      {/* Step indicator */}
      <div className="flex flex-wrap gap-1.5 mt-6 mb-8">
        {steps.map((s, idx) => (
          <button
            key={s}
            type="button"
            onClick={() => idx < stepIndex && setStep(s)}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              s === step
                ? 'bg-emerald-600 text-white'
                : idx < stepIndex
                  ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200 cursor-pointer hover:bg-emerald-200 dark:hover:bg-emerald-900'
                  : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-500'
            }`}
          >
            {idx + 1}. {s === 'tier' && 'Size'}
            {s === 'profile' && 'Business'}
            {s === 'operations' && 'Ops request'}
            {s === 'goals' && 'Goals'}
            {s === 'membership' && 'Membership'}
            {s === 'review' && 'Review'}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 sm:p-8 shadow-sm">
        {step === 'tier' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                What best describes your business?
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                We use this to surface the right fields — not to gate features in this prototype.
              </p>
            </div>
            <div className="grid gap-3">
              {tierCards.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setTier(c.id)}
                  className={`text-left rounded-xl border p-4 transition-all ${
                    tier === c.id
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 ring-2 ring-emerald-500/30'
                      : 'border-gray-200 dark:border-gray-700 hover:border-emerald-300 dark:hover:border-emerald-800'
                  }`}
                >
                  <p className="font-medium">{c.title}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">{c.subtitle}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 'profile' && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              Business profile
            </h2>

            <label className="block">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Brand / store name</span>
              <input
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="e.g. Sports Gear Pro"
                className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
              />
            </label>

            {showLegal && (
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Legal entity name</span>
                <input
                  value={legalEntityName}
                  onChange={(e) => setLegalEntityName(e.target.value)}
                  placeholder="As on tax / vendor forms"
                  className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                />
              </label>
            )}

            {tier === 'consumer' ? (
              <>
                <div>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Garage sale, event sale, move-out sale
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                    Pick any that apply — or skip and describe below / add a shop link.
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {consumerSaleContextOptions.map((label) => (
                      <button
                        key={label}
                        type="button"
                        onClick={() => setConsumerSaleContexts((prev) => toggleInList(prev, label))}
                        className={`rounded-full px-3 py-1 text-xs font-medium border transition-colors ${
                          consumerSaleContexts.includes(label)
                            ? 'border-emerald-500 bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-100'
                            : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-emerald-300'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    What are you selling (or planning to sell)?
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                    Optional if you selected sale types above — otherwise add a quick note here, a shop link, or both.
                  </p>
                  <textarea
                    value={sellingDescription}
                    onChange={(e) => setSellingDescription(e.target.value)}
                    rows={4}
                    placeholder="e.g. Vintage streetwear from my closet, trading cards, handmade jewelry…"
                    className="mt-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm resize-y"
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <Globe className="w-4 h-4 opacity-70" />
                    Website or shop link (optional)
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                    Optional — use if you sell online instead of (or in addition to) the fields above.
                  </p>
                  <input
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    placeholder="https:// or @handle"
                    className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                  />
                </label>
              </>
            ) : (
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                  <Globe className="w-4 h-4 opacity-70" />
                  Website or primary storefront URL
                </span>
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                  Optional in this demo — add your main site or branded storefront if you have one.
                </p>
                <input
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="https://"
                  className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                />
              </label>
            )}

            <div>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Top categories</span>
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                Choose common types below and/or add your own categories.
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                {categoryOptions.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setCategories((prev) => toggleInList(prev, m))}
                    className={`rounded-full px-3 py-1 text-xs font-medium border transition-colors ${
                      categories.includes(m)
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-100'
                        : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-emerald-300'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-2 mt-3">
                <input
                  value={categoryInput}
                  onChange={(e) => setCategoryInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const t = categoryInput.trim();
                      if (!t) return;
                      setCategories((prev) => {
                        if (prev.some((c) => c.toLowerCase() === t.toLowerCase())) return prev;
                        return [...prev, t];
                      });
                      setCategoryInput('');
                    }
                  }}
                  placeholder="Add a category (e.g. Automotive, Baby)"
                  className="flex-1 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2 text-sm"
                />
                <button
                  type="button"
                  onClick={() => {
                    const t = categoryInput.trim();
                    if (!t) return;
                    setCategories((prev) => {
                      if (prev.some((c) => c.toLowerCase() === t.toLowerCase())) return prev;
                      return [...prev, t];
                    });
                    setCategoryInput('');
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-emerald-600 bg-emerald-600 text-white px-4 py-2 text-sm font-medium hover:bg-emerald-700 shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  Add
                </button>
              </div>
              {categories.some((c) => !categoryOptions.includes(c)) && (
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                  Custom categories — tap to remove:
                </p>
              )}
              <div className="flex flex-wrap gap-2 mt-1.5">
                {categories
                  .filter((c) => !categoryOptions.includes(c))
                  .map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCategories((prev) => prev.filter((x) => x !== c))}
                      className="rounded-full px-3 py-1 text-xs font-medium border border-emerald-500 bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-100"
                      title="Remove"
                    >
                      {c} ✕
                    </button>
                  ))}
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Country / region</span>
                <input
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                />
              </label>
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Timezone</span>
                <input
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                />
              </label>
            </div>

            <label className="block">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Additional information</span>
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                Optional — policies, inventory constraints, launch timing, or anything else that helps us support your store.
              </p>
              <textarea
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                rows={4}
                placeholder="Type any extra context here…"
                className="mt-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm resize-y"
              />
            </label>
          </div>
        )}

        {step === 'operations' && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Radio className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              Request operations from ConnectIn
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 -mt-2">
              Tell us how you sell live today and who we should work with. ConnectIn uses this to scope onboarding,
              tooling, and creator ops — not to judge your business.
            </p>

            {(tier === 'small' || tier === 'mid' || tier === 'large') && (
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Approx. monthly live GMV band (for your request)
                  </span>
                  <select
                    value={gmvBand}
                    onChange={(e) => setGmvBand(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                  >
                    <option value="">Select…</option>
                    <option value="lt25k">Under $25k</option>
                    <option value="25-100k">$25k – $100k</option>
                    <option value="100-500k">$100k – $500k</option>
                    <option value="500k-2m">$500k – $2M</option>
                    <option value="gt2m">$2M+</option>
                  </select>
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <Package className="w-4 h-4 opacity-70" />
                    Active SKU band (for your request)
                  </span>
                  <select
                    value={catalogBand}
                    onChange={(e) => setCatalogBand(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                  >
                    <option value="">Select…</option>
                    <option value="lt500">Under 500</option>
                    <option value="500-5k">500 – 5,000</option>
                    <option value="5k-50k">5,000 – 50,000</option>
                    <option value="gt50k">50,000+</option>
                  </select>
                </label>
              </div>
            )}

            <div>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Platforms to include in your ConnectIn ops request
              </span>
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                Select everywhere you stream today or want coordination — we’ll align live workflows and creator touchpoints.
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                {livePlatformOptions.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setLivePlatforms((prev) => toggleInList(prev, m))}
                    className={`rounded-full px-3 py-1 text-xs font-medium border transition-colors ${
                      livePlatforms.includes(m)
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-100'
                        : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-emerald-300'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-gray-200 dark:border-gray-700 p-4 space-y-3">
              <div className="flex items-center gap-2 font-medium text-sm">
                <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                Who should ConnectIn coordinate with?
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                We route creator outreach, live show logistics, and payouts to the right people on your side.
              </p>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={soloStreamer}
                  onChange={(e) => setSoloStreamer(e.target.checked)}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                Mostly me (founder / owner) — single point of contact
              </label>
              {!soloStreamer && (
                <div className="pl-6 space-y-2 text-sm">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={teamRoles.marketing}
                      onChange={(e) => setTeamRoles((r) => ({ ...r, marketing: e.target.checked }))}
                      className="rounded border-gray-300 text-emerald-600"
                    />
                    Marketing / growth (invites & campaigns)
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={teamRoles.ops}
                      onChange={(e) => setTeamRoles((r) => ({ ...r, ops: e.target.checked }))}
                      className="rounded border-gray-300 text-emerald-600"
                    />
                    Ops / studio (live runs & scheduling)
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={teamRoles.finance}
                      onChange={(e) => setTeamRoles((r) => ({ ...r, finance: e.target.checked }))}
                      className="rounded border-gray-300 text-emerald-600"
                    />
                    Finance (creator payouts & approvals)
                  </label>
                </div>
              )}
            </div>

            {showBrandGuidelines && (
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Notes for the ConnectIn ops team (optional)
                </span>
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-0.5">
                  Brand guardrails, tone, logo usage — helps us brief creators and your internal team consistently.
                </p>
                <textarea
                  value={brandGuidelinesNote}
                  onChange={(e) => setBrandGuidelinesNote(e.target.value)}
                  rows={3}
                  placeholder="e.g. Approved messaging, do-not-say list, link to brand kit…"
                  className="mt-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm resize-y"
                />
              </label>
            )}
          </div>
        )}

        {step === 'goals' && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              Goals & compliance
            </h2>

            <div>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Primary goal with creator collabs</span>
              <div className="grid gap-2 mt-2">
                {[
                  ['clearance', 'Move clearance / aged inventory'],
                  ['launch', 'Product launches & buzz'],
                  ['always-on', 'Always-on brand & community'],
                  ['experiments', 'Test new categories or audiences'],
                ].map(([id, label]) => (
                  <label
                    key={id}
                    className={`flex items-center gap-3 rounded-lg border p-3 cursor-pointer text-sm ${
                      primaryGoal === id
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50'
                        : 'border-gray-200 dark:border-gray-700 hover:border-emerald-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="goal"
                      checked={primaryGoal === id}
                      onChange={() => setPrimaryGoal(id)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    {label}
                  </label>
                ))}
              </div>
            </div>

            {showBillingEmail && (
              <label className="block">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">AP / billing email</span>
                <input
                  type="email"
                  value={billingEmail}
                  onChange={(e) => setBillingEmail(e.target.value)}
                  placeholder="ap@yourcompany.com"
                  className="mt-1 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 px-3 py-2.5 text-sm"
                />
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">Used for invoices & creator payouts in a full rollout.</p>
              </label>
            )}

            <div className="rounded-xl border border-gray-200 dark:border-gray-700 p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                Compliance (demo checkboxes)
              </div>
              <label className="flex items-start gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={complianceBusiness}
                  onChange={(e) => setComplianceBusiness(e.target.checked)}
                  className="mt-0.5 rounded border-gray-300 text-emerald-600"
                />
                <span>
                  We intend to provide accurate business & tax information when ConnectIn requests verification
                  {tier === 'large' ? ' (W-9 / VAT / vendor onboarding).' : '.'}
                </span>
              </label>
              <label className="flex items-start gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={complianceTerms}
                  onChange={(e) => setComplianceTerms(e.target.checked)}
                  className="mt-0.5 rounded border-gray-300 text-emerald-600"
                />
                <span>
                  I agree to the{' '}
                  <Link to="/terms" className="text-emerald-700 dark:text-emerald-400 underline font-medium">
                    seller terms
                  </Link>{' '}
                  and{' '}
                  <Link to="/privacy" className="text-emerald-700 dark:text-emerald-400 underline font-medium">
                    privacy policy
                  </Link>{' '}
                  for this demo.
                </span>
              </label>
            </div>
          </div>
        )}

        {step === 'membership' && tier && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                Seller membership
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Pricing matches your business tier. No payment is processed in this prototype — you’re agreeing to the fee
                structure only.{' '}
                <span className="text-gray-700 dark:text-gray-300 font-medium">
                  Cancel anytime
                </span>{' '}
                from billing settings; no long-term lock-in for membership.
              </p>
            </div>

            {(tier === 'consumer' || tier === 'small') && (
              <div className="rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/60 dark:bg-emerald-950/30 p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-emerald-800 dark:text-emerald-300 mb-1">
                  Your plan
                </p>
                <p className="text-3xl font-bold text-emerald-950 dark:text-emerald-100 tabular-nums">
                  {formatUsd(SELLER_MEMBERSHIP_MONTHLY_USD[tier])}
                  <span className="text-lg font-semibold text-emerald-800/90 dark:text-emerald-300/90"> / month</span>
                </p>
                <p className="text-xs text-emerald-900/80 dark:text-emerald-200/80 mt-2">
                  Consumer & small sellers bill monthly only. Cancel anytime.
                </p>
              </div>
            )}

            {(tier === 'mid' || tier === 'large') && (
              <div className="space-y-3">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Choose billing</p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBillingInterval('monthly')}
                    className={`rounded-xl border p-4 text-left transition-all ${
                      billingInterval === 'monthly'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 ring-2 ring-emerald-500/30'
                        : 'border-gray-200 dark:border-gray-700 hover:border-emerald-300'
                    }`}
                  >
                    <p className="text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                      Monthly
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1 tabular-nums">
                      {formatUsd(SELLER_MEMBERSHIP_MONTHLY_USD[tier])}
                      <span className="text-sm font-normal text-gray-600 dark:text-gray-400"> / mo</span>
                    </p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setBillingInterval('annual')}
                    className={`rounded-xl border p-4 text-left transition-all ${
                      billingInterval === 'annual'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 ring-2 ring-emerald-500/30'
                        : 'border-gray-200 dark:border-gray-700 hover:border-emerald-300'
                    }`}
                  >
                    <p className="text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                      Annual
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1 tabular-nums">
                      {formatUsd(SELLER_MEMBERSHIP_ANNUAL_USD[tier]!)}
                      <span className="text-sm font-normal text-gray-600 dark:text-gray-400"> / year</span>
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-2 font-medium">
                      {tier === 'mid' &&
                        `Save ${formatUsd(SELLER_MEMBERSHIP_MONTHLY_USD.mid * 12 - SELLER_MEMBERSHIP_ANNUAL_USD.mid!)} vs 12× monthly`}
                      {tier === 'large' &&
                        `Save ${formatUsd(SELLER_MEMBERSHIP_MONTHLY_USD.large * 12 - SELLER_MEMBERSHIP_ANNUAL_USD.large!)} vs 12× monthly`}
                    </p>
                  </button>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-500">
                  Cancel anytime from account billing — annual saves vs paying monthly for a full year.
                </p>
              </div>
            )}

            <label className="flex items-start gap-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50/80 dark:bg-gray-950/50 p-4 cursor-pointer">
              <input
                type="checkbox"
                checked={membershipFeeAcknowledged}
                onChange={(e) => setMembershipFeeAcknowledged(e.target.checked)}
                className="mt-1 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300">
                I authorize ConnectIn to charge my{' '}
                <strong className="text-emerald-800 dark:text-emerald-300">
                  {resolvedMembership?.interval === 'annual' ? 'annual' : 'monthly'} membership at{' '}
                  {resolvedMembership != null ? formatUsd(resolvedMembership.amountUsd) : '—'}
                  {resolvedMembership?.interval === 'annual' ? ' per year' : ' per month'}
                </strong>{' '}
                on the payment method I’ll add at launch (demo — no charge today). You may{' '}
                <strong className="font-medium text-gray-800 dark:text-gray-200">cancel anytime</strong>; access continues
                through the end of the paid period.
              </span>
            </label>
          </div>
        )}

        {step === 'review' && (
          <div className="space-y-6">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              Review & launch workspace
            </h2>
            <dl className="grid gap-3 text-sm">
              <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                <dt className="text-gray-500 dark:text-gray-400">Business size</dt>
                <dd className="font-medium text-right">{tierCards.find((t) => t.id === tier)?.title ?? '—'}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                <dt className="text-gray-500 dark:text-gray-400">Brand</dt>
                <dd className="font-medium text-right">{brandName || '—'}</dd>
              </div>
              {legalEntityName && (
                <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <dt className="text-gray-500 dark:text-gray-400">Legal entity</dt>
                  <dd className="font-medium text-right">{legalEntityName}</dd>
                </div>
              )}
              {tier === 'consumer' && consumerSaleContexts.length > 0 && (
                <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <dt className="text-gray-500 dark:text-gray-400 shrink-0">Sale setting</dt>
                  <dd className="font-medium text-right text-balance">{consumerSaleContexts.join(', ')}</dd>
                </div>
              )}
              {tier === 'consumer' && sellingDescription.trim() && (
                <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <dt className="text-gray-500 dark:text-gray-400 shrink-0">What you sell</dt>
                  <dd className="font-medium text-right text-balance max-w-[min(28rem,65%)]">{sellingDescription.trim()}</dd>
                </div>
              )}
              {website.trim() && (
                <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <dt className="text-gray-500 dark:text-gray-400">Website / shop link</dt>
                  <dd className="font-medium text-right text-balance break-all">{website.trim()}</dd>
                </div>
              )}
              {additionalNotes.trim() && (
                <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <dt className="text-gray-500 dark:text-gray-400 shrink-0">Additional information</dt>
                  <dd className="font-medium text-right text-balance max-w-[min(28rem,65%)] whitespace-pre-wrap">
                    {additionalNotes.trim()}
                  </dd>
                </div>
              )}
              <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                <dt className="text-gray-500 dark:text-gray-400">Categories</dt>
                <dd className="font-medium text-right text-balance">{categories.join(', ') || '—'}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                <dt className="text-gray-500 dark:text-gray-400">Ops request · platforms</dt>
                <dd className="font-medium text-right text-balance">{livePlatforms.join(', ') || '—'}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                <dt className="text-gray-500 dark:text-gray-400">Primary goal</dt>
                <dd className="font-medium text-right">
                  {primaryGoal === 'clearance' && 'Clearance / aged inventory'}
                  {primaryGoal === 'launch' && 'Launches & buzz'}
                  {primaryGoal === 'always-on' && 'Always-on brand'}
                  {primaryGoal === 'experiments' && 'Tests & experiments'}
                  {!primaryGoal && '—'}
                </dd>
              </div>
            </dl>

            {resolvedMembership != null && (
              <div className="rounded-2xl border-2 border-emerald-500/35 bg-gradient-to-br from-emerald-50 to-white dark:from-emerald-950/45 dark:to-gray-900 dark:border-emerald-700/45 p-6 shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-600/25">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold uppercase tracking-wide text-emerald-800 dark:text-emerald-300">
                      Membership price
                    </p>
                    <p className="mt-1 text-3xl font-bold text-emerald-950 dark:text-emerald-50 tabular-nums tracking-tight">
                      {formatUsd(resolvedMembership.amountUsd)}
                      <span className="text-xl font-semibold text-emerald-800/90 dark:text-emerald-300/90">
                        {resolvedMembership.interval === 'annual' ? ' / year' : ' / month'}
                      </span>
                    </p>
                    <p className="mt-2 text-sm text-emerald-900/90 dark:text-emerald-200/90">
                      {resolvedMembership.interval === 'annual' ? 'Annual' : 'Monthly'} billing — cancel anytime from account
                      billing.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900/60 p-4 text-sm text-emerald-950 dark:text-emerald-100">
              Next: invite creators from <strong>Find influencers</strong>, track replies in <strong>Invites</strong>, and
              align rates in <strong>Pay talks</strong>.
            </div>
          </div>
        )}

        <div className="flex flex-col-reverse sm:flex-row sm:justify-between gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-800">
          <button
            type="button"
            onClick={goBack}
            disabled={stepIndex === 0}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 dark:border-gray-600 px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-40 disabled:pointer-events-none"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

          {step !== 'review' ? (
            <button
              type="button"
              onClick={goNext}
              disabled={
                (step === 'tier' && !canAdvanceTier) ||
                (step === 'profile' && !canAdvanceProfile) ||
                (step === 'operations' && !canAdvanceOperations) ||
                (step === 'goals' && !canAdvanceGoals) ||
                (step === 'membership' && !canAdvanceMembership)
              }
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 text-white px-5 py-2.5 text-sm font-medium hover:bg-emerald-700 disabled:opacity-40 disabled:pointer-events-none"
            >
              Continue
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={finish}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 text-white px-5 py-2.5 text-sm font-medium hover:bg-emerald-700"
            >
              <Check className="w-4 h-4" />
              Finish & go to workspace
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
