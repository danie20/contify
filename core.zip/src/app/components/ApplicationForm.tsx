import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Linkedin, Youtube, Instagram, Send, FileText, DollarSign, Calendar, Target, BadgeCheck } from 'lucide-react';
import { SellerTierPill } from './SellerTierBadge';
import { tierForDiscoverSellerId } from './sellerTierMock';

export function ApplicationForm() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sellerId = searchParams.get('seller');
  const discoverProposalTier = tierForDiscoverSellerId(sellerId);

  const [formData, setFormData] = useState({
    sellerId: sellerId || '',
    sellerName: 'Premium Electronics Store',
    fullName: '',
    email: '',
    phone: '',
    platform: '',
    linkedinUrl: '',
    youtubeId: '',
    instagramId: '',
    followerCount: '',
    engagementRate: '',
    avgViewers: '',
    streamingExperience: '',
    equipment: '',
    proposedRate: '',
    commissionRate: '',
    streamFrequency: '',
    preferredDays: [] as string[],
    preferredTimeSlot: '',
    campaignObjectives: '',
    targetAudience: '',
    contentApproach: '',
    whyPartner: '',
    portfolioLinks: '',
    references: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/application-status');
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleDayToggle = (day: string) => {
    const updated = formData.preferredDays.includes(day)
      ? formData.preferredDays.filter((d) => d !== day)
      : [...formData.preferredDays, day];
    setFormData({ ...formData, preferredDays: updated });
  };

  const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <h2 className="text-2xl mb-2">Request for Live Streaming (RFLS)</h2>
        <p className="text-gray-600">
          Submit your live-streaming collaboration request to verified sellers
        </p>
      </div>

      {sellerId && (
        <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-200 rounded-full flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-700" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3>Proposing to: {formData.sellerName}</h3>
                <BadgeCheck className="w-5 h-5 text-blue-500 shrink-0" />
                {discoverProposalTier ? <SellerTierPill tier={discoverProposalTier} /> : null}
              </div>
              <p className="text-sm text-gray-600">eBay Verified Seller</p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2">1. Seller Selection</h3>

          {!sellerId && (
            <div>
              <label className="block text-sm mb-2">
                Select Seller <span className="text-red-500">*</span>
              </label>
              <select
                name="sellerId"
                value={formData.sellerId}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              >
                <option value="">Choose a seller to partner with</option>
                <option value="1">Premium Electronics Store (eBay)</option>
                <option value="2">Fashion Forward Boutique (eBay)</option>
                <option value="3">Collectibles Warehouse (Whatnot)</option>
                <option value="5">Sports Gear Pro (eBay)</option>
              </select>
              <p className="text-sm text-gray-500 mt-1">
                Don't see your preferred seller? <a href="/discover" className="text-[var(--color-primary)] hover:underline">Browse sellers</a>
              </p>
            </div>
          )}

          <div>
            <label className="block text-sm mb-2">
              Preferred Streaming Platform <span className="text-red-500">*</span>
            </label>
            <select
              name="platform"
              value={formData.platform}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
            >
              <option value="">Select Platform</option>
              <option value="eBay Live">eBay Live</option>
              <option value="Whatnot">Whatnot</option>
              <option value="Both">Both Platforms</option>
            </select>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2">2. Personal & Contact Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-2">
                Full Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2 flex items-center gap-2">
            <Instagram className="w-5 h-5" />
            3. Social Media Credentials & Metrics
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2 flex items-center gap-2">
                <Linkedin className="w-4 h-4" />
                LinkedIn Profile URL <span className="text-red-500">*</span>
              </label>
              <input
                type="url"
                name="linkedinUrl"
                value={formData.linkedinUrl}
                onChange={handleChange}
                required
                placeholder="https://linkedin.com/in/yourprofile"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-2 flex items-center gap-2">
                  <Youtube className="w-4 h-4" />
                  YouTube Channel ID
                </label>
                <input
                  type="text"
                  name="youtubeId"
                  value={formData.youtubeId}
                  onChange={handleChange}
                  placeholder="@yourchannel"
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                />
              </div>
              <div>
                <label className="block text-sm mb-2 flex items-center gap-2">
                  <Instagram className="w-4 h-4" />
                  Instagram Handle <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="instagramId"
                  value={formData.instagramId}
                  onChange={handleChange}
                  required
                  placeholder="@yourhandle"
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm mb-2">
                  Total Followers <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="followerCount"
                  value={formData.followerCount}
                  onChange={handleChange}
                  required
                  placeholder="50000"
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">
                  Engagement Rate (%) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="engagementRate"
                  value={formData.engagementRate}
                  onChange={handleChange}
                  required
                  placeholder="5.2"
                  step="0.1"
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">
                  Avg Live Viewers <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="avgViewers"
                  value={formData.avgViewers}
                  onChange={handleChange}
                  required
                  placeholder="2000"
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2 flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            4. Proposed Commercial Terms
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-2">
                Proposed Rate per Stream ($) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                name="proposedRate"
                value={formData.proposedRate}
                onChange={handleChange}
                required
                placeholder="200"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Commission Rate (%) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                name="commissionRate"
                value={formData.commissionRate}
                onChange={handleChange}
                required
                placeholder="10"
                step="0.5"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm text-gray-700">
            <p>💡 Competitive rates: $150-$300 per stream + 5-15% commission based on sales generated</p>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2 flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            5. Availability & Schedule
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">
                Stream Frequency <span className="text-red-500">*</span>
              </label>
              <select
                name="streamFrequency"
                value={formData.streamFrequency}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              >
                <option value="">Select Frequency</option>
                <option value="1-2 per week">1-2 streams per week</option>
                <option value="3-4 per week">3-4 streams per week</option>
                <option value="5+ per week">5+ streams per week</option>
                <option value="custom">Custom schedule</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2">
                Preferred Days <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-4 md:grid-cols-7 gap-2">
                {weekdays.map((day) => (
                  <label
                    key={day}
                    className={`px-3 py-2 border-2 rounded cursor-pointer text-center text-sm transition-all ${
                      formData.preferredDays.includes(day)
                        ? 'border-[var(--color-primary)] bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={formData.preferredDays.includes(day)}
                      onChange={() => handleDayToggle(day)}
                      className="hidden"
                    />
                    {day.slice(0, 3)}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm mb-2">
                Preferred Time Slot <span className="text-red-500">*</span>
              </label>
              <select
                name="preferredTimeSlot"
                value={formData.preferredTimeSlot}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              >
                <option value="">Select Time Slot</option>
                <option value="Morning (8AM - 12PM)">Morning (8AM - 12PM)</option>
                <option value="Afternoon (12PM - 5PM)">Afternoon (12PM - 5PM)</option>
                <option value="Evening (5PM - 9PM)">Evening (5PM - 9PM)</option>
                <option value="Night (9PM - 12AM)">Night (9PM - 12AM)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2 flex items-center gap-2">
            <Target className="w-5 h-5" />
            6. Campaign Strategy & Objectives
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">
                Campaign Objectives <span className="text-red-500">*</span>
              </label>
              <textarea
                name="campaignObjectives"
                value={formData.campaignObjectives}
                onChange={handleChange}
                required
                rows={3}
                placeholder="What are the key goals for this partnership? (e.g., increase product awareness, drive sales, build brand loyalty)"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Target Audience <span className="text-red-500">*</span>
              </label>
              <textarea
                name="targetAudience"
                value={formData.targetAudience}
                onChange={handleChange}
                required
                rows={2}
                placeholder="Describe your audience demographics and interests"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Content Approach & Strategy <span className="text-red-500">*</span>
              </label>
              <textarea
                name="contentApproach"
                value={formData.contentApproach}
                onChange={handleChange}
                required
                rows={4}
                placeholder="Describe your planned content format, engagement tactics, and how you'll showcase the products"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Why Partner With This Seller? <span className="text-red-500">*</span>
              </label>
              <textarea
                name="whyPartner"
                value={formData.whyPartner}
                onChange={handleChange}
                required
                rows={3}
                placeholder="Explain why you're interested in this partnership and what unique value you bring"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-6 space-y-4">
          <h3 className="text-lg border-b pb-2">7. Experience & References</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">
                Live Streaming Experience <span className="text-red-500">*</span>
              </label>
              <select
                name="streamingExperience"
                value={formData.streamingExperience}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              >
                <option value="">Select Experience Level</option>
                <option value="Beginner">Beginner (0-6 months)</option>
                <option value="Intermediate">Intermediate (6 months - 2 years)</option>
                <option value="Advanced">Advanced (2+ years)</option>
                <option value="Expert">Expert (5+ years)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2">
                Portfolio & Past Campaign Links
              </label>
              <textarea
                name="portfolioLinks"
                value={formData.portfolioLinks}
                onChange={handleChange}
                rows={3}
                placeholder="Share links to previous streams, campaigns, or case studies"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">
                Professional References
              </label>
              <textarea
                name="references"
                value={formData.references}
                onChange={handleChange}
                rows={3}
                placeholder="Previous seller partnerships, contact information, or testimonials"
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            type="submit"
            className="flex-1 bg-[var(--color-primary)] text-white px-6 py-4 rounded hover:opacity-90 transition-opacity flex items-center justify-center gap-2 text-lg"
          >
            <Send className="w-5 h-5" />
            Submit RFLS
          </button>
          <button
            type="button"
            className="px-6 py-4 border-2 border-gray-300 rounded hover:bg-gray-50 transition-colors"
          >
            Save Draft
          </button>
        </div>

        <p className="text-sm text-gray-500 text-center">
          By submitting this RFLS, you agree to our terms and conditions. The seller will review your request within 3–5 business days.
        </p>
      </form>
    </div>
  );
}
