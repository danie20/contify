import { useState } from 'react';
import { Link } from 'react-router';
import { Search, Star, BadgeCheck, MapPin, Package } from 'lucide-react';
import type { BusinessTier } from './SellerOnboarding';
import { SellerTierPill } from './SellerTierBadge';
import { DISCOVER_SELLER_ID_TO_TIER } from './sellerTierMock';

interface Seller {
  id: number;
  name: string;
  platform: string;
  verified: boolean;
  rating: number;
  reviews: number;
  location: string;
  categories: string[];
  inventory: number;
  imageUrl: string;
  tier: BusinessTier;
}

const mockSellers: Seller[] = [
  {
    id: 1,
    tier: DISCOVER_SELLER_ID_TO_TIER[1],
    name: 'Premium Electronics Store',
    platform: 'eBay',
    verified: true,
    rating: 4.9,
    reviews: 1243,
    location: 'Los Angeles, CA',
    categories: ['Electronics', 'Gadgets'],
    inventory: 450,
    imageUrl: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=200&h=200&fit=crop',
  },
  {
    id: 2,
    tier: DISCOVER_SELLER_ID_TO_TIER[2],
    name: 'Fashion Forward Boutique',
    platform: 'eBay',
    verified: true,
    rating: 4.8,
    reviews: 892,
    location: 'New York, NY',
    categories: ['Fashion', 'Accessories'],
    inventory: 680,
    imageUrl: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=200&h=200&fit=crop',
  },
  {
    id: 3,
    tier: DISCOVER_SELLER_ID_TO_TIER[3],
    name: 'Collectibles Warehouse',
    platform: 'Whatnot',
    verified: true,
    rating: 4.7,
    reviews: 567,
    location: 'Austin, TX',
    categories: ['Collectibles', 'Trading Cards'],
    inventory: 320,
    imageUrl: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=200&h=200&fit=crop',
  },
  {
    id: 4,
    tier: DISCOVER_SELLER_ID_TO_TIER[4],
    name: 'Home Decor Haven',
    platform: 'eBay',
    verified: false,
    rating: 4.5,
    reviews: 234,
    location: 'Seattle, WA',
    categories: ['Home & Garden', 'Decor'],
    inventory: 210,
    imageUrl: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=200&h=200&fit=crop',
  },
  {
    id: 5,
    tier: DISCOVER_SELLER_ID_TO_TIER[5],
    name: 'Sports Gear Pro',
    platform: 'eBay',
    verified: true,
    rating: 4.9,
    reviews: 1567,
    location: 'Miami, FL',
    categories: ['Sports', 'Fitness'],
    inventory: 890,
    imageUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=200&h=200&fit=crop',
  },
  {
    id: 6,
    tier: DISCOVER_SELLER_ID_TO_TIER[6],
    name: 'Vintage Treasures',
    platform: 'Whatnot',
    verified: true,
    rating: 4.6,
    reviews: 445,
    location: 'Portland, OR',
    categories: ['Vintage', 'Antiques'],
    inventory: 156,
    imageUrl: 'https://images.unsplash.com/photo-1567016376408-0226e4d0c1ea?w=200&h=200&fit=crop',
  },
];

export function DiscoverSellers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');

  const filteredSellers = mockSellers.filter((seller) => {
    const matchesSearch =
      seller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      seller.categories.some((cat) => cat.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesPlatform = platformFilter === 'all' || seller.platform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  return (
    <div className="max-w-7xl mx-auto p-6 text-gray-900 dark:text-gray-100">
      <div className="mb-6">
        <h2 className="text-2xl mb-2">Discover Sellers</h2>
        <p className="text-gray-600 dark:text-gray-400">Find verified sellers to collaborate with on your live streams</p>
      </div>

      <div className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by seller name or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
            />
          </div>
          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
          >
            <option value="all">All Platforms</option>
            <option value="eBay">eBay</option>
            <option value="Whatnot">Whatnot</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSellers.map((seller) => (
          <div key={seller.id} className="bg-white dark:bg-gray-900 dark:border dark:border-gray-800 rounded-lg shadow hover:shadow-lg transition-shadow">
            <div className="h-48 bg-gray-200 dark:bg-gray-800 rounded-t-lg overflow-hidden">
              <img src={seller.imageUrl} alt={seller.name} className="w-full h-full object-cover" />
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2 flex-wrap">
                <h3 className="flex flex-wrap items-center gap-x-2 gap-y-1.5 text-gray-900 dark:text-gray-100">
                  {seller.name}
                  {seller.verified && (
                    <BadgeCheck className="w-5 h-5 text-blue-500 flex-shrink-0" />
                  )}
                  <SellerTierPill tier={seller.tier} />
                </h3>
              </div>
              <div className="flex items-center gap-4 mb-3">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span>{seller.rating}</span>
                  <span className="text-gray-500 text-sm">({seller.reviews})</span>
                </div>
              </div>
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{seller.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Package className="w-4 h-4" />
                  <span>{seller.inventory} items in stock</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-4">
                {seller.categories.map((category) => (
                  <span
                    key={category}
                    className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded"
                  >
                    {category}
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <Link
                  to={`/apply?seller=${seller.id}`}
                  className="flex-1 bg-[var(--color-primary)] text-white px-4 py-2 rounded hover:opacity-90 transition-opacity text-sm text-center"
                >
                  Connect
                </Link>
                <button className="flex-1 border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 transition-colors text-sm">
                  View Details
                </button>
              </div>
              <div className="mt-2 text-center">
                <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                  {seller.platform}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredSellers.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No sellers found matching your criteria</p>
        </div>
      )}
    </div>
  );
}
