import { useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Search, Send, Users, MapPin, BadgeCheck, Sparkles, Heart } from 'lucide-react';
import { MOCK_INFLUENCERS, type Influencer } from './sellerInfluencerDirectory';
import { useSellerWorkspace } from './SellerWorkspaceContext';

export function SellerFindInfluencers() {
  const { sendInvite, hasActiveInviteTo, isFavorite, toggleFavorite } = useSellerWorkspace();
  const [query, setQuery] = useState('');
  const [nicheFilter, setNicheFilter] = useState('all');
  const [inviteTarget, setInviteTarget] = useState<Influencer | null>(null);
  const [message, setMessage] = useState('');
  const [campaign, setCampaign] = useState('');
  const [banner, setBanner] = useState<string | null>(null);

  const niches = useMemo(() => {
    const set = new Set(MOCK_INFLUENCERS.map((i) => i.niche));
    return ['all', ...Array.from(set).sort()];
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MOCK_INFLUENCERS.filter((inf) => {
      const matchesNiche = nicheFilter === 'all' || inf.niche === nicheFilter;
      const matchesQuery =
        !q ||
        inf.displayName.toLowerCase().includes(q) ||
        inf.handle.toLowerCase().includes(q) ||
        inf.niche.toLowerCase().includes(q) ||
        inf.platforms.some((p) => p.toLowerCase().includes(q));
      return matchesNiche && matchesQuery;
    });
  }, [query, nicheFilter]);

  const openInvite = (inf: Influencer) => {
    setInviteTarget(inf);
    setMessage(
      `Hi ${inf.displayName.split(' ')[0]}, we'd love to invite you to co-host a live stream featuring our inventory. Let us know if you're open to discussing rates and schedule.`,
    );
    setCampaign('');
  };

  const closeInvite = () => {
    setInviteTarget(null);
  };

  const handleSendInvite = () => {
    if (!inviteTarget) return;
    sendInvite({
      influencer: inviteTarget,
      campaign: campaign.trim(),
      message,
    });
    setBanner(
      `Invite sent to ${inviteTarget.displayName} (${inviteTarget.handle}). Track it under Invites sent on your workspace.`,
    );
    closeInvite();
    window.setTimeout(() => setBanner(null), 7000);
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {banner && (
        <div className="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-900 px-4 py-3 text-sm flex items-start gap-2">
          <Sparkles className="w-5 h-5 shrink-0 mt-0.5" />
          <span>{banner}</span>
        </div>
      )}

      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">Find influencers</h2>
        <p className="text-gray-600 max-w-2xl">
          Search creators who match your categories, then send a collaboration invite. Use the heart to save someone
          to <strong className="text-gray-800">Favorites</strong> for later. This flow is mocked — data stays in this
          browser session until refresh.
        </p>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 p-4 mb-8">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, @handle, niche, or platform…"
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
            />
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <label className="text-sm text-gray-600 whitespace-nowrap">Niche</label>
            <select
              value={nicheFilter}
              onChange={(e) => setNicheFilter(e.target.value)}
              className="border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 min-w-[200px]"
            >
              {niches.map((n) => (
                <option key={n} value={n}>
                  {n === 'all' ? 'All niches' : n}
                </option>
              ))}
            </select>
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-3 flex items-center gap-1">
          <Users className="w-3.5 h-3.5" />
          Showing {filtered.length} of {MOCK_INFLUENCERS.length} creators (mock directory)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filtered.map((inf) => {
          const sent = hasActiveInviteTo(inf.id);
          const fav = isFavorite(inf.id);
          return (
            <div
              key={inf.id}
              className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-shadow"
            >
              <div className="p-5 flex gap-4 flex-1">
                <img
                  src={inf.avatar}
                  alt=""
                  className="w-16 h-16 rounded-full object-cover border border-gray-100 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="font-semibold text-gray-900 truncate">{inf.displayName}</h3>
                    {inf.verified && <BadgeCheck className="w-4 h-4 text-sky-500 shrink-0" aria-label="Verified" />}
                  </div>
                  <p className="text-sm text-emerald-700 font-medium">{inf.handle}</p>
                  <p className="text-sm text-gray-600 mt-1">{inf.niche}</p>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2 text-xs text-gray-500">
                    <span>{inf.followers} followers</span>
                    <span>{inf.avgViewers}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    {inf.location}
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {inf.platforms.map((p) => (
                      <span
                        key={p}
                        className="text-[11px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-700 border border-gray-200"
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="px-5 pb-5 pt-0 flex gap-2">
                <button
                  type="button"
                  onClick={() => toggleFavorite(inf)}
                  className={`shrink-0 flex items-center justify-center w-11 h-11 rounded-lg border transition-colors ${
                    fav
                      ? 'border-rose-200 bg-rose-50 text-rose-600'
                      : 'border-gray-200 text-gray-400 hover:border-rose-200 hover:text-rose-500'
                  }`}
                  title={fav ? 'Remove from favorites' : 'Save to favorites'}
                >
                  <Heart className={`w-5 h-5 ${fav ? 'fill-current' : ''}`} />
                </button>
                <button
                  type="button"
                  disabled={sent}
                  onClick={() => openInvite(inf)}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Send className="w-4 h-4" />
                  {sent ? 'Invite in progress' : 'Send invite'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-gray-500 bg-white dark:bg-gray-900 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
          No creators match your filters. Try clearing search or choosing “All niches”.
        </div>
      )}

      <Dialog open={!!inviteTarget} onOpenChange={(open) => !open && closeInvite()}>
        <DialogContent className="sm:max-w-md bg-white text-gray-900 border-gray-200">
          <DialogHeader>
            <DialogTitle>Send collaboration invite</DialogTitle>
            <DialogDescription className="text-gray-600">
              {inviteTarget && (
                <>
                  To <span className="font-medium text-gray-900">{inviteTarget.displayName}</span>{' '}
                  <span className="text-emerald-700">{inviteTarget.handle}</span>
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          {inviteTarget && (
            <div className="space-y-4 py-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Campaign / stream focus (optional)</label>
                <input
                  type="text"
                  value={campaign}
                  onChange={(e) => setCampaign(e.target.value)}
                  placeholder="e.g. Spring sneaker drop, May 15"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={5}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 resize-none"
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <button
              type="button"
              onClick={closeInvite}
              className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSendInvite}
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              Send invite
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
