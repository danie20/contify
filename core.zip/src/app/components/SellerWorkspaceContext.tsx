import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import type { Influencer } from './sellerInfluencerDirectory';

export type InviteStatus = 'pending' | 'viewed' | 'accepted' | 'declined';

export interface SentInvite {
  id: string;
  influencerId: number;
  displayName: string;
  handle: string;
  avatar: string;
  niche: string;
  campaign: string;
  message: string;
  sentAt: string;
  status: InviteStatus;
}

export interface FavoriteCreator {
  influencerId: number;
  displayName: string;
  handle: string;
  avatar: string;
  niche: string;
  savedAt: string;
  note: string;
}

export interface FollowUpReminder {
  id: string;
  influencerId: number;
  displayName: string;
  handle: string;
  dueDate: string;
  note: string;
  completed: boolean;
}

function isoNow() {
  return new Date().toISOString();
}

function addDaysYmd(ymd: string, days: number): string {
  const d = new Date(ymd + 'T12:00:00');
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

const initialInvites: SentInvite[] = [
  {
    id: 'seed-inv-1',
    influencerId: 3,
    displayName: 'Sam Okonkwo',
    handle: '@samcollects',
    avatar:
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&crop=face',
    niche: 'Collectibles & cards',
    campaign: 'Memorial Day card breaks',
    message: 'We would love to run a dual-host show with graded slabs.',
    sentAt: '2026-04-28T15:00:00.000Z',
    status: 'viewed',
  },
  {
    id: 'seed-inv-2',
    influencerId: 5,
    displayName: 'Taylor Brooks',
    handle: '@taylorfitlive',
    avatar:
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop&crop=face',
    niche: 'Sports & fitness',
    campaign: 'Spring running gear',
    message: 'Interested in a 90-minute stream featuring our outlet inventory.',
    sentAt: '2026-05-02T09:30:00.000Z',
    status: 'pending',
  },
];

const initialFavorites: FavoriteCreator[] = [
  {
    influencerId: 1,
    displayName: 'Alex Rivera',
    handle: '@alexstreamstv',
    avatar:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop&crop=face',
    niche: 'Electronics & tech',
    savedAt: '2026-04-20T11:00:00.000Z',
    note: 'Strong tech unboxings — align with our refurb drops.',
  },
];

const initialReminders: FollowUpReminder[] = [
  {
    id: 'seed-rem-1',
    influencerId: 3,
    displayName: 'Sam Okonkwo',
    handle: '@samcollects',
    dueDate: '2026-05-03',
    note: 'Check if they saw revised commission sheet.',
    completed: false,
  },
  {
    id: 'seed-rem-2',
    influencerId: 2,
    displayName: 'Jordan Lee',
    handle: '@jordanthrifts',
    dueDate: '2026-05-08',
    note: 'Send lookbook PDF before follow-up call.',
    completed: false,
  },
];

interface SellerWorkspaceContextValue {
  sentInvites: SentInvite[];
  favorites: FavoriteCreator[];
  reminders: FollowUpReminder[];
  hasActiveInviteTo: (influencerId: number) => boolean;
  sendInvite: (args: {
    influencer: Influencer;
    campaign: string;
    message: string;
  }) => void;
  setInviteStatus: (inviteId: string, status: InviteStatus) => void;
  isFavorite: (influencerId: number) => boolean;
  toggleFavorite: (influencer: Influencer) => void;
  updateFavoriteNote: (influencerId: number, note: string) => void;
  removeFavorite: (influencerId: number) => void;
  addReminder: (args: {
    influencerId: number;
    displayName: string;
    handle: string;
    dueDate: string;
    note: string;
  }) => void;
  completeReminder: (id: string) => void;
  snoozeReminder: (id: string, days: number) => void;
  openRemindersCount: number;
  overdueReminderCount: number;
  dueSoonReminders: FollowUpReminder[];
}

const SellerWorkspaceContext = createContext<SellerWorkspaceContextValue | null>(null);

export function SellerWorkspaceProvider({ children }: { children: ReactNode }) {
  const [sentInvites, setSentInvites] = useState<SentInvite[]>(initialInvites);
  const [favorites, setFavorites] = useState<FavoriteCreator[]>(initialFavorites);
  const [reminders, setReminders] = useState<FollowUpReminder[]>(initialReminders);

  const hasActiveInviteTo = useCallback(
    (influencerId: number) =>
      sentInvites.some(
        (i) =>
          i.influencerId === influencerId && (i.status === 'pending' || i.status === 'viewed'),
      ),
    [sentInvites],
  );

  const sendInvite = useCallback(
    ({ influencer, campaign, message }: { influencer: Influencer; campaign: string; message: string }) => {
      const row: SentInvite = {
        id: `inv-${Date.now()}`,
        influencerId: influencer.id,
        displayName: influencer.displayName,
        handle: influencer.handle,
        avatar: influencer.avatar,
        niche: influencer.niche,
        campaign: campaign.trim(),
        message,
        sentAt: isoNow(),
        status: 'pending',
      };
      setSentInvites((prev) => [row, ...prev]);
    },
    [],
  );

  const setInviteStatus = useCallback((inviteId: string, status: InviteStatus) => {
    setSentInvites((prev) => prev.map((i) => (i.id === inviteId ? { ...i, status } : i)));
  }, []);

  const isFavorite = useCallback(
    (influencerId: number) => favorites.some((f) => f.influencerId === influencerId),
    [favorites],
  );

  const toggleFavorite = useCallback((influencer: Influencer) => {
    setFavorites((prev) => {
      const exists = prev.some((f) => f.influencerId === influencer.id);
      if (exists) {
        return prev.filter((f) => f.influencerId !== influencer.id);
      }
      const row: FavoriteCreator = {
        influencerId: influencer.id,
        displayName: influencer.displayName,
        handle: influencer.handle,
        avatar: influencer.avatar,
        niche: influencer.niche,
        savedAt: isoNow(),
        note: '',
      };
      return [row, ...prev];
    });
  }, []);

  const updateFavoriteNote = useCallback((influencerId: number, note: string) => {
    setFavorites((prev) =>
      prev.map((f) => (f.influencerId === influencerId ? { ...f, note } : f)),
    );
  }, []);

  const removeFavorite = useCallback((influencerId: number) => {
    setFavorites((prev) => prev.filter((f) => f.influencerId !== influencerId));
  }, []);

  const addReminder = useCallback(
    (args: {
      influencerId: number;
      displayName: string;
      handle: string;
      dueDate: string;
      note: string;
    }) => {
      const row: FollowUpReminder = {
        id: `rem-${Date.now()}`,
        ...args,
        completed: false,
      };
      setReminders((prev) => [row, ...prev]);
    },
    [],
  );

  const completeReminder = useCallback((id: string) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, completed: true } : r)));
  }, []);

  const snoozeReminder = useCallback((id: string, days: number) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, dueDate: addDaysYmd(r.dueDate, days) } : r)),
    );
  }, []);

  const { openRemindersCount, overdueReminderCount, dueSoonReminders } = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const open = reminders.filter((r) => !r.completed);
    const overdue = open.filter((r) => r.dueDate < todayStr).length;
    const sorted = [...open].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    const weekOut = addDaysYmd(todayStr, 7);
    const dueSoon = sorted.filter((r) => r.dueDate <= weekOut);
    return {
      openRemindersCount: open.length,
      overdueReminderCount: overdue,
      dueSoonReminders: dueSoon.slice(0, 5),
    };
  }, [reminders]);

  const value = useMemo(
    () => ({
      sentInvites,
      favorites,
      reminders,
      hasActiveInviteTo,
      sendInvite,
      setInviteStatus,
      isFavorite,
      toggleFavorite,
      updateFavoriteNote,
      removeFavorite,
      addReminder,
      completeReminder,
      snoozeReminder,
      openRemindersCount,
      overdueReminderCount,
      dueSoonReminders,
    }),
    [
      sentInvites,
      favorites,
      reminders,
      hasActiveInviteTo,
      sendInvite,
      setInviteStatus,
      isFavorite,
      toggleFavorite,
      updateFavoriteNote,
      removeFavorite,
      addReminder,
      completeReminder,
      snoozeReminder,
      openRemindersCount,
      overdueReminderCount,
      dueSoonReminders,
    ],
  );

  return (
    <SellerWorkspaceContext.Provider value={value}>{children}</SellerWorkspaceContext.Provider>
  );
}

export function useSellerWorkspace() {
  const ctx = useContext(SellerWorkspaceContext);
  if (!ctx) {
    throw new Error('useSellerWorkspace must be used within SellerWorkspaceProvider');
  }
  return ctx;
}
