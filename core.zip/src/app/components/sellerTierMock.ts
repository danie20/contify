import type { BusinessTier } from './SellerOnboarding';

/** Tier labels for mock sellers across Discover, RFLS flow, negotiations, and connections (demo data). */
const MOCK_SELLER_TIER_BY_NAME: Partial<Record<string, BusinessTier>> = {
  'Premium Electronics Store': 'large',
  'Fashion Forward Boutique': 'mid',
  'Collectibles Warehouse': 'mid',
  'Home Decor Haven': 'small',
  'Sports Gear Pro': 'large',
  'Vintage Treasures': 'consumer',
  'TechVault Outlet': 'mid',
  'Urban Streetwear Co.': 'small',
  'Gaming Legends Shop': 'mid',
  'Organic Beauty Lab': 'small',
  'Outdoor Adventure Supply': 'mid',
  'Luxury Watch Exchange': 'large',
  'Pet Paradise Store': 'consumer',
  'Artisan Coffee Roasters': 'small',
  'Kids Toy Universe': 'consumer',
  'Handmade Jewelry Loft': 'consumer',
  'Fitness Essentials Hub': 'small',
  'Retro Vinyl & Audio': 'consumer',
  'Smart Home Direct': 'mid',
  'Board Game Bazaar': 'small',
  'Sneakerhead Archive': 'mid',
  'Eco Living Marketplace': 'small',
  'Camera Gear Pro Shop': 'mid',
  'Craft Beer Collective': 'small',
};

/** Discover seller cards — aligned with `/apply?seller=` ids. */
export const DISCOVER_SELLER_ID_TO_TIER: Record<number, BusinessTier> = {
  1: 'large',
  2: 'mid',
  3: 'mid',
  4: 'small',
  5: 'large',
  6: 'consumer',
};

export function mockSellerTierForDisplay(name: string, seed?: number): BusinessTier {
  const byName = MOCK_SELLER_TIER_BY_NAME[name];
  if (byName) return byName;
  if (seed != null && Number.isFinite(seed)) {
    const tiers: BusinessTier[] = ['consumer', 'small', 'mid', 'large'];
    return tiers[Math.abs(seed) % 4];
  }
  return 'small';
}

export function tierForDiscoverSellerId(id: string | number | null): BusinessTier | null {
  if (id === '' || id == null) return null;
  const n = typeof id === 'string' ? Number(id) : id;
  if (!Number.isFinite(n)) return null;
  return DISCOVER_SELLER_ID_TO_TIER[n] ?? null;
}
