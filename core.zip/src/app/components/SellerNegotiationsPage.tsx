import { Negotiations } from './Negotiations';

/** Seller portal entry: same negotiation UI with `mode="seller"` and Sports Gear Pro mock threads. */
export function SellerNegotiationsPage() {
  return <Negotiations mode="seller" />;
}
