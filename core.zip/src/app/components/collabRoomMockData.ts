import type { CollabRoomState } from './CollabRoomTypes';

function id() {
  return `c-${Math.random().toString(36).slice(2, 10)}`;
}

/** Seeded rooms for demo RFLS ids (aligned with ApplicationStatus / Negotiations mocks). */
export const MOCK_COLLAB_BY_RFLS_ID: Record<number, CollabRoomState> = {
  1: {
    rflsId: 1,
    sellerName: 'Premium Electronics Store',
    influencerName: 'Alex Rivera',
    platform: 'eBay Live',
    checklist: [
      { id: id(), label: 'Confirm inventory SKU list for stream', done: false },
      { id: id(), label: 'Ship demo units to creator (tracked)', done: false },
      { id: id(), label: 'Legal: usage rights for product B-roll', done: true },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Intro + hook', notes: 'Brand story, tonight’s deals' },
      { id: id(), startTime: '0:08', segment: 'Featured drops', notes: '3 hero SKUs, rotating bids' },
      { id: id(), startTime: '0:25', segment: 'Q&A + bundles', notes: 'Accessory bundles, shipping SLA' },
    ],
    assets: [
      { id: id(), name: 'Brand guidelines (PDF)', url: '#' },
      { id: id(), name: 'Product hero images', url: '#' },
    ],
    deadlines: [
      { id: id(), label: 'Final run-of-show sign-off', dueDate: '2026-05-12', done: false },
      { id: id(), label: 'Tracking numbers for demo units', dueDate: '2026-05-10', done: false },
    ],
    chat: [
      {
        id: id(),
        sender: 'seller',
        authorLabel: 'Premium Electronics',
        content: 'Uploaded rough SKU list in Assets — flag anything you can’t feature.',
        createdAt: new Date().toISOString(),
      },
      {
        id: id(),
        sender: 'influencer',
        authorLabel: 'Alex Rivera',
        content: 'Looks good. I’ll trim to 12 SKUs for the first hour.',
        createdAt: new Date().toISOString(),
      },
    ],
  },
  2: {
    rflsId: 2,
    sellerName: 'Fashion Forward Boutique',
    influencerName: 'Alex Rivera',
    platform: 'eBay Live',
    checklist: [
      { id: id(), label: 'Share sizing chart + return policy', done: true },
      { id: id(), label: 'Approve mannequin vs flat lay shots', done: false },
      { id: id(), label: 'Music / license clearance', done: false },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Welcome + collection theme', notes: '' },
      { id: id(), startTime: '0:10', segment: 'Try-on block', notes: '3 outfits, quick changes' },
    ],
    assets: [{ id: id(), name: 'Spring lookbook', url: '#' }],
    deadlines: [{ id: id(), label: 'Portfolio review deadline', dueDate: '2026-05-08', done: false }],
    chat: [],
  },
  3: {
    rflsId: 3,
    sellerName: 'Sports Gear Pro',
    influencerName: 'Alex Rivera',
    platform: 'eBay Live',
    checklist: [
      { id: id(), label: 'Contract countersigned', done: true },
      { id: id(), label: 'Kickoff call scheduled', done: true },
      { id: id(), label: 'Sample kits shipped', done: false },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Warm-up + audience polls', notes: '' },
      { id: id(), startTime: '0:12', segment: 'Outlet running line', notes: '12 SKU bundles max' },
      { id: id(), startTime: '0:35', segment: 'Flash close', notes: 'Free shipping threshold' },
    ],
    assets: [
      { id: id(), name: 'SKU bundle sheet', url: '#' },
      { id: id(), name: 'Stream overlays pack', url: '#' },
    ],
    deadlines: [
      { id: id(), label: 'Go-live dry run', dueDate: '2026-05-05', done: true },
      { id: id(), label: 'Live date', dueDate: '2026-05-18', done: false },
    ],
    chat: [
      {
        id: id(),
        sender: 'system',
        authorLabel: 'ConnectIn',
        content: 'RFLS approved — this room is your shared workspace for the deal.',
        createdAt: new Date().toISOString(),
      },
    ],
  },
  1204: {
    rflsId: 1204,
    sellerName: 'Sports Gear Pro',
    influencerName: 'Taylor Brooks',
    platform: 'eBay Live',
    checklist: [
      { id: id(), label: 'Confirm May slot calendar', done: false },
      { id: id(), label: 'Rate + commission final', done: false },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Intro', notes: 'Outlet running line focus' },
      { id: id(), startTime: '0:15', segment: 'Multi-SKU wheel', notes: 'Up to 12 SKUs' },
    ],
    assets: [{ id: id(), name: 'Reference VOD (seller)', url: '#' }],
    deadlines: [{ id: id(), label: 'Payment terms locked', dueDate: '2026-05-09', done: false }],
    chat: [],
  },
  1198: {
    rflsId: 1198,
    sellerName: 'Sports Gear Pro',
    influencerName: 'Morgan Patel',
    platform: 'Whatnot',
    checklist: [
      { id: id(), label: '12 SKU bundle confirmation', done: true },
      { id: id(), label: 'Reference VODs shared', done: true },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Sports-tech positioning', notes: '' },
      { id: id(), startTime: '0:20', segment: 'Drop mechanics', notes: 'Runner for SKUs' },
    ],
    assets: [],
    deadlines: [{ id: id(), label: 'Ship samples', dueDate: '2026-05-11', done: false }],
    chat: [],
  },
};

/** Deep clone for immutable seed application. */
export function cloneCollabState(source: CollabRoomState): CollabRoomState {
  return JSON.parse(JSON.stringify(source)) as CollabRoomState;
}

export function getCollabSeedForRfls(rflsId: number): CollabRoomState {
  const seed = MOCK_COLLAB_BY_RFLS_ID[rflsId];
  if (seed) return cloneCollabState(seed);
  return {
    rflsId,
    sellerName: 'Seller',
    influencerName: 'Creator',
    platform: 'Live commerce',
    checklist: [
      { id: id(), label: 'Kickoff checklist item', done: false },
      { id: id(), label: 'Share key links & assets', done: false },
    ],
    runOfShow: [
      { id: id(), startTime: '0:00', segment: 'Opening', notes: 'Add segments as you plan the show.' },
    ],
    assets: [],
    deadlines: [],
    chat: [
      {
        id: id(),
        sender: 'system',
        authorLabel: 'ConnectIn',
        content: 'Start planning — checklist, run-of-show, and chat stay in sync for this RFLS (demo).',
        createdAt: new Date().toISOString(),
      },
    ],
  };
}
