import { Link } from 'react-router';
import { isSellerOnboardingComplete } from './SellerOnboarding';
import { SellerTierBadge } from './SellerTierBadge';
import {
  ArrowRight,
  Bell,
  Heart,
  Inbox,
  LayoutGrid,
  Lightbulb,
  Send,
  Users,
} from 'lucide-react';
import { useSellerWorkspace } from './SellerWorkspaceContext';

function formatShort(iso: string) {
  try {
    return new Date(iso).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function SellerDashboard() {
  const {
    sentInvites,
    favorites,
    openRemindersCount,
    overdueReminderCount,
    dueSoonReminders,
    reminders,
  } = useSellerWorkspace();

  const activePipeline = sentInvites.filter(
    (i) => i.status === 'pending' || i.status === 'viewed',
  ).length;
  const recentInvites = [...sentInvites].sort((a, b) => b.sentAt.localeCompare(a.sentAt)).slice(0, 5);

  const onboardingDone = isSellerOnboardingComplete();

  return (
    <div className="max-w-7xl mx-auto p-6">
      {!onboardingDone && (
        <div className="mb-6 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/90 dark:bg-amber-950/30 px-4 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <p className="text-sm text-amber-950 dark:text-amber-100">
            <strong className="font-semibold">Finish seller onboarding</strong> — size, channels, and goals help us
            tailor your workspace (demo).
          </p>
          <Link
            to="/seller/onboarding"
            className="inline-flex shrink-0 items-center justify-center rounded-lg bg-amber-600 text-white px-4 py-2 text-sm font-medium hover:bg-amber-700"
          >
            Continue setup
          </Link>
        </div>
      )}
      <div className="mb-8">
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">Seller workspace</h2>
          {onboardingDone ? <SellerTierBadge variant="inline" /> : null}
        </div>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl">
          Track outreach, saved creators, and follow-ups in one place. Everything below is in-memory for this mock
          (a full page refresh resets to the seeded sample data).
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        <Link
          to="/seller/invites"
          className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 hover:border-emerald-200 hover:shadow transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-500">Invites sent</span>
            <Send className="w-5 h-5 text-emerald-600" />
          </div>
          <p className="text-3xl font-semibold text-gray-900">{sentInvites.length}</p>
          <p className="text-xs text-gray-500 mt-1 flex items-center gap-1 group-hover:text-emerald-700">
            {activePipeline} awaiting response
            <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </Link>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-500">Active pipeline</span>
            <Inbox className="w-5 h-5 text-amber-600" />
          </div>
          <p className="text-3xl font-semibold text-gray-900">{activePipeline}</p>
          <p className="text-xs text-gray-500 mt-1">Pending or viewed — needs follow-up</p>
        </div>

        <Link
          to="/seller/favorites"
          className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 hover:border-emerald-200 hover:shadow transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-500">Favorites</span>
            <Heart className="w-5 h-5 text-rose-500" />
          </div>
          <p className="text-3xl font-semibold text-gray-900">{favorites.length}</p>
          <p className="text-xs text-gray-500 mt-1 group-hover:text-emerald-700 flex items-center gap-1">
            Saved creators
            <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </Link>

        <Link
          to="/seller/reminders"
          className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 hover:border-emerald-200 hover:shadow transition-all group relative"
        >
          {overdueReminderCount > 0 && (
            <span className="absolute top-3 right-3 min-w-[22px] h-[22px] px-1.5 rounded-full bg-red-500 text-white text-[11px] font-bold flex items-center justify-center">
              {overdueReminderCount}
            </span>
          )}
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-500">Open reminders</span>
            <Bell className="w-5 h-5 text-violet-600" />
          </div>
          <p className="text-3xl font-semibold text-gray-900">{openRemindersCount}</p>
          <p className="text-xs text-gray-500 mt-1 group-hover:text-emerald-700 flex items-center gap-1">
            Follow-ups scheduled
            <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 bg-amber-50 border border-amber-100 rounded-xl p-5 flex gap-4">
          <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
            <Lightbulb className="w-5 h-5 text-amber-800" />
          </div>
          <div>
            <h3 className="font-semibold text-amber-950 mb-1">Outreach tips</h3>
            <ul className="text-sm text-amber-950/85 space-y-1.5 list-disc pl-4">
              <li>Follow up within 48 hours when an invite shows as viewed but not accepted.</li>
              <li>Star creators you want to pitch later — add a short note so your team knows why they matter.</li>
              <li>When a creator declines, update status here so you can re-invite later with a fresh angle.</li>
            </ul>
          </div>
        </div>

        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-5 h-5 text-emerald-800" />
            <h3 className="font-semibold text-emerald-950">Quick actions</h3>
          </div>
          <div className="flex flex-col gap-2">
            <Link
              to="/seller/find-influencers"
              className="text-sm font-medium text-emerald-800 hover:underline"
            >
              Search directory & send invites
            </Link>
            <Link to="/seller/reminders" className="text-sm font-medium text-emerald-800 hover:underline">
              Add a follow-up reminder
            </Link>
            <Link to="/seller/negotiations" className="text-sm font-medium text-emerald-800 hover:underline">
              Payment negotiations with creators
            </Link>
            <Link
              to="/seller/collab/1204"
              className="text-sm font-medium text-emerald-800 hover:underline inline-flex items-center gap-1"
            >
              <LayoutGrid className="w-3.5 h-3.5 opacity-80" />
              Live Collab Room (demo RFLS-01204)
            </Link>
            <Link to="/seller/invites" className="text-sm font-medium text-emerald-800 hover:underline">
              Review full invite history
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-900">Recent invites</h3>
            <Link to="/seller/invites" className="text-sm text-emerald-700 hover:underline font-medium">
              View all
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {recentInvites.length === 0 ? (
              <p className="p-6 text-sm text-gray-500">No invites yet. Start from Find influencers.</p>
            ) : (
              recentInvites.map((inv) => (
                <div key={inv.id} className="px-5 py-4 flex gap-3">
                  <img src={inv.avatar} alt="" className="w-10 h-10 rounded-full object-cover border border-gray-100" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-900 truncate">{inv.displayName}</p>
                    <p className="text-xs text-gray-500">{formatShort(inv.sentAt)} · {inv.campaign || 'No campaign title'}</p>
                    <span
                      className={`inline-block mt-1.5 text-[11px] px-2 py-0.5 rounded-full font-medium ${
                        inv.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : inv.status === 'viewed'
                            ? 'bg-sky-100 text-sky-800'
                            : inv.status === 'accepted'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-900">Follow-ups (next 7 days)</h3>
            <Link to="/seller/reminders" className="text-sm text-emerald-700 hover:underline font-medium">
              Manage
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {dueSoonReminders.length === 0 ? (
              <p className="p-6 text-sm text-gray-500">
                {reminders.filter((r) => !r.completed).length === 0
                  ? 'No open reminders. Add one from the Reminders page.'
                  : 'Nothing due in the next week.'}
              </p>
            ) : (
              dueSoonReminders.map((r) => {
                const todayStr = new Date().toISOString().slice(0, 10);
                const overdue = r.dueDate < todayStr;
                return (
                  <div key={r.id} className="px-5 py-4 flex gap-3">
                    <div
                      className={`w-1.5 rounded-full shrink-0 mt-1 ${overdue ? 'bg-red-500' : 'bg-violet-400'}`}
                    />
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900">{r.displayName}</p>
                      <p className="text-xs text-gray-500">
                        Due {r.dueDate}
                        {overdue ? ' · Overdue' : ''}
                      </p>
                      <p className="text-sm text-gray-600 mt-1 line-clamp-2">{r.note}</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
