import { RouterProvider } from 'react-router';
import { router } from './routes';
import { AppThemeProvider } from './components/AppThemeProvider';

export default function App() {
  return (
    <AppThemeProvider>
      <RouterProvider router={router} />
    </AppThemeProvider>
  );
}