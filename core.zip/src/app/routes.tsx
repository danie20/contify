import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/RootLayout";
import { DiscoverSellers } from "./components/DiscoverSellers";
import { ApplicationForm } from "./components/ApplicationForm";
import { ApplicationStatus } from "./components/ApplicationStatus";
import { Negotiations } from "./components/Negotiations";
import { InfluencerOnboarding } from "./components/InfluencerOnboarding";
import { Dashboard } from "./components/Dashboard";
import { ActiveConnections } from "./components/ActiveConnections";
import { HelpPage } from "./components/HelpPage";
import { SupportPage } from "./components/SupportPage";
import { ContactPage } from "./components/ContactPage";
import { TermsPage } from "./components/TermsPage";
import { PrivacyPage } from "./components/PrivacyPage";
import { SignIn } from "./components/SignIn";
import { SignUp } from "./components/SignUp";
import { SellerSignIn } from "./components/SellerSignIn";
import { SellerLayout } from "./components/SellerLayout";
import { SellerFindInfluencers } from "./components/SellerFindInfluencers";
import { SellerDashboard } from "./components/SellerDashboard";
import { SellerInvitesPage } from "./components/SellerInvitesPage";
import { SellerFavoritesPage } from "./components/SellerFavoritesPage";
import { SellerRemindersPage } from "./components/SellerRemindersPage";
import { SellerNegotiationsPage } from "./components/SellerNegotiationsPage";
import { SellerOnboarding } from "./components/SellerOnboarding";
import { CollabRoomPage } from "./components/CollabRoomPage";

export const router = createBrowserRouter([
  {
    path: "/signin",
    Component: SignIn,
  },
  {
    path: "/seller/signin",
    Component: SellerSignIn,
  },
  {
    path: "/signup",
    Component: SignUp,
  },
  {
    path: "/seller",
    Component: SellerLayout,
    children: [
      { index: true, Component: SellerDashboard },
      { path: "onboarding", Component: SellerOnboarding },
      { path: "find-influencers", Component: SellerFindInfluencers },
      { path: "invites", Component: SellerInvitesPage },
      { path: "favorites", Component: SellerFavoritesPage },
      { path: "reminders", Component: SellerRemindersPage },
      { path: "negotiations", Component: SellerNegotiationsPage },
      { path: "collab/:rflsId", Component: CollabRoomPage },
    ],
  },
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "active-connections", Component: ActiveConnections },
      { path: "discover", Component: DiscoverSellers },
      { path: "apply", Component: ApplicationForm },
      { path: "application-status", Component: ApplicationStatus },
      { path: "negotiations", Component: Negotiations },
      { path: "onboarding", Component: InfluencerOnboarding },
      { path: "help", Component: HelpPage },
      { path: "support", Component: SupportPage },
      { path: "contact", Component: ContactPage },
      { path: "terms", Component: TermsPage },
      { path: "privacy", Component: PrivacyPage },
      { path: "collab/:rflsId", Component: CollabRoomPage },
    ],
  },
]);
