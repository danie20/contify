
  # hackweek

  This is a code bundle for hackweek. The original project is available at https://www.figma.com/design/KkHDkMsLyjIH7WPRlmMzEJ/hackweek.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  