# LiveLoop Seller Acquisition, Agency, and Enterprise Flow

## Decision

LiveLoop uses three separate operating models:

| Model | Operator | Primary purpose | Access boundary |
|---|---|---|---|
| Admin Seller Discovery | LiveLoop Operations | Find, qualify, and invite seller leads | Public/permitted discovery until seller consent |
| Independent Agency | Registered agency organization | Manage creators and campaigns for seller clients | Delegated access from each seller |
| Enterprise Marketplace Partner | eBay, Walmart, or another marketplace | Enable a seller ecosystem through an approved integration | Partner agreement plus seller consent for protected data |

An agency is not an enterprise marketplace and does not automatically receive
access to seller leads. A discovered lead is not a verified seller listing.

## Implemented route map

### LiveLoop Admin

- [Seller discovery](http://localhost:3000/admin/seller-discovery)
- [Enterprise marketplace partners](http://localhost:3000/admin/enterprise)
- [Admin command center](http://localhost:3000/admin)

### Enterprise Partner Access

- [Partner sign-in](http://localhost:3000/enterprise/signin)
- [Invitation activation](http://localhost:3000/enterprise/activate/EBAY-2026-DEMO)
- [Partner onboarding](http://localhost:3000/enterprise/onboarding)
- [Enterprise portal](http://localhost:3000/enterprise)
- [Seller enablement](http://localhost:3000/enterprise/sellers)
- [Connectors and OAuth](http://localhost:3000/enterprise/connectors)
- [Team and access](http://localhost:3000/enterprise/team)
- [Program performance](http://localhost:3000/enterprise/performance)

### Independent Agency

- [Agency registration](http://localhost:3000/agency/register)
- [Agency portfolio](http://localhost:3000/agency)
- [Seller clients](http://localhost:3000/agency/clients)
- [Agency campaigns](http://localhost:3000/agency/campaigns)
- [Team and access](http://localhost:3000/agency/team)

## Flow 1 — Admin seller discovery

```text
Connector search/import
    → Discovered seller lead
    → Normalize and deduplicate
    → AI qualification
    → Admin review
    → Seller invitation
    → Seller claims account
    → Business verification
    → Marketplace OAuth/consent
    → Influencer-ready seller
```

### Admin capabilities

1. Run an individual connector or all connectors.
2. Review connector health, provenance, scope, and last-sync status.
3. Search and filter internal seller leads.
4. Review AI fit, sales signals, category, marketplace, and acquisition owner.
5. Qualify or suppress a lead.
6. Invite a qualified seller to claim a LiveLoop account.
7. Monitor invitation, claim, verification, and authorization stages.
8. Keep unclaimed leads hidden from influencer discovery.

### Lead lifecycle

```text
Discovered
    → Admin review
    → Ready to invite
    → Invited
    → Claimed
    → Verified
    → Connected
    → Influencer-ready
```

Required production records:

- Marketplace and seller identifiers.
- Source type, source URL, retrieval time, and permitted-use basis.
- Normalized seller identity and duplicate candidates.
- AI score with evidence and model version.
- Suppression, outreach, claim, verification, and authorization history.
- Connector job, quota, error, and credential-health metadata.

## Flow 2 — Independent agency

```text
Agency registration
    → Business and owner verification
    → Team and role setup
    → Seller-client invitation
    → Seller grants delegated permissions
    → Agency manages authorized campaigns
    → Seller can change or revoke access
```

### Registration

The agency submits its legal business details, services, owner, team size, and
operating-policy acceptance. LiveLoop verifies the agency before it can invite
seller clients.

### Seller-client relationship

Each seller:

1. Receives an agency invitation.
2. Signs in or creates a LiveLoop seller organization.
3. Reviews the agency identity.
4. Grants specific permissions.
5. Selects which marketplace connections and data the agency may use.
6. Can amend or revoke delegation at any time.

Example permission groups:

- View profile and catalog.
- Discover and shortlist creators.
- Draft campaign briefs.
- Send proposals.
- Negotiate within seller limits.
- Approve campaigns.
- View analytics.
- View financial data.
- Manage payouts or billing.

Sensitive permissions should require seller-owner approval and cannot be
inherited from another client.

### Agency AI assistant

The portfolio copilot may:

- Identify creator opportunities across authorized clients.
- Detect creator conflicts and schedule overlap.
- Recommend creator allocation by predicted incremental value.
- Summarize portfolio performance.
- Draft plans for human review.

It must preserve seller-level data isolation and explain which authorized data
supports a recommendation.

## Flow 3 — Enterprise marketplace partner

```text
Commercial partner agreement
    → Integration and security approval
    → Sandbox validation
    → Eligible seller feed or permitted discovery
    → Seller invitation
    → Seller claim and OAuth consent
    → Verified LiveLoop seller workspace
    → Creator matching and campaigns
```

### Partner authentication and activation

```text
LiveLoop Admin creates partner invitation
    → Invited administrator opens single-use activation link
    → Verified work identity and organization domain
    → Enterprise SSO authentication
    → Partner terms and role acceptance
    → Organization, security, connector, and consent onboarding
    → LiveLoop production approval
    → Isolated enterprise partner portal
```

Authentication requirements:

- Enterprise SSO using the partner identity provider.
- Domain verification and mandatory multi-factor authentication.
- Time-limited, single-use invitation tokens.
- Separate authentication and authorization decisions.
- Server-side organization membership and role enforcement.
- Session expiry, step-up authentication, and access audit events.

The current application implements this as an interactive product mock. A
production version must use a supported external identity-provider integration
and enforce all organization and role authorization on the server.

Enterprise partner controls include:

- Contract and approved-use-case status.
- Connector environment and health.
- API scopes and security review.
- Seller eligibility and invitation rules.
- Seller-consent conversion.
- Enabled, pending, revoked, and failed connections.
- Program-level campaign and performance reporting.
- Incident response and integration kill switch.

The partner may operate a seller program, but protected seller data must follow
the approved API scope, agreement, and applicable seller authorization.

## Shared governance rules

1. Never expose an unclaimed lead to creators.
2. Never infer seller consent from public availability.
3. Store data provenance and permitted-use basis.
4. Enforce tenant isolation for every seller organization.
5. Keep agency and enterprise roles distinct in authorization checks.
6. Require step-up approval for sensitive access or irreversible actions.
7. Record permission grants, revocations, connector access, invitations, and
   administrative overrides in the audit trail.
8. Provide suppression and deletion workflows.
9. Rate-limit imports and outreach.
10. Validate provider terms before enabling a production connector.

## Recommended backend boundaries

```text
Identity and Organizations
├── SellerOrganization
├── AgencyOrganization
├── EnterprisePartner
└── Membership and Role

Acquisition
├── Connector
├── ConnectorJob
├── SellerLead
├── LeadEvidence
├── LeadScore
└── SellerInvitation

Delegation
├── AgencySellerRelationship
├── PermissionGrant
├── ApprovalPolicy
└── RevocationEvent

Marketplace Connections
├── OAuthConnection
├── AuthorizedScope
├── SyncJob
└── ConnectorIncident
```

## Production delivery phases

### Phase 1 — Operating model and agency foundation

- Organization types and role-based authorization.
- Agency verification, team management, and seller delegation.
- Tenant isolation and audit coverage.

### Phase 2 — Admin discovery foundation

- Manual leads and one permitted connector.
- Normalization, deduplication, provenance, review, and invitation.
- Claim, verification, and suppression workflows.

### Phase 3 — Enterprise partner integration

- Partner configuration and approval workflow.
- Sandbox connector and OAuth consent.
- Seller eligibility, invitations, and connection health.

### Phase 4 — AI and operations

- Explainable lead scoring.
- Portfolio recommendations within delegated data.
- Connector monitoring, SLA alerts, and admin reporting.

## Acceptance criteria

- Admin can run a mock connector and advance a lead through the acquisition
  stages.
- A lead cannot become creator-visible before claim and verification.
- Agency registration clearly states the delegated-client model.
- Agency can manage multiple seller clients without mixing their data.
- Seller access is explicitly granted and revocable.
- Enterprise partner screens show agreement, connector, consent, and rollout
  state.
- All routes remain usable on desktop and mobile layouts.
