# LiveLoop Application Flow Guide

## Public product guidance

- AI Help Center: [http://localhost:3000/help](http://localhost:3000/help)
- LiveLoop AI product overview: [http://localhost:3000/ai](http://localhost:3000/ai)
- Creator sign-in story: [http://localhost:3000/signin](http://localhost:3000/signin)
- Seller sign-in story: [http://localhost:3000/seller/signin](http://localhost:3000/seller/signin)
- Customer support and tickets: [http://localhost:3000/support](http://localhost:3000/support)

The Help Center lets visitors switch among Seller, Creator, Agency, and
Enterprise guidance. Its guided AI preview answers common product questions,
links to the relevant workspace, and hands account-specific issues to the
support ticket flow.

For a consolidated explanation of every AI capability, see
[LiveLoop AI Features](LIVELOOP_AI_FEATURES.md).

This is the navigation and product-flow reference for the runnable LiveLoop
application in `connectin-app`.

Local application base URL: [http://localhost:3000](http://localhost:3000)

## 1. Quick route map

### Shared entry routes

| Experience | Direct link | Purpose |
| --- | --- | --- |
| Default application | [Open](http://localhost:3000) | Opens the seller workspace |
| Combined login | [Open](http://localhost:3000/login) | Switch between seller and creator sign-in |
| Creator sign-in | [Open](http://localhost:3000/signin) | Creator-focused standalone sign-in |
| Seller sign-in | [Open](http://localhost:3000/seller/signin) | Seller-focused standalone sign-in |
| Generic profile | [Open](http://localhost:3000/profile) | Seller profile/settings entry |
| Generic subscription | [Open](http://localhost:3000/subscription) | Seller plan and billing entry |
| Generic onboarding | [Open](http://localhost:3000/onboarding) | Seller onboarding entry |
| Admin control plane | [Open](http://localhost:3000/admin) | Marketplace governance, safety, and performance |
| Customer support portal | [Open](http://localhost:3000/support) | Create, track, and reply to support tickets |
| Admin support desk | [Open](http://localhost:3000/admin/support) | Triage, assign, escalate, and resolve tickets |

### Seller routes

| Screen | Direct link | Primary goal |
| --- | --- | --- |
| Seller home | [Open](http://localhost:3000/seller) | See revenue, active campaigns, and the AI Sales Boost |
| Discover creators | [Open](http://localhost:3000/seller/discover) | Find and evaluate influencer partners |
| Campaigns | [Open](http://localhost:3000/seller/campaigns) | Manage RFLS requests and campaign preparation |
| Negotiations | [Open](http://localhost:3000/seller/negotiations) | Discuss and accept commercial terms with a creator |
| Collaboration room | [Open](http://localhost:3000/seller/collab/RFLS-02841) | Prepare an accepted campaign with its creator |
| Performance | [Open](http://localhost:3000/seller/performance) | Understand revenue and creator performance |
| Seller profile | [Open](http://localhost:3000/seller/profile) | Edit business and commerce information |
| Seller plans | [Open](http://localhost:3000/seller/subscription) | Compare plans and review billing |
| Seller onboarding | [Open](http://localhost:3000/seller/onboarding) | Configure business goals and commerce data |

### Creator routes

| Screen | Direct link | Primary goal |
| --- | --- | --- |
| Creator home | [Open](http://localhost:3000/creator) | See earnings, active work, and the AI Copilot |
| Discover sellers | [Open](http://localhost:3000/creator/discover) | Find aligned seller opportunities |
| Campaigns | [Open](http://localhost:3000/creator/campaigns) | Manage RFLS requests and live preparation |
| Negotiations | [Open](http://localhost:3000/creator/negotiations) | Discuss and accept commercial terms with a seller |
| Collaboration room | [Open](http://localhost:3000/creator/collab/RFLS-02841) | Prepare an accepted campaign with its seller |
| Performance | [Open](http://localhost:3000/creator/performance) | Understand earnings and content performance |
| Creator profile | [Open](http://localhost:3000/creator/profile) | Edit creator identity and connected channels |
| Creator plans | [Open](http://localhost:3000/creator/subscription) | Compare creator plans and billing |
| Creator onboarding | [Open](http://localhost:3000/creator/onboarding) | Configure audience, goals, and social data |

## 2. Global navigation

### Desktop

The left sidebar contains:

1. **Seller / Creator switch** — changes the current workspace persona.
2. **Home** — role-specific dashboard.
3. **Discover** — seller sees creators; creator sees sellers.
4. **Campaigns** — RFLS and collaboration pipeline.
5. **Performance** — role-specific commercial analytics.
6. **Profile & settings** — profile, connections, billing, and onboarding.

The top bar contains:

- Current plan badge → opens Subscription and Billing.
- Search → opens the role-specific Discover screen.
- Notifications.
- Account avatar → opens Profile and Settings on mobile.

### Mobile

The fixed bottom dock contains Home, Discover, Campaigns, and Performance.
Use the top-right avatar to reach Profile, Onboarding, and Subscription.

## 3. Authentication flow

### Combined sign-in

Entry: [Login](http://localhost:3000/login)

1. Select **I’m a seller** or **I’m a creator**.
2. Continue with Google, or use the populated demonstration email/password.
3. Select **Sign in**.
4. The application opens the selected role’s Home dashboard.
5. Select **Create your account** to enter onboarding.

### Dedicated sign-in entries

- Creator: [http://localhost:3000/signin](http://localhost:3000/signin)
- Seller: [http://localhost:3000/seller/signin](http://localhost:3000/seller/signin)

Current implementation note: this is a complete interactive sign-in
demonstration, not production authentication. A production release still needs
an approved identity provider, server sessions, authorization, and recovery
flows.

## 4. Seller end-to-end flow

### Flow S1 — Seller onboarding

Entry: [Seller onboarding](http://localhost:3000/seller/onboarding)

1. **Your profile**
   - Enter business name.
   - Choose the primary category.
   - Add a short seller introduction.
2. **Business goals**
   - Increase live revenue.
   - Launch products.
   - Find repeat creators.
   - Reach new audiences.
3. **Connect data**
   - Shopify.
   - TikTok Shop.
   - Google Analytics.
4. Select **Finish setup**.
5. Exit: Seller Home.

The connected data is intended to power inventory-aware matching, revenue
attribution, offer recommendations, and AI Sales Boost suggestions.

### Flow S2 — Seller Home and AI Sales Boost

Entry: [Seller Home](http://localhost:3000/seller)

The seller sees:

- Attributed revenue.
- Live conversion.
- Active campaigns.
- Orders from live campaigns.
- Highest-impact AI recommendation.
- Expected revenue lift and confidence.
- Audience-fit evidence, offer guidance, and best live window.
- Next scheduled campaign and readiness checklist.
- AI-ranked creator matches.

Primary actions:

- **Build this campaign** → adds the recommendation to the campaign flow.
- **See AI rationale** → expands evidence and risk notes.
- **Open collaboration room** → enters the selected campaign workspace.
- **View all matches** → Seller Discover.

### Flow S3 — Discover creators

Entry: [Seller Discover](http://localhost:3000/seller/discover)

1. Search by creator, category, or audience.
2. Filter by category, platform, or location.
3. Review AI fit score.
4. Review audience size, average conversion, channel, and category tags.
5. Read **Why this fits** for an explainable match.
6. Select **Invite to campaign**.
7. Exit: Commercial negotiation with a drafted invitation.

### Flow S4 — RFLS and commercial negotiation

Entry: [Seller Campaigns](http://localhost:3000/seller/campaigns)

1. Review Active, Completed, or Draft campaigns.
2. Select an RFLS from the campaign list.
3. Select **Review negotiation**, or open
   [Seller Negotiations](http://localhost:3000/seller/negotiations) directly.
4. Review the lifecycle:
   - Proposed.
   - Negotiating.
   - Accepted.
   - Preparing.
5. Compare the original proposal with the latest counter offer.
6. Review the flat rate, commission, payment terms, revisions, usage, and
   deliverables.
7. Use the private deal thread to discuss the offer.
8. Choose **Accept offer**, **Counter offer**, or **Decline**.
9. Accepted terms are locked and the collaboration room is unlocked.

### Flow S5 — Shared seller collaboration room

Entry:
[Seller Collaboration Room](http://localhost:3000/seller/collab/RFLS-02841)

1. Confirm campaign readiness and remaining shared tasks.
2. Use **Checklist** to complete seller- and creator-owned preparation.
3. Use **Run of show** to review the live sequence and responsibility at each
   point.
4. Use **Assets & links** to review briefs, teaser cuts, approved claims,
   tracking, and promo links.
5. Use **Deadlines** to review delivery, rehearsal, approval, live, and
   performance milestones.
6. Use **Chat** to coordinate with the creator in context.
7. Review the locked commercial terms and AI readiness warning in the side
   panel.

### Flow S6 — Seller performance

Entry: [Seller Performance](http://localhost:3000/seller/performance)

The seller sees:

- Live-commerce revenue.
- Return on spend.
- Average order value.
- Creator repeat rate.
- Revenue trend.
- AI explanation of the largest performance driver.
- Campaign-by-campaign views, conversion, revenue, and trend.

Primary action: **Generate next playbook** turns the observed performance into
the next recommended campaign strategy.

### Flow S7 — Seller profile and connected commerce

Entry: [Seller Profile](http://localhost:3000/seller/profile)

1. Review profile completeness.
2. Update business name, email, location, category, and company description.
3. Review Shopify, TikTok Shop, and inventory connections.
4. Resolve any connection marked **Needs review**.
5. Save changes.

Profile navigation also links to onboarding, notification preferences,
security, and plan/billing.

### Flow S8 — Seller subscription and billing

Entry: [Seller Plans](http://localhost:3000/seller/subscription)

1. Review the current LiveLoop Pro plan and renewal date.
2. Compare Solo, Pro, and Elite plans.
3. Select a different plan.
4. Review or edit the payment method.
5. Review billing history and invoice status.

## 5. Creator end-to-end flow

### Flow C1 — Creator onboarding

Entry: [Creator onboarding](http://localhost:3000/creator/onboarding)

1. **Your profile**
   - Enter creator name.
   - Choose a category.
   - Add an introduction for sellers.
2. **Audience and goals**
   - Grow collaboration income.
   - Find aligned brands.
   - Improve live performance.
   - Build repeat partnerships.
3. **Connect data**
   - TikTok.
   - Instagram.
   - YouTube.
4. Select **Finish setup**.
5. Exit: Creator Home.

### Flow C2 — Creator Home and AI Copilot

Entry: [Creator Home](http://localhost:3000/creator)

The creator sees:

- Earnings this month.
- Live conversion.
- Active collaborations.
- Returning viewers.
- AI pre-live brief.
- Suggested opening hook, product proof, and close.
- Projected live earnings.
- Next live and readiness checklist.
- AI-ranked seller opportunities.

Primary actions:

- **Add to live room** → adds the brief to campaign preparation.
- **See AI rationale** → shows supporting performance evidence.
- **View all matches** → Creator Discover.

### Flow C3 — Discover sellers

Entry: [Creator Discover](http://localhost:3000/creator/discover)

1. Search sellers, categories, or campaigns.
2. Filter opportunities.
3. Review AI fit score.
4. Review estimated fee and commission.
5. Review campaign tags and seller context.
6. Read **Why this fits**.
7. Select **View opportunity**.
8. Exit: Creator commercial negotiation.

### Flow C4 — RFLS and commercial negotiation

Entry: [Creator Campaigns](http://localhost:3000/creator/campaigns)

1. Select an active collaboration.
2. Select **Review negotiation**, or open
   [Creator Negotiations](http://localhost:3000/creator/negotiations) directly.
3. Review the complete proposal and counter-offer history.
4. Discuss the rate, commission, usage, revisions, deliverables, and payment
   timing in the private thread.
5. Choose **Accept offer**, **Counter offer**, or **Decline**.
6. Accepted terms are locked and the collaboration room is unlocked.

### Flow C5 — Shared creator collaboration room

Entry:
[Creator Collaboration Room](http://localhost:3000/creator/collab/RFLS-02841)

The creator sees the same shared campaign state as the seller with
creator-specific message attribution and ownership:

1. Complete creator-owned checklist tasks.
2. Review the run of show and planned offer moment.
3. Upload and review creative assets.
4. Track rehearsal, approval, live, and reporting deadlines.
5. Coordinate in the campaign chat.
6. Use AI Readiness Assist to identify the highest-risk preparation blocker.

### Flow C6 — Creator performance

Entry: [Creator Performance](http://localhost:3000/creator/performance)

The creator sees:

- Total earnings.
- Revenue influenced.
- Average watch time.
- Offer acceptance.
- Earnings trend.
- AI explanation of the strongest content behavior.
- Collaboration-level views, conversion, earnings, and trend.

Primary action: **Generate next playbook** creates coaching guidance for the
next live campaign.

### Flow C7 — Creator profile and social channels

Entry: [Creator Profile](http://localhost:3000/creator/profile)

1. Review profile strength.
2. Update name, email, location, category, and creator description.
3. Review TikTok, Instagram, and YouTube connections.
4. Save changes.

### Flow C7 — Creator subscription and billing

Entry: [Creator Plans](http://localhost:3000/creator/subscription)

1. Review the current Creator Elite plan.
2. Compare Creator, Elite, and Studio plans.
3. Select a plan.
4. Review the payment method.
5. Review billing history.

## 6. Shared campaign lifecycle

```text
Draft
  ↓
Proposed
  ↓
Negotiating
  ↓
Accepted
  ↓
Preparing
  ↓
Live
  ↓
Completed
  ↓
Reported
```

Side or terminal states:

- Declined.
- Cancelled.
- Expired.
- Disputed.

The seller and creator should always see the same source-of-truth campaign
status. In production, transitions should be server-validated and written to an
audit log.

## 7. AI assistance flow

### Seller AI loop

```text
Catalog + inventory + margin
        ↓
Creator and audience matching
        ↓
Offer, bundle, and schedule recommendation
        ↓
Campaign preparation
        ↓
Revenue and conversion measurement
        ↓
Next-best Sales Boost action
```

### Creator AI loop

```text
Audience + channel performance
        ↓
Seller opportunity matching
        ↓
Rate guidance and campaign brief
        ↓
Hook, talking points, and live preparation
        ↓
Earnings and content measurement
        ↓
Personalized coaching action
```

AI recommendations show a confidence score, supporting evidence, and an
explicit user action. They do not automatically send invitations, accept
commercial terms, or change pricing.

## 8. Current implementation coverage

| Flow | Status | Notes |
| --- | --- | --- |
| Seller and creator sign-in | Interactive prototype | Production identity integration remains |
| Seller and creator onboarding | Interactive prototype | Three steps with role-specific content |
| Role-specific Home dashboards | Implemented | Seller AI Sales Boost and Creator AI Copilot |
| Discover creators/sellers | Implemented | Search, filters, AI fit, and campaign action |
| RFLS/campaign pipeline | Implemented | Shared lifecycle and preparation workspace |
| Negotiation | Implemented prototype | Versioned offers, private messages, countering, acceptance, and decline |
| Live collaboration room | Implemented prototype | Shared checklist, run of show, assets, deadlines, chat, and locked terms |
| Performance | Implemented | Role-specific metrics and AI explanation |
| Profile and data connections | Implemented | Editing and connection states are demo interactions |
| Subscription and billing | Implemented | Plan selection and billing are demo interactions |
| Notifications | Placeholder | Dedicated inbox remains |
| Help and support | Implemented prototype | AI Help Center plus customer and admin ticketing routes |
| Persistent database | Planned | D1/SQL model is defined in the full-stack plan |
| Payments and escrow | Planned | Marketplace-readiness phase |

## 9. Admin governance flow

Entry: [Admin control plane](http://localhost:3000/admin)

The admin workspace is intentionally separate from seller and creator
navigation. It is designed for authorized operations, trust and safety,
payments, and support personnel.

### Flow A1 — Command center

The command center shows:

- Open review queue and SLA risk.
- Active marketplace users.
- Gross marketplace value.
- Trust incidents.
- Priority proposal decisions.
- Marketplace health.
- Emerging fraud, claims, payout, and review signals.
- Admin team workload.
- AI-assisted triage time savings.

AI can rank and summarize queue items, but it does not make final enforcement
decisions.

### Flow A2 — Proposal approval, denial, and override

1. Open **Proposal queue**.
2. Filter open, escalated, high-risk, or appealed proposals.
3. Review seller, creator, projected value, risk, queue age, and flags.
4. Choose:
   - **Approve** — moves an eligible proposal forward.
   - **Deny** — rejects the proposal with a policy reason.
   - **Override** — replaces the normal policy outcome.
5. Enter the required decision reason.
6. Confirm and record.
7. The proposal status and audit trail update.

Production requirement: overrides must be server-authorized. High-impact
overrides should require a second administrator, time-bounded privilege, and
step-up authentication.

### Flow A3 — Seller or creator suspension and delisting

1. Open **Users & listings**.
2. Search by name, account ID, or role.
3. Review trust score, campaigns, marketplace value, reports, and status.
4. Choose:
   - **Suspend** — temporarily blocks marketplace operations.
   - **Delist** — removes the seller or creator from marketplace discovery.
   - **Restore** — returns an eligible account to Active status.
5. Enter the required reason.
6. Confirm and record.

Production should distinguish account suspension from listing delisting,
campaign restrictions, payout holds, and permanent removal.

### Flow A4 — Review and comment moderation

1. Open **Reviews & comments**.
2. Review the author, subject, rating, comment, flags, and authenticity score.
3. Open supporting evidence.
4. Choose:
   - **Hide review**.
   - **Restore review**.
   - **Override decision** after an escalation or appeal.
5. Enter the moderation basis.
6. Confirm and record.

The original review must remain preserved in the audit history even when it is
hidden or replaced in the user-facing experience.

### Flow A5 — Marketplace performance

The admin performance view includes:

- Gross marketplace value.
- Completed campaigns.
- Dispute rate.
- AI recommendation lift.
- Proposal-to-payment funnel.
- Resolution time and appeal reversals.
- Payout timeliness, funds on hold, and chargebacks.
- AI acceptance, measured lift, and safety fallback rate.

This view closes an important product gap: seller and creator dashboards measure
individual results, while Admin measures the health and fairness of the entire
marketplace.

### Flow A6 — Audit trail

Every privileged action records:

- Timestamp.
- Administrator identity.
- Action.
- Target record.
- Required reason.
- Severity.

Production additions should include before/after state, policy version,
evidence references, request/correlation ID, IP/session metadata, approval
chain, and a tamper-evident signature.

### Flow A7 — Customer support operations

Entry: [Admin support desk](http://localhost:3000/admin/support)

1. Review open-ticket volume, SLA risk, response time, resolution time, and
   customer satisfaction.
2. Filter My Queue, Unassigned, or All tickets.
3. Select a ticket to open the conversation and full context.
4. Review customer, campaign, payment, owner, priority, and SLA.
5. Reply to the customer or add an internal note.
6. Change status, priority, or assignee.
7. Escalate to Payments, open a dispute case, or place a payout hold.
8. Review customer trust and support history.

Production requires durable ticket messages, private-note permissions,
attachment storage, notification delivery, SLA timers, assignment rules, and
audited payment/dispute actions.

### Additional admin gaps identified

- Role-based permissions for Support, Trust & Safety, Payments, Operations,
  Analyst, and Super Admin.
- Two-person approval for permanent delisting, payout release, and high-value
  overrides.
- Appeals and reinstatement workflow with deadlines and owner assignment.
- Disputes, refunds, payout holds, chargebacks, and escrow release.
- Fraud rings, duplicate identity, coordinated review, and collusion signals.
- Seller product-claim and creator disclosure compliance.
- Case management with evidence attachments and internal notes.
- Enforcement-policy versioning and decision templates.
- Bulk actions with stronger confirmation and rollback windows.
- Data access logs and sensitive-field masking.
- Admin workload, SLA, accuracy, and appeal-reversal reporting.
- AI recommendation evaluation, bias checks, drift alerts, and fallback rates.
- Emergency feature kill switches and incident-response controls.
- Marketplace configuration for categories, tiers, fees, limits, and regions.

### Flow A8 — Seller acquisition connectors

Entry: [Admin seller discovery](http://localhost:3000/admin/seller-discovery)

1. Review the discovery guardrail separating internal leads from live seller
   listings.
2. Run eBay, Walmart, or all configured connectors.
3. Review source scope, provenance, connector health, and AI qualification.
4. Qualify a seller lead.
5. Send the seller invitation.
6. Track claim, verification, marketplace consent, and creator-ready status.

### Flow A9 — Enterprise marketplace partners

Entry: [Enterprise partners](http://localhost:3000/admin/enterprise)

1. Review the controlled enablement lifecycle.
2. Open the eBay or Walmart partner workspace.
3. Monitor integration type, seller consent, rollout, and connector health.
4. Confirm data boundaries across Admin, Agency, and Enterprise roles.

### Flow E1 — Enterprise partner sign-in and activation

1. [Open Partner Sign-in](http://localhost:3000/enterprise/signin).
2. Continue with Enterprise SSO or an invited work account.
3. For first-time access, open the
   [invitation activation mock](http://localhost:3000/enterprise/activate/EBAY-2026-DEMO).
4. Review organization, program, role, and initial permission boundaries.
5. Accept partner terms and continue to
   [enterprise onboarding](http://localhost:3000/enterprise/onboarding).
6. Configure organization, SSO security, connector sandbox, and seller consent.
7. Submit the setup for LiveLoop production approval.

### Flow E2 — Enterprise partner portal

1. [Program overview](http://localhost:3000/enterprise)
2. [Seller enablement](http://localhost:3000/enterprise/sellers)
3. [Connectors and OAuth](http://localhost:3000/enterprise/connectors)
4. [Team and access](http://localhost:3000/enterprise/team)
5. [Program performance](http://localhost:3000/enterprise/performance)

The portal is isolated to one enterprise partner and one approved program.
Partner users see eligible, invited, consented, and activated sellers, but do
not receive seller banking data or private creator-account access.

## 9A. Independent Agency

Agency is a separate delegated-client operating model. It is not seller
discovery or an enterprise marketplace integration.

### Flow G1 — Agency registration

Entry: [Agency registration](http://localhost:3000/agency/register)

1. Submit agency business details.
2. Identify the verified agency owner.
3. Accept the delegated-client operating model.
4. Submit for LiveLoop review.
5. Exit to the Agency Portfolio after verification.

### Flow G2 — Agency operations

1. [Agency portfolio](http://localhost:3000/agency)
2. [Seller clients and permissions](http://localhost:3000/agency/clients)
3. [Multi-client campaigns](http://localhost:3000/agency/campaigns)
4. [Team and access](http://localhost:3000/agency/team)

The seller remains the data owner and contracting party. Every agency-client
relationship requires explicit, revocable seller permission.

## 10. Recommended demonstration scripts

### Customer support demonstration

1. [Customer support portal](http://localhost:3000/support)
2. Select a ticket and review its progress and conversation.
3. Reply to the support specialist.
4. Create a new ticket with category, campaign, priority, and evidence.
5. [Admin support desk](http://localhost:3000/admin/support)
6. Open the ticket queue and review customer context.
7. Change the status, assignment, or priority.
8. Reply, add an internal note, or escalate the case.

### Seller demonstration

1. [Seller sign-in](http://localhost:3000/seller/signin)
2. [Seller onboarding](http://localhost:3000/seller/onboarding)
3. [Seller Home](http://localhost:3000/seller)
4. [Discover creators](http://localhost:3000/seller/discover)
5. [Seller Campaigns](http://localhost:3000/seller/campaigns)
6. [Seller Performance](http://localhost:3000/seller/performance)
7. [Seller Profile](http://localhost:3000/seller/profile)
8. [Seller Plans](http://localhost:3000/seller/subscription)

### Creator demonstration

1. [Creator sign-in](http://localhost:3000/signin)
2. [Creator onboarding](http://localhost:3000/creator/onboarding)
3. [Creator Home](http://localhost:3000/creator)
4. [Discover sellers](http://localhost:3000/creator/discover)
5. [Creator Campaigns](http://localhost:3000/creator/campaigns)
6. [Creator Performance](http://localhost:3000/creator/performance)
7. [Creator Profile](http://localhost:3000/creator/profile)
8. [Creator Plans](http://localhost:3000/creator/subscription)

### Admin demonstration

1. [Admin control plane](http://localhost:3000/admin)
2. [Open Seller Discovery](http://localhost:3000/admin/seller-discovery), run a
   connector, qualify a lead, and send an invitation.
3. [Open Enterprise Partners](http://localhost:3000/admin/enterprise) and review
   seller-consent and rollout health.
4. Review the Command Center health and priority queue.
5. Open Proposal Queue and approve, deny, or override a proposal.
6. Enter a reason and confirm the action.
7. Open Users & Listings and suspend, delist, or restore an account.
8. Open Reviews & Comments and moderate or override a review.
9. Review Platform Performance.
10. Confirm the new decisions in Audit Trail.

### Agency demonstration

1. [Register an agency](http://localhost:3000/agency/register).
2. Confirm that agency access requires seller invitation and consent.
3. [Open the Agency Portfolio](http://localhost:3000/agency).
4. Review authorized and pending [seller clients](http://localhost:3000/agency/clients).
5. Open the AI portfolio recommendation.
6. Review [multi-client campaigns](http://localhost:3000/agency/campaigns).
7. Review client-scoped [team permissions](http://localhost:3000/agency/team).

## 11. Related documentation

- [Full-stack product and technical plan](LIVELOOP_FULL_STACK_PLAN.md)
- [Agent and seller discovery implementation plan](AGENT_SELLER_DISCOVERY_IMPLEMENTATION_PLAN.md)
- [Seller acquisition, agency, and enterprise flow](SELLER_ACQUISITION_AGENCY_ENTERPRISE_FLOW.md)
- [Application README](connectin-app/README.md)
- [Original consolidated Stitch flow reference](design_flows_all.md)
- [Original design system](design.md)
- [Trendy visual refresh](connectin_trendy_refresh/DESIGN.md)
