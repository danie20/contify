import assert from "node:assert/strict";
import test from "node:test";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${pathname}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${pathname}`, {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("server-renders the LiveLoop seller workspace and product metadata", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>LiveLoop — AI-powered live commerce<\/title>/i);
  assert.match(html, /og-liveloop\.png/);
  assert.match(html, /liveloop-theme/);
  assert.match(html, /Switch to light mode/);
  assert.match(html, /Seller workspace/);
  assert.match(html, /LIVELOOP AI/);
  assert.match(html, /SALES BOOST/);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape/i);
});

test("server-renders the animated creator sign-in story and help entry", async () => {
  const response = await render("/signin");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /FOR CREATORS/);
  assert.match(html, /Turn your audience into/);
  assert.match(html, /DISCOVER/);
  assert.match(html, /Explore LiveLoop AI/);
  assert.match(html, /AI Help Center/);
});

test("server-renders the LiveLoop AI marketing and demo page", async () => {
  const response = await render("/ai");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /THE LIVELOOP INTELLIGENCE LAYER/);
  assert.match(html, /AI for the next/);
  assert.match(html, /ROLE-AWARE INTELLIGENCE/);
  assert.match(html, /AI Sales Boost/);
  assert.match(html, /AI Live Copilot/);
  assert.match(html, /Better evidence/);
  assert.match(html, /Open interactive demo/);
});

test("server-renders role-aware AI Help Center guidance", async () => {
  const response = await render("/help");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /AI-ASSISTED HELP CENTER/);
  assert.match(html, /Answers that understand your/);
  assert.match(html, /How do I find the right creator/);
  assert.match(html, /Finding the right creator/);
  assert.match(html, /One learning loop, from discovery to growth/);
  assert.match(html, /Still need help\? Create a ticket/);
});

test("server-renders admin seller discovery and its consent guardrail", async () => {
  const response = await render("/admin/seller-discovery");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /Marketplace seller discovery/);
  assert.match(html, /Discovery creates internal leads/);
  assert.match(html, /eBay seller discovery/);
  assert.match(html, /Walmart Marketplace/);
  assert.match(html, /AI ACQUISITION COPILOT/);
});

test("server-renders the independent agency registration flow", async () => {
  const response = await render("/agency/register");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /AGENCY PARTNER PROGRAM/);
  assert.match(html, /Manage creator commerce for every seller client/);
  assert.match(html, /Seller-controlled permissions/);
  assert.match(html, /Tell us about your agency/);
});

test("server-renders enterprise marketplace partner controls", async () => {
  const response = await render("/admin/enterprise");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /Enterprise marketplace partners/);
  assert.match(html, /CONTROLLED ENABLEMENT FLOW/);
  assert.match(html, /Seller consent/);
  assert.match(html, /DATA GOVERNANCE/);
});

test("server-renders enterprise partner sign-in and SSO entry", async () => {
  const response = await render("/enterprise/signin");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /ENTERPRISE PARTNER ACCESS/);
  assert.match(html, /Continue with enterprise SSO/);
  assert.match(html, /secure activation link/i);
  assert.match(html, /og-liveloop\.png/);
});

test("server-renders enterprise invitation activation", async () => {
  const response = await render("/enterprise/activate/EBAY-2026-DEMO");
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /ORGANIZATION-VERIFIED INVITATION/);
  assert.match(html, /Activate your partner account/);
  assert.match(html, /Partner administrator/);
  assert.match(html, /No access to seller banking/);
});

test("server-renders enterprise onboarding and partner portal", async () => {
  const [onboarding, portal] = await Promise.all([
    render("/enterprise/onboarding"),
    render("/enterprise"),
  ]);
  assert.equal(onboarding.status, 200);
  assert.equal(portal.status, 200);

  const onboardingHtml = await onboarding.text();
  const portalHtml = await portal.text();
  assert.match(onboardingHtml, /Configure the seller growth program/);
  assert.match(onboardingHtml, /Organization/);
  assert.match(onboardingHtml, /Security/);
  assert.match(portalHtml, /Enterprise partner portal/);
  assert.match(portalHtml, /Isolated partner tenant/);
  assert.match(portalHtml, /PROGRAM AI ASSISTANT/);
});

test("renders collapsible navigation and contextual workspace search", async () => {
  const [seller, admin, agency, enterprise] = await Promise.all([
    render("/seller"),
    render("/admin"),
    render("/agency"),
    render("/enterprise"),
  ]);

  const pages = await Promise.all([seller.text(), admin.text(), agency.text(), enterprise.text()]);
  for (const html of pages) {
    assert.match(html, /Collapse (?:admin |agency |enterprise )?navigation/i);
  }
  assert.match(pages[0], /Search across your seller workspace/);
  assert.match(pages[1], /Search LiveLoop operations/);
  assert.match(pages[2], /Search agency workspace/);
  assert.match(pages[3], /Search enterprise partner workspace/);
});

test("server-renders role-aware seller and creator commercial negotiations", async () => {
  const [seller, creator] = await Promise.all([
    render("/seller/negotiations"),
    render("/creator/negotiations"),
  ]);
  assert.equal(seller.status, 200);
  assert.equal(creator.status, 200);

  const [sellerHtml, creatorHtml] = await Promise.all([seller.text(), creator.text()]);
  for (const html of [sellerHtml, creatorHtml]) {
    assert.match(html, /COMMERCIAL NEGOTIATION/);
    assert.match(html, /LATEST COUNTER OFFER/);
    assert.match(html, /Accept offer/);
    assert.match(html, /Counter offer/);
    assert.match(html, /RFLS-02841/);
  }
  assert.match(sellerHtml, /Seller view/);
  assert.match(sellerHtml, /Agree on terms with.*Maya Chen/);
  assert.match(creatorHtml, /Creator view/);
  assert.match(creatorHtml, /Agree on terms with.*Aster &amp; Vale/);
});

test("server-renders the shared seller and creator collaboration workspace", async () => {
  const [seller, creator] = await Promise.all([
    render("/seller/collab/RFLS-02841"),
    render("/creator/collab/RFLS-02841"),
  ]);
  assert.equal(seller.status, 200);
  assert.equal(creator.status, 200);

  const [sellerHtml, creatorHtml] = await Promise.all([seller.text(), creator.text()]);
  for (const html of [sellerHtml, creatorHtml]) {
    assert.match(html, /SHARED COLLABORATION ROOM/);
    assert.match(html, /Checklist/);
    assert.match(html, /Run of show/);
    assert.match(html, /Assets &amp; links/);
    assert.match(html, /Deadlines/);
    assert.match(html, /Readiness assist/);
  }
  assert.match(sellerHtml, /Seller view/);
  assert.match(creatorHtml, /Creator view/);
});
