# LiveLoop Full-Stack Product & Build Plan

For screen-by-screen navigation, direct local links, role journeys, and
implementation coverage, see [LIVELOOP_FLOW_GUIDE.md](LIVELOOP_FLOW_GUIDE.md).

For the Agency/Agent role, marketplace seller discovery, eBay/Walmart
connectors, seller claiming, and delegated client management, see
[AGENT_SELLER_DISCOVERY_IMPLEMENTATION_PLAN.md](AGENT_SELLER_DISCOVERY_IMPLEMENTATION_PLAN.md).

## 1. Product vision

LiveLoop is a two-sided live-commerce operating system that helps sellers and
influencers find the right partner, agree on a campaign, run it, and learn what
to do next.

The product should not stop at matchmaking. Its core loop is:

1. Match a seller's product and commercial goal to the right influencer.
2. Turn the match into a clear RFLS (Request for Live Streaming).
3. Negotiate scope, rate, commission, dates, and deliverables.
4. Prepare and run the live collaboration.
5. Measure revenue, engagement, conversion, and partner quality.
6. Use AI to recommend the next action for both parties.

## 2. Existing design-flow audit

The Google Stitch archive contains two complete product surfaces and their
shared support flows.

### Influencer surface

- Sign in and onboarding
- Creator dashboard and upcoming stream schedule
- Seller marketplace and seller profiles
- RFLS creation and application tracking
- Payment negotiation
- Active connections
- Live collaboration room
- Profile settings
- Help, support, contact, terms, and privacy

### Seller surface

- Seller sign in
- Business scale, business profile, membership, and onboarding completion
- Seller workspace/dashboard
- Influencer discovery, infinite scroll, and creator profiles
- Favorites
- Invites sent
- Negotiation
- Live collaboration room
- Membership and billing

### Shared design language

- Mobile-first layout with a responsive desktop shell
- Creator actions use indigo/violet
- Seller actions use emerald/teal
- Dark navy canvas, atmospheric gradients, glass cards, and pill navigation
- Minimum 44px touch targets, explicit status colors, and accessible focus rings

## 3. Gaps to solve in the application

The mocks cover the transactional flow well, but a production product also
needs:

- A unified campaign lifecycle and consistent campaign status model
- AI assistance that is tied to measurable outcomes
- Shared post-campaign performance data
- Seller product/catalog context for better matching
- Influencer audience and content-performance context
- Actionable recommendations instead of dashboard-only reporting
- Notification, audit, and consent rules around AI-generated recommendations
- Server-owned persistence, authorization, and role boundaries

## 4. MVP experience being built

The first runnable version is a responsive, interactive application with a role
switcher so both sides of the marketplace can be demonstrated in one session.

### Seller home — AI Sales Boost

- Revenue, live conversion, active campaigns, and attributable orders
- AI growth brief with an estimated upside and confidence score
- Ranked recommended actions:
  - Pair a product with a high-fit influencer
  - Adjust the offer or bundle
  - Schedule at a stronger audience time
  - Re-engage viewers from a previous stream
- Campaign pipeline and top influencer matches
- Explainable match reasons and expected commercial outcomes

### Influencer home — AI Copilot

- Earnings, conversion, viewers, and active collaborations
- AI pre-live brief with audience angle, product talking points, and run-of-show
- Seller opportunities ranked by audience fit and earning potential
- Performance explanation across views, clicks, conversion, and revenue
- Personalized coaching actions for the next stream
- Shared campaign status and collaboration progress

### Marketplace and campaign flow

- Browse recommended partners
- Filter and inspect fit
- Open a campaign/RFLS
- Review commercial terms
- Track preparation steps
- See performance after the event

## 5. Information architecture

```text
LiveLoop
├── Seller
│   ├── Growth Home
│   ├── Find Influencers
│   ├── Campaigns / Invites
│   ├── AI Sales Boost
│   └── Performance
├── Influencer
│   ├── Creator Home
│   ├── Discover Sellers
│   ├── Opportunities / RFLS
│   ├── AI Copilot
│   └── Performance
└── Shared
    ├── Campaign Detail
    ├── Negotiation
    ├── Live Collaboration Room
    ├── Notifications
    └── Profile / Support
└── Admin
    ├── Command Center
    ├── Proposal Governance
    ├── Users & Listings
    ├── Reviews & Comments
    ├── Disputes & Payments
    ├── Platform Performance
    ├── Customer Support
    └── Audit Trail
```

## 6. Core domain model

| Entity | Purpose |
| --- | --- |
| User | Account identity and role membership |
| SellerProfile | Business, category, goals, location, and subscription tier |
| InfluencerProfile | Channels, audience, categories, rate card, and availability |
| Product | Catalog item, price, margin, inventory, and media |
| AudienceMetric | Platform audience and demographic snapshots |
| Campaign | Shared RFLS/collaboration lifecycle |
| CampaignOffer | Fee, commission, scope, dates, and offer revisions |
| CampaignTask | Preparation checklist and owner |
| PerformanceSnapshot | Views, clicks, orders, revenue, conversion, and returns |
| AIRecommendation | Recommendation, evidence, confidence, status, and outcome |
| Notification | Role-aware inbox event |
| AuditEvent | Sensitive workflow and commercial change history |
| AdminCase | Investigation, evidence, owner, SLA, and appeal state |
| EnforcementAction | Suspension, delisting, restriction, restoration, and reason |
| PolicyDecision | Policy version, decision basis, override, and approval chain |
| SupportTicket | Customer request, category, priority, SLA, owner, and status |
| TicketMessage | Customer reply, agent reply, internal note, and attachment metadata |

## 7. Campaign lifecycle

```text
Draft → Proposed → Negotiating → Accepted → Preparing → Live
      → Completed → Reported

Terminal/side states: Declined, Cancelled, Expired, Disputed
```

Every transition should be server-validated and written to an audit history.
Commercial terms should be versioned rather than overwritten.

## 8. AI product design

### Seller AI Sales Boost

Inputs:

- Product margin, inventory, price, and past conversion
- Campaign and influencer performance
- Audience/product category fit
- Offer structure, time slot, and historic promotion response

Outputs:

- Ranked growth actions with expected lift range
- Recommended influencer/product pairing
- Bundle, discount, commission, and scheduling suggestions
- Campaign brief and outreach draft
- Post-campaign explanation and next-best action

### Influencer AI Copilot

Inputs:

- Audience demographics and watch behavior
- Content and live-session history
- Product knowledge and seller campaign goals
- Personal rate, availability, and content preferences

Outputs:

- Ranked seller opportunities with fit explanation
- Suggested rate/commission range
- Pre-live hook, talking points, objection handling, and run-of-show
- Live coaching prompts based on funnel signals
- Post-live performance summary and targeted skill coaching

### AI guardrails

- Always label generated content and confidence.
- Show the evidence used for a recommendation.
- Never auto-send outreach, accept terms, or change prices.
- Require the user to review commercial and public-facing content.
- Store recommendation acceptance/dismissal and measured outcomes.
- Avoid protected-attribute targeting and proxy discrimination.
- Allow users to remove connected data and opt out of model improvement.

## 9. Technical architecture

### Frontend

- React/Next-compatible application using the existing Sites runtime
- Responsive app shell with seller and influencer modes
- Shared cards, status pills, tables, charts, drawers, and campaign components
- Server-rendered initial data with client-side interaction where useful
- Accessible semantics, keyboard navigation, reduced-motion support, and
  mobile-safe layouts

### Backend

- Route handlers for dashboard, discovery, campaigns, offers, performance, and
  AI recommendations
- Role and ownership checks on every write
- Idempotency keys for campaign and offer mutations
- Server-side input validation
- Event/audit writes for workflow transitions
- Server-enforced admin roles and fine-grained permissions
- Mandatory reason, evidence, before/after state, and approval chain for overrides
- Dual control for permanent delisting, payout release, and high-impact actions

### Data

- D1/SQL for structured product data and workflow state
- R2/object storage later for product media, creator media kits, and attachments
- Indexed queries for discovery, campaign status, dates, and recommendation
  status
- Analytics events separated from source-of-truth transactional records

### AI service boundary

- A dedicated recommendation/orchestration module
- Structured JSON outputs validated before storage
- Retrieval limited to the current user's authorized campaign context
- Prompt/model version stored with every recommendation
- Offline evaluation set for match quality and recommendation usefulness
- Cost, latency, safety, and fallback monitoring

## 10. API outline

```text
GET    /api/me
GET    /api/dashboard?role=seller|influencer
GET    /api/partners
GET    /api/campaigns
POST   /api/campaigns
GET    /api/campaigns/:id
POST   /api/campaigns/:id/offers
POST   /api/campaigns/:id/transition
GET    /api/campaigns/:id/performance
GET    /api/recommendations
POST   /api/recommendations/:id/respond
POST   /api/ai/campaign-brief
POST   /api/ai/performance-summary
```

## 11. Delivery phases

### Phase 1 — Demonstrable product

- Build the shared shell and role switcher
- Build seller AI Sales Boost and influencer AI Copilot dashboards
- Add partner discovery, campaign pipeline, and performance views
- Add realistic data and meaningful interactions
- Validate responsive layout and production build

### Phase 2 — Transactional MVP

- Add authentication and role-based onboarding
- Add D1 schema, migrations, seed data, and ownership rules
- Implement RFLS, offers, campaign transitions, tasks, and notifications
- Add product catalog and influencer media-kit management
- Add server-side audit and idempotency

### Phase 3 — AI-connected beta

- Connect approved commerce, social, and analytics data sources
- Implement structured AI briefs and post-campaign analysis
- Add feedback capture and recommendation outcome measurement
- Add evaluation dashboards, safety checks, and cost controls

### Phase 4 — Marketplace readiness

- Payments/escrow and disputes
- Subscription and billing enforcement
- Fraud, moderation, and trust controls
- Admin operations, reporting, exports, and support tooling

## 12. Success metrics

North-star metric: weekly attributable live-commerce revenue completed through
LiveLoop.

Supporting metrics:

- Match viewed → RFLS sent conversion
- RFLS sent → accepted conversion
- Time from match to accepted campaign
- Campaign completion rate
- Gross merchandise value and seller contribution margin
- Influencer earnings and repeat-collaboration rate
- Recommendation acceptance rate
- Incremental lift after accepted AI recommendations
- User-reported recommendation helpfulness

## 13. Definition of done for the first version

- Seller and influencer modes are both usable and visually distinct.
- The full marketplace-to-performance story is navigable.
- AI recommendations are specific, explainable, and tied to metrics.
- Core interactions work with mouse, keyboard, and mobile touch.
- Layout is responsive from phone to desktop.
- Production build completes without errors.
- The application can be deployed without changing the product architecture.
