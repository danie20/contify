import LiveLoopApp from "../LiveLoopApp";

export default function OnboardingPage() {
  return <LiveLoopApp initialView="onboarding" />;
}
