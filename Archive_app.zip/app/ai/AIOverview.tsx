"use client";

import Link from "next/link";
import { useState } from "react";

type Audience = "seller" | "creator" | "scale" | "admin";

const audienceContent: Record<Audience, {
  label: string;
  eyebrow: string;
  headline: string;
  body: string;
  result: string;
  resultLabel: string;
  href: string;
  link: string;
  features: { number: string; title: string; body: string; output: string }[];
}> = {
  seller: {
    label: "Sellers",
    eyebrow: "SELLER GROWTH INTELLIGENCE",
    headline: "Turn campaign signals into the next sales move.",
    body: "LiveLoop AI helps sellers find creators who can convert, shape a commercially sound offer, and understand what should be repeated.",
    result: "+14.6%",
    resultLabel: "demonstrated AI recommendation lift",
    href: "/seller",
    link: "Open Seller AI Sales Boost",
    features: [
      { number: "01", title: "AI Sales Boost", body: "Recommends creator, product, offer, and timing combinations tied to an expected commercial outcome.", output: "Next-best growth action" },
      { number: "02", title: "Smart creator matching", body: "Ranks creators using audience fit, category affinity, format, and conversion potential.", output: "Explainable fit score" },
      { number: "03", title: "Performance story", body: "Explains which campaign behavior drove revenue and converts the insight into another playbook.", output: "Repeatable campaign strategy" },
    ],
  },
  creator: {
    label: "Creators",
    eyebrow: "CREATOR EARNING INTELLIGENCE",
    headline: "Prepare a stronger live and understand what grows earnings.",
    body: "The Creator Copilot translates seller goals and audience behavior into a practical live plan—without taking away the creator’s voice.",
    result: "+22%",
    resultLabel: "demonstrated creator earning lift",
    href: "/creator",
    link: "Open Creator AI Copilot",
    features: [
      { number: "01", title: "Seller opportunity matching", body: "Prioritizes aligned sellers using audience relevance, fee, commission, and campaign expectations.", output: "Better partnership shortlist" },
      { number: "02", title: "AI Live Copilot", body: "Drafts the hook, proof, demo sequence, close, and performance watch-outs for the next live.", output: "Actionable pre-live brief" },
      { number: "03", title: "Content performance story", body: "Connects retention and conversion changes to specific content behavior.", output: "Clear earning insight" },
    ],
  },
  scale: {
    label: "Agency & Enterprise",
    eyebrow: "PROGRAM INTELLIGENCE",
    headline: "Scale seller enablement without losing consent or control.",
    body: "Portfolio and program assistants prioritize creator allocation, seller cohorts, activation opportunities, and aggregate performance.",
    result: "+$148K",
    resultLabel: "demonstrated 90-day program opportunity",
    href: "/enterprise",
    link: "Open Enterprise AI Assistant",
    features: [
      { number: "01", title: "Agency Portfolio Copilot", body: "Recommends how to allocate limited creator capacity across authorized seller clients.", output: "Cross-client allocation plan" },
      { number: "02", title: "Enterprise Program Assistant", body: "Finds eligible seller cohorts with strong creator coverage and activation potential.", output: "Consent-aware seller cohort" },
      { number: "03", title: "Program performance", body: "Tracks activation, connector health, creator readiness, and aggregate commercial impact.", output: "Scalable program insight" },
    ],
  },
  admin: {
    label: "Admin & Operations",
    eyebrow: "RESPONSIBLE AI OPERATIONS",
    headline: "Prioritize work faster while humans keep final authority.",
    body: "LiveLoop AI helps operations teams qualify leads, triage queues, and measure recommendation health—but never makes final enforcement decisions.",
    result: "6.4h",
    resultLabel: "demonstrated daily triage time saved",
    href: "/admin",
    link: "Open Admin Intelligence",
    features: [
      { number: "01", title: "Acquisition Copilot", body: "Scores permitted seller leads, detects duplicates, and creates an admin-reviewed shortlist.", output: "Qualified seller pipeline" },
      { number: "02", title: "Operations triage", body: "Prioritizes and routes lower-risk work without auto-deciding proposals, reviews, payouts, or access.", output: "Faster review queues" },
      { number: "03", title: "AI governance", body: "Measures acceptance, positive lift, safety fallback, and performance against control groups.", output: "Recommendation health" },
    ],
  },
};

const loopSteps = [
  { number: "01", icon: "⌕", title: "Discover", body: "Find the strongest partner or opportunity." },
  { number: "02", icon: "◇", title: "Connect", body: "Shape clear terms and a shared campaign." },
  { number: "03", icon: "◉", title: "Stream", body: "Prepare the live with an approved AI brief." },
  { number: "04", icon: "↗", title: "Learn", body: "Explain the performance behavior behind results." },
  { number: "05", icon: "↻", title: "Repeat", body: "Turn the insight into the next playbook." },
];

export default function AIOverview() {
  const [audience, setAudience] = useState<Audience>("seller");
  const content = audienceContent[audience];

  return (
    <main className={`ai-marketing ${audience}`}>
      <header className="ai-mkt-header">
        <Link className="ai-mkt-brand" href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>AI</small></Link>
        <nav aria-label="AI page navigation"><a href="#capabilities">Capabilities</a><a href="#loop">How it works</a><a href="#trust">Responsible AI</a><Link href="/help">Help center</Link></nav>
        <Link className="ai-mkt-header-cta" href="/signin">Explore the product <span>→</span></Link>
      </header>

      <section className="ai-mkt-hero">
        <div className="ai-mkt-hero-copy">
          <span className="ai-mkt-eyebrow">✦ THE LIVELOOP INTELLIGENCE LAYER</span>
          <h1>AI for the next <em>live-commerce decision.</em></h1>
          <p>Discover the right partner, design the campaign, prepare the live, understand performance, and repeat what converts—with evidence at every step.</p>
          <div className="ai-mkt-hero-actions"><a href="#capabilities">Explore AI capabilities <span>↓</span></a><Link href="/seller">Open interactive demo <span>→</span></Link></div>
          <div className="ai-mkt-proof"><div><strong>9</strong><span>AI capability areas</span></div><div><strong>4</strong><span>role-aware copilots</span></div><div><strong>100%</strong><span>human-controlled decisions</span></div></div>
        </div>
        <div className="ai-mkt-visual" aria-label="LiveLoop AI recommendation example">
          <div className="ai-mkt-orbit"><span>✦</span>{["Seller", "Creator", "Agency", "Enterprise"].map((item) => <i key={item}>{item}</i>)}</div>
          <article className="ai-mkt-recommendation">
            <header><span>✦ LIVELOOP AI · SALES BOOST</span><small>92% confidence</small></header>
            <h2>Pair the Summer Reset Kit with Maya Chen.</h2>
            <p>Her audience has the strongest category affinity and converts 1.7× above the category baseline.</p>
            <div><span>Expected revenue lift</span><strong>+$8.4K</strong><small>+17–23% vs. baseline</small></div>
            <footer><span>Evidence available</span><span>Seller approves</span></footer>
          </article>
          <div className="ai-mkt-signal"><span>↗</span><div><small>OUTCOME SIGNAL</small><strong>Offer before minute 8</strong></div></div>
        </div>
      </section>

      <section className="ai-mkt-principles">
        <article><span>01</span><div><strong>Explainable</strong><p>Every material recommendation shows its evidence, confidence, impact, and watch-outs.</p></div></article>
        <article><span>02</span><div><strong>Measurable</strong><p>Recommendations are tied to revenue, earnings, activation, or operational outcomes.</p></div></article>
        <article><span>03</span><div><strong>Human controlled</strong><p>People approve commercial decisions, access, claims, payouts, and enforcement.</p></div></article>
      </section>

      <section className="ai-mkt-capabilities" id="capabilities">
        <div className="ai-mkt-section-head"><span className="ai-mkt-eyebrow">ROLE-AWARE INTELLIGENCE</span><h2>One AI layer. A useful job for every participant.</h2><p>Select an audience to see how LiveLoop AI supports their workflow.</p></div>
        <div className="ai-mkt-tabs" aria-label="Choose an AI audience">
          {(Object.keys(audienceContent) as Audience[]).map((item) => <button className={audience === item ? "active" : ""} key={item} onClick={() => setAudience(item)}>{audienceContent[item].label}</button>)}
        </div>
        <article className="ai-mkt-role-story">
          <div className="ai-mkt-role-copy">
            <span className="ai-mkt-eyebrow">{content.eyebrow}</span>
            <h2>{content.headline}</h2>
            <p>{content.body}</p>
            <div className="ai-mkt-result"><strong>{content.result}</strong><span>{content.resultLabel}</span></div>
            <Link href={content.href}>{content.link} <span>→</span></Link>
          </div>
          <div className="ai-mkt-feature-list">
            {content.features.map((feature) => <article key={feature.title}><span>{feature.number}</span><div><h3>{feature.title}</h3><p>{feature.body}</p><small>{feature.output}</small></div></article>)}
          </div>
        </article>
      </section>

      <section className="ai-mkt-loop" id="loop">
        <div className="ai-mkt-section-head"><span className="ai-mkt-eyebrow">THE LIVELOOP METHOD</span><h2>AI that learns from the complete commercial loop.</h2><p>The outcome from one campaign becomes evidence for the next decision.</p></div>
        <div className="ai-mkt-loop-grid">
          {loopSteps.map((step, index) => <article key={step.title}><span>{step.number}</span><i>{step.icon}</i><h3>{step.title}</h3><p>{step.body}</p>{index < loopSteps.length - 1 && <b>→</b>}</article>)}
        </div>
        <div className="ai-mkt-feedback"><span>Recommendation</span><i>→</i><span>User decision</span><i>→</i><span>Campaign outcome</span><i>→</i><span>Measured lift</span><i>→</i><strong>Better next playbook</strong></div>
      </section>

      <section className="ai-mkt-trust" id="trust">
        <div><span className="ai-mkt-eyebrow">RESPONSIBLE BY DESIGN</span><h2>Better evidence.<br />People remain in control.</h2><p>LiveLoop limits AI to authorized data and keeps consequential decisions reviewable, editable, and auditable.</p><Link href="/admin">Explore AI governance <span>→</span></Link></div>
        <div className="ai-mkt-trust-grid">
          {[
            ["Authorized context", "AI uses only the data a person and organization are permitted to access."],
            ["Visible evidence", "Recommendations expose their basis instead of hiding behind a score."],
            ["Explicit confidence", "Low-confidence or incomplete-data cases must safely fall back."],
            ["Human approval", "Product claims, pricing, access, payments, and enforcement stay with people."],
            ["Outcome learning", "Accepted, edited, and dismissed recommendations are measured against results."],
            ["Auditability", "Production recommendations retain evidence, version, decision, and outcome history."],
          ].map(([title, body], index) => <article key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{body}</p></article>)}
        </div>
      </section>

      <section className="ai-mkt-demo">
        <div><span className="ai-mkt-eyebrow">INTERACTIVE PRODUCT DEMO</span><h2>See the intelligence layer from every side.</h2><p>The current application demonstrates the experience with realistic sample data. Production AI requires connected, authorized data and measured evaluation.</p></div>
        <div>
          <Link href="/seller"><span>Seller</span><strong>AI Sales Boost</strong><i>→</i></Link>
          <Link href="/creator"><span>Creator</span><strong>AI Live Copilot</strong><i>→</i></Link>
          <Link href="/agency"><span>Agency</span><strong>Portfolio Copilot</strong><i>→</i></Link>
          <Link href="/enterprise"><span>Enterprise</span><strong>Program Assistant</strong><i>→</i></Link>
          <Link href="/admin"><span>Admin</span><strong>AI Governance</strong><i>→</i></Link>
          <Link href="/help"><span>Everyone</span><strong>AI Help Center</strong><i>→</i></Link>
        </div>
      </section>

      <footer className="ai-mkt-footer"><div><span className="live-loop-mark">L</span><strong>LiveLoop AI</strong></div><blockquote>“Better evidence for the next live-commerce decision—while people remain in control.”</blockquote><Link href="/signin">Enter LiveLoop <span>→</span></Link></footer>
    </main>
  );
}
