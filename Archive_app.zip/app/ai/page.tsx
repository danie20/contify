import type { Metadata } from "next";
import AIOverview from "./AIOverview";

export const metadata: Metadata = {
  title: "LiveLoop AI — Intelligence for every live-commerce decision",
  description: "Explore LiveLoop AI features for sellers, creators, agencies, enterprise marketplace partners, and operations teams.",
};

export default function LiveLoopAIPage() {
  return <AIOverview />;
}
