"use client";

import { useState } from "react";

type SupportRole = "seller" | "creator";

const customerTickets = [
  { id: "TKT-1048", subject: "Creator payout still pending", category: "Payments", status: "Investigating", updated: "12 min ago", priority: "Urgent", campaign: "RFLS-02841", owner: "Lena Park" },
  { id: "TKT-0992", subject: "Question about commission reporting", category: "Campaign", status: "Resolved", updated: "Jul 21", priority: "Normal", campaign: "RFLS-02782", owner: "Omar Reed" },
  { id: "TKT-0951", subject: "Update connected TikTok account", category: "Account", status: "Resolved", updated: "Jul 12", priority: "Normal", campaign: "—", owner: "Lena Park" },
];

function SupportBadge({ value }: { value: string }) {
  return <span className={`support-badge ${value.toLowerCase()}`}>{value}</span>;
}

export default function SupportPortal({ initialTicket = "TKT-1048" }: { initialTicket?: string }) {
  const [role, setRole] = useState<SupportRole>("creator");
  const [tickets, setTickets] = useState(customerTickets);
  const [selected, setSelected] = useState(Math.max(0, customerTickets.findIndex((ticket) => ticket.id === initialTicket)));
  const [creating, setCreating] = useState(false);
  const [message, setMessage] = useState("");
  const [toast, setToast] = useState("");
  const ticket = tickets[selected] ?? tickets[0];

  const flash = (text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(""), 3000);
  };

  return (
    <main className={`support-shell ${role}`}>
      <header className="support-header">
        <a className="support-brand" href={role === "seller" ? "/seller" : "/creator"}><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong></a>
        <nav><a href={role === "seller" ? "/seller" : "/creator"}>Workspace</a><a href="/ai">LiveLoop AI</a><a className="active" href="/support">Support</a><a href="/help">Help center</a></nav>
        <div className="support-role-switch"><button className={role === "seller" ? "active" : ""} onClick={() => setRole("seller")}>Seller</button><button className={role === "creator" ? "active" : ""} onClick={() => setRole("creator")}>Creator</button></div>
        <button className="support-user">{role === "seller" ? "AS" : "AJ"}</button>
      </header>

      <section className="support-hero">
        <div><span className="support-eyebrow">LIVELOOP SUPPORT</span><h1>How can we help?</h1><p>Get answers, track requests, or speak with a specialist who can see your campaign context.</p></div>
        <button className="support-primary" onClick={() => setCreating(true)}>＋ Create support ticket</button>
      </section>

      <section className="support-quick-grid">
        <button onClick={() => setCreating(true)}><span>◇</span><div><strong>Campaign issue</strong><small>Invites, terms, products, or live preparation</small></div><i>→</i></button>
        <button onClick={() => setCreating(true)}><span>$</span><div><strong>Payments & payouts</strong><small>Commission, payout timing, refunds, or holds</small></div><i>→</i></button>
        <button onClick={() => setCreating(true)}><span>◎</span><div><strong>Account & verification</strong><small>Profile, identity, connected channels, or access</small></div><i>→</i></button>
        <button onClick={() => setCreating(true)}><span>!</span><div><strong>Report a safety issue</strong><small>Misleading claims, harassment, fraud, or abuse</small></div><i>→</i></button>
      </section>

      <section className="support-main-grid">
        <article className="customer-ticket-panel support-card">
          <div className="support-section-head"><div><span className="support-eyebrow">MY REQUESTS</span><h2>Support tickets</h2></div><button>All tickets ⌄</button></div>
          <label className="customer-ticket-search"><span>⌕</span><input placeholder="Search your tickets…" /></label>
          <div className="customer-ticket-list">
            {tickets.map((item, index) => (
              <button className={selected === index ? "active" : ""} key={item.id} onClick={() => setSelected(index)}>
                <div><SupportBadge value={item.status} /><span>{item.updated}</span></div>
                <strong>{item.subject}</strong><p>{item.id} · {item.category}</p>
                <div><span>Related: {item.campaign}</span><SupportBadge value={item.priority} /></div>
              </button>
            ))}
          </div>
        </article>

        <article className="customer-ticket-detail support-card">
          <div className="customer-detail-head">
            <div><span className="support-eyebrow">{ticket.id} · {ticket.category}</span><h2>{ticket.subject}</h2><p>Last updated {ticket.updated}</p></div>
            <div><SupportBadge value={ticket.priority} /><SupportBadge value={ticket.status} /></div>
          </div>
          <div className="customer-ticket-progress">
            {["Submitted", "Assigned", "Investigating", "Resolved"].map((step, index) => <div className={ticket.status === "Resolved" || index < 3 ? "complete" : index === 2 ? "current" : ""} key={step}><span>{index < 2 || ticket.status === "Resolved" ? "✓" : index + 1}</span><small>{step}</small></div>)}
          </div>
          <div className="customer-ticket-context"><div><span>Support specialist</span><strong>{ticket.owner}</strong></div><div><span>Related campaign</span><strong>{ticket.campaign}</strong></div><div><span>Expected update</span><strong>{ticket.status === "Resolved" ? "Completed" : "Within 42 minutes"}</strong></div></div>
          <div className="customer-conversation">
            <div className="customer-message mine"><span>{role === "seller" ? "AS" : "AJ"}</span><div><header><strong>You</strong><small>Today · 10:18 AM</small></header><p>Hi, I completed the live campaign and the dashboard says the payout was released, but it has not reached my bank account yet. Can you check what happened?</p></div></div>
            <div className="customer-message support"><span>LP</span><div><header><strong>Lena Park · LiveLoop Support</strong><small>Today · 10:29 AM</small></header><p>Thanks for flagging this. I found the payout and I’m checking its transfer status with our payment processor. I’ll update you within the hour.</p></div></div>
            <div className="customer-case-event"><span>⌾</span><p>Your ticket was escalated to the Payments team.</p><small>10:31 AM</small></div>
          </div>
          <div className="customer-reply">
            <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Reply to your support specialist…" />
            <div><button>＋ Add attachment</button><span>PDF, PNG, JPG up to 10 MB</span><button className="support-primary" onClick={() => { setMessage(""); flash("Your reply was added to the ticket"); }}>Send reply</button></div>
          </div>
        </article>

        <aside className="support-side">
          <article className="support-card support-ai-help"><span>✦</span><div><span className="support-eyebrow">AI ASSISTED HELP</span><h2>Get a quick answer</h2><p>Ask about LiveLoop features, campaign status, or common payment questions.</p></div><a href="/help">Ask LiveLoop AI →</a></article>
          <article className="support-card"><div className="support-section-head"><div><span className="support-eyebrow">RECOMMENDED</span><h2>Helpful guides</h2></div></div><div className="support-articles"><a href="#">How creator payouts work <span>→</span></a><a href="#">Understanding campaign status <span>→</span></a><a href="#">Resolve a collaboration dispute <span>→</span></a><a href="#">Contact safety support <span>→</span></a></div></article>
          <article className="support-card support-availability"><span className="support-online" /><div><strong>Specialists are online</strong><small>Typical first response: 18 minutes</small></div></article>
        </aside>
      </section>

      {creating && (
        <div className="support-modal-backdrop">
          <section className="support-modal" role="dialog" aria-modal="true" aria-labelledby="new-ticket-title">
            <button className="support-close" onClick={() => setCreating(false)} aria-label="Close">×</button>
            <span className="support-eyebrow">NEW SUPPORT REQUEST</span><h2 id="new-ticket-title">Tell us what happened</h2><p>Adding campaign and payment context helps us resolve your request faster.</p>
            <form onSubmit={(event) => { event.preventDefault(); const newTicket = { id: "TKT-1051", subject: "New support request", category: "Campaign", status: "Open", updated: "Just now", priority: "Normal", campaign: "RFLS-02841", owner: "Unassigned" }; setTickets([newTicket, ...tickets]); setSelected(0); setCreating(false); flash("Ticket TKT-1051 was created"); }}>
              <label>What do you need help with?<select><option>Campaign or collaboration</option><option>Payment or payout</option><option>Account or verification</option><option>Safety or fraud concern</option><option>Subscription and billing</option></select></label>
              <label>Subject<input placeholder="Short summary of the issue" required /></label>
              <label>Related campaign<select><option>RFLS-02841 · Summer Reset Kit</option><option>RFLS-02803 · Soft Spaces Launch</option><option>No related campaign</option></select></label>
              <label>Priority<select><option>Normal</option><option>High — work is blocked</option><option>Urgent — money or safety risk</option></select></label>
              <label className="support-full">Description<textarea placeholder="Include what you expected, what happened, and any steps you already tried…" required /></label>
              <div className="support-upload support-full"><span>＋</span><div><strong>Add screenshots or documents</strong><small>PDF, PNG, JPG up to 10 MB</small></div><button type="button">Browse files</button></div>
              <div className="support-modal-actions support-full"><button type="button" onClick={() => setCreating(false)}>Cancel</button><button className="support-primary" type="submit">Submit ticket <span>→</span></button></div>
            </form>
          </section>
        </div>
      )}
      {toast && <div className="support-toast" role="status"><span>✓</span>{toast}</div>}
    </main>
  );
}
