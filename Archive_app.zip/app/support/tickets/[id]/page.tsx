import SupportPortal from "../../SupportPortal";

export default function SupportTicketPage() {
  return <SupportPortal />;
}
