"use client";

import { FormEvent, useMemo, useState } from "react";

export type DealMode = "negotiation" | "collaboration";
export type DealRole = "seller" | "influencer";

type DealWorkspaceProps = {
  mode: DealMode;
  role: DealRole;
  onNavigate: (view: "campaigns" | DealMode) => void;
  flash: (message: string) => void;
};

type Message = {
  id: number;
  author: string;
  body: string;
  mine?: boolean;
  system?: boolean;
  time: string;
};

type Task = {
  id: number;
  title: string;
  owner: "Seller" | "Creator";
  due: string;
  done: boolean;
};

const threadCards = [
  { id: "RFLS-02841", title: "Summer Reset Kit", state: "Negotiating", active: true },
  { id: "RFLS-02816", title: "Sunday Reset Live", state: "Awaiting reply" },
  { id: "RFLS-02792", title: "Desk Refresh Drop", state: "Draft" },
];

const initialTasks: Task[] = [
  { id: 1, title: "Approve final product talking points", owner: "Seller", due: "Today", done: true },
  { id: 2, title: "Upload vertical teaser cut", owner: "Creator", due: "Jul 28", done: true },
  { id: 3, title: "Confirm inventory and live promo code", owner: "Seller", due: "Jul 29", done: false },
  { id: 4, title: "Complete technical rehearsal", owner: "Creator", due: "Jul 30", done: false },
  { id: 5, title: "Approve final run of show", owner: "Seller", due: "Jul 30", done: false },
];

export default function DealWorkspace({ mode, role, onNavigate, flash }: DealWorkspaceProps) {
  const isSeller = role === "seller";
  const you = isSeller ? "Aster Supply" : "Alex Jordan";
  const partner = isSeller ? "Maya Chen" : "Aster & Vale";
  const partnerRole = isSeller ? "Creator" : "Seller";
  const [dealStatus, setDealStatus] = useState<"Negotiating" | "Accepted" | "Declined">("Negotiating");
  const [revision, setRevision] = useState(3);
  const [offer, setOffer] = useState({
    rate: 2850,
    commission: 15,
    payment: "Net 15",
    revisions: 2,
    usage: "90 days",
  });
  const [countering, setCountering] = useState(false);
  const [counterRate, setCounterRate] = useState("2850");
  const [counterRevisions, setCounterRevisions] = useState("2");
  const [counterPayment, setCounterPayment] = useState("Net 15");
  const [messageDraft, setMessageDraft] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      author: partner,
      body: isSeller
        ? "Thanks for sending the brief. The audience fit is strong. I can include a teaser and one live stream, but I would like to revisit the usage window."
        : "We loved your concept. We can move to $2,850 if the package includes one teaser, the live stream, and 90-day paid usage.",
      time: "9:42 AM",
    },
    {
      id: 2,
      author: you,
      body: isSeller
        ? "That works. We revised usage to 90 days and increased the flat rate to $2,850."
        : "That structure works for me. Can we keep the revision limit at two and use Net 15 payment terms?",
      mine: true,
      time: "10:08 AM",
    },
    {
      id: 3,
      author: "LiveLoop",
      body: "Counter offer v3 was shared. Both parties can review the updated commercial terms below.",
      system: true,
      time: "10:09 AM",
    },
  ]);
  const [tasks, setTasks] = useState(initialTasks);
  const [collabTab, setCollabTab] = useState<"checklist" | "run" | "assets" | "deadlines" | "chat">(
    "checklist",
  );
  const [collabDraft, setCollabDraft] = useState("");
  const [collabMessages, setCollabMessages] = useState<Message[]>([
    {
      id: 1,
      author: partner,
      body: isSeller
        ? "I uploaded the teaser cut and marked the two product claims that need confirmation."
        : "The product samples have shipped. Tracking and the approved claim sheet are in Assets & links.",
      time: "Yesterday",
    },
    {
      id: 2,
      author: you,
      body: isSeller
        ? "The teaser looks good. Legal has approved claim one; I will confirm claim two today."
        : "Perfect. I will use those in the rehearsal and upload the final run of show.",
      mine: true,
      time: "9:18 AM",
    },
  ]);

  const completedTasks = tasks.filter((task) => task.done).length;
  const progress = Math.round((completedTasks / tasks.length) * 100);
  const phaseIndex = dealStatus === "Accepted" ? 2 : dealStatus === "Declined" ? 0 : 1;

  const terms = useMemo(
    () => [
      ["Flat rate", `$${offer.rate.toLocaleString()}`],
      ["Sales commission", `${offer.commission}%`],
      ["Payment", offer.payment],
      ["Included revisions", `${offer.revisions}`],
      ["Paid usage", offer.usage],
      ["Deliverables", "1 teaser + 1 live stream"],
    ],
    [offer],
  );

  function sendNegotiationMessage(event: FormEvent) {
    event.preventDefault();
    const body = messageDraft.trim();
    if (!body) return;
    setMessages((current) => [
      ...current,
      { id: Date.now(), author: you, body, mine: true, time: "Just now" },
    ]);
    setMessageDraft("");
  }

  function submitCounter(event: FormEvent) {
    event.preventDefault();
    const rate = Number(counterRate);
    const revisions = Number(counterRevisions);
    if (!Number.isFinite(rate) || rate <= 0 || !Number.isFinite(revisions) || revisions < 0) {
      flash("Enter valid counter-offer terms");
      return;
    }
    setOffer((current) => ({ ...current, rate, revisions, payment: counterPayment }));
    setRevision((current) => current + 1);
    setDealStatus("Negotiating");
    setMessages((current) => [
      ...current,
      {
        id: Date.now(),
        author: you,
        body: `Countered at $${rate.toLocaleString()}, ${revisions} revisions, ${counterPayment}.`,
        mine: true,
        time: "Just now",
      },
    ]);
    setCountering(false);
    flash("Counter offer shared");
  }

  function acceptOffer() {
    setDealStatus("Accepted");
    setMessages((current) => [
      ...current,
      {
        id: Date.now(),
        author: "LiveLoop",
        body: `${you} accepted offer v${revision}. The shared collaboration room is now unlocked.`,
        system: true,
        time: "Just now",
      },
    ]);
    flash("Offer accepted — collaboration room unlocked");
  }

  function openCollaboration() {
    if (dealStatus !== "Accepted") setDealStatus("Accepted");
    onNavigate("collaboration");
  }

  function sendCollabMessage(event: FormEvent) {
    event.preventDefault();
    const body = collabDraft.trim();
    if (!body) return;
    setCollabMessages((current) => [
      ...current,
      { id: Date.now(), author: you, body, mine: true, time: "Just now" },
    ]);
    setCollabDraft("");
  }

  if (mode === "collaboration") {
    return (
      <section className="workspace-page">
        <header className="workspace-hero">
          <div>
            <button className="text-button workspace-back" onClick={() => onNavigate("negotiation")}>
              ← Back to negotiation
            </button>
            <div className="eyebrow">SHARED COLLABORATION ROOM · RFLS-02841</div>
            <h1>Summer Reset Kit</h1>
            <p>
              {you} and {partner} are preparing the campaign in one shared workspace.
            </p>
          </div>
          <div className="workspace-hero-actions">
            <span className="role-view-badge">{isSeller ? "Seller view" : "Creator view"}</span>
            <button className="button secondary" onClick={() => onNavigate("campaigns")}>
              All campaigns
            </button>
          </div>
        </header>

        <div className="workspace-progress-card">
          <div>
            <span className="mini-label">LIVE CAMPAIGN PREP</span>
            <strong>{progress}% ready</strong>
          </div>
          <div className="workspace-progress-track" aria-label={`${progress}% complete`}>
            <span style={{ width: `${progress}%` }} />
          </div>
          <span>
            {completedTasks} of {tasks.length} shared tasks complete
          </span>
        </div>

        <div className="workspace-tabs" role="tablist" aria-label="Collaboration sections">
          {[
            ["checklist", "Checklist"],
            ["run", "Run of show"],
            ["assets", "Assets & links"],
            ["deadlines", "Deadlines"],
            ["chat", "Chat"],
          ].map(([id, label]) => (
            <button
              key={id}
              className={collabTab === id ? "active" : ""}
              onClick={() => setCollabTab(id as typeof collabTab)}
              role="tab"
              aria-selected={collabTab === id}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="workspace-layout">
          <div className="workspace-main-card">
            {collabTab === "checklist" && (
              <>
                <div className="section-heading-row">
                  <div>
                    <span className="mini-label">SHARED CHECKLIST</span>
                    <h2>What needs to happen next</h2>
                  </div>
                  <span className="muted">{tasks.length - completedTasks} open</span>
                </div>
                <div className="task-list">
                  {tasks.map((task) => (
                    <label className={`shared-task ${task.done ? "complete" : ""}`} key={task.id}>
                      <input
                        type="checkbox"
                        checked={task.done}
                        onChange={() =>
                          setTasks((current) =>
                            current.map((item) =>
                              item.id === task.id ? { ...item, done: !item.done } : item,
                            ),
                          )
                        }
                      />
                      <span className="task-check" aria-hidden="true">
                        {task.done ? "✓" : ""}
                      </span>
                      <span className="task-copy">
                        <strong>{task.title}</strong>
                        <small>
                          {task.owner} · {task.due}
                        </small>
                      </span>
                      <span className={`owner-pill ${task.owner.toLowerCase()}`}>{task.owner}</span>
                    </label>
                  ))}
                </div>
              </>
            )}

            {collabTab === "run" && (
              <>
                <div className="section-heading-row">
                  <div>
                    <span className="mini-label">LIVE PLAN</span>
                    <h2>Run of show</h2>
                  </div>
                  <span className="status-pill accepted">Draft v4</span>
                </div>
                <div className="run-sheet">
                  {[
                    ["00:00", "Opening hook", "Creator", "Pin product collection"],
                    ["02:00", "Problem + routine story", "Creator", "Show before setup"],
                    ["07:00", "Product demonstration", "Both", "Seller monitors questions"],
                    ["18:00", "LiveLoop offer drop", "Seller", "Activate LIVE15"],
                    ["24:00", "Audience Q&A", "Both", "Answer top five questions"],
                    ["29:00", "Final CTA and close", "Creator", "Repeat code and link"],
                  ].map(([time, title, owner, note]) => (
                    <div className="run-row" key={time}>
                      <strong>{time}</strong>
                      <span>
                        <b>{title}</b>
                        <small>{note}</small>
                      </span>
                      <em>{owner}</em>
                    </div>
                  ))}
                </div>
              </>
            )}

            {collabTab === "assets" && (
              <>
                <div className="section-heading-row">
                  <div>
                    <span className="mini-label">SOURCE OF TRUTH</span>
                    <h2>Assets & links</h2>
                  </div>
                  <button className="button secondary" onClick={() => flash("Upload panel opened")}>
                    Upload asset
                  </button>
                </div>
                <div className="asset-list">
                  {[
                    ["Summer_Reset_Brief_v3.pdf", "Seller", "Approved"],
                    ["Maya_Teaser_Cut_02.mp4", "Creator", "Approved"],
                    ["Product_Claims_Final.pdf", "Seller", "Needs review"],
                    ["Live_Run_of_Show_v4.doc", "Creator", "In progress"],
                    ["Tracking + LIVE15 links", "Seller", "Ready"],
                  ].map(([name, owner, state]) => (
                    <div className="asset-row" key={name}>
                      <span className="asset-icon">↗</span>
                      <span>
                        <strong>{name}</strong>
                        <small>Added by {owner}</small>
                      </span>
                      <span className={`asset-state ${state.toLowerCase().replace(" ", "-")}`}>{state}</span>
                    </div>
                  ))}
                </div>
              </>
            )}

            {collabTab === "deadlines" && (
              <>
                <div className="section-heading-row">
                  <div>
                    <span className="mini-label">CAMPAIGN TIMELINE</span>
                    <h2>Deadlines and approvals</h2>
                  </div>
                  <span className="muted">Live Aug 3 · 6:00 PM</span>
                </div>
                <div className="deadline-list">
                  {[
                    ["Jul 28", "Teaser delivered", "Complete"],
                    ["Jul 29", "Claims + inventory locked", "Due next"],
                    ["Jul 30", "Technical rehearsal", "Scheduled"],
                    ["Jul 31", "Final approval", "Upcoming"],
                    ["Aug 3", "Go live", "Milestone"],
                    ["Aug 5", "Performance snapshot", "Upcoming"],
                  ].map(([date, title, state]) => (
                    <div className="deadline-row" key={title}>
                      <time>{date}</time>
                      <span>
                        <strong>{title}</strong>
                        <small>{state}</small>
                      </span>
                    </div>
                  ))}
                </div>
              </>
            )}

            {collabTab === "chat" && (
              <WorkspaceChat
                messages={collabMessages}
                draft={collabDraft}
                setDraft={setCollabDraft}
                onSubmit={sendCollabMessage}
                placeholder={`Message ${partner}…`}
              />
            )}
          </div>

          <aside className="workspace-side">
            <div className="workspace-side-card">
              <span className="mini-label">CAMPAIGN TEAM</span>
              <div className="party-row">
                <span className="party-avatar seller">AS</span>
                <span>
                  <strong>Aster Supply</strong>
                  <small>Seller · Brand lead</small>
                </span>
              </div>
              <div className="party-row">
                <span className="party-avatar creator">MC</span>
                <span>
                  <strong>Maya Chen</strong>
                  <small>Creator · Live host</small>
                </span>
              </div>
            </div>
            <div className="workspace-side-card locked-terms">
              <span className="mini-label">LOCKED COMMERCIAL TERMS</span>
              <strong>${offer.rate.toLocaleString()} + {offer.commission}% commission</strong>
              <p>{offer.payment} · {offer.revisions} revisions · {offer.usage} usage</p>
              <button className="text-button" onClick={() => onNavigate("negotiation")}>
                View accepted offer →
              </button>
            </div>
            <div className="workspace-side-card ai-nudge">
              <span className="ai-dot">AI</span>
              <div>
                <strong>Readiness assist</strong>
                <p>
                  Inventory confirmation is the highest-risk blocker. Resolve it before the technical rehearsal.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    );
  }

  return (
    <section className="deal-page">
      <header className="deal-hero">
        <div>
          <button className="text-button workspace-back" onClick={() => onNavigate("campaigns")}>
            ← Back to campaigns
          </button>
          <div className="eyebrow">COMMERCIAL NEGOTIATION · RFLS-02841</div>
          <h1>Agree on terms with {partner}</h1>
          <p>Review every revision, discuss details, and unlock the shared campaign room.</p>
        </div>
        <div className="deal-hero-meta">
          <span className="role-view-badge">{isSeller ? "Seller view" : "Creator view"}</span>
          <span className={`status-pill ${dealStatus.toLowerCase()}`}>{dealStatus}</span>
        </div>
      </header>

      <div className="deal-phase-track" aria-label="Deal progress">
        {["Proposed", "Negotiating", "Accepted", "Preparing"].map((phase, index) => (
          <div className={index <= phaseIndex ? "active" : ""} key={phase}>
            <span>{index < phaseIndex ? "✓" : index + 1}</span>
            <strong>{phase}</strong>
          </div>
        ))}
      </div>

      <div className="deal-thread-strip" aria-label="Negotiation threads">
        {threadCards.map((thread) => (
          <button className={thread.active ? "active" : ""} key={thread.id}>
            <span>{thread.id}</span>
            <strong>{thread.title}</strong>
            <small>{thread.state}</small>
          </button>
        ))}
      </div>

      <div className="deal-layout">
        <div className="deal-main">
          <div className="offer-card">
            <div className="section-heading-row">
              <div>
                <span className="mini-label">LATEST COUNTER OFFER · V{revision}</span>
                <h2>${offer.rate.toLocaleString()} campaign package</h2>
              </div>
              <span className="offer-time">Updated today, 10:09 AM</span>
            </div>
            <div className="terms-grid">
              {terms.map(([label, value]) => (
                <div key={label}>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
            </div>
            <div className="offer-history">
              <span className="history-dot" />
              <div>
                <strong>Original proposal</strong>
                <p>$2,400 · Net 30 · 3 revisions · 180-day paid usage</p>
              </div>
              <span className="history-arrow">→</span>
              <div>
                <strong>Counter offer v{revision}</strong>
                <p>${offer.rate.toLocaleString()} · {offer.payment} · {offer.revisions} revisions · {offer.usage} usage</p>
              </div>
            </div>
          </div>

          <div className="negotiation-chat-card">
            <div className="section-heading-row">
              <div>
                <span className="mini-label">PRIVATE DEAL THREAD</span>
                <h2>{you} ↔ {partner}</h2>
              </div>
              <button className="text-button" onClick={() => flash("Brief RFLS-02841 opened")}>
                Open brief ↗
              </button>
            </div>
            <WorkspaceChat
              messages={messages}
              draft={messageDraft}
              setDraft={setMessageDraft}
              onSubmit={sendNegotiationMessage}
              placeholder={`Message ${partner} about the offer…`}
            />
          </div>
        </div>

        <aside className="deal-side">
          {dealStatus === "Accepted" ? (
            <div className="response-card accepted-card">
              <span className="accepted-mark">✓</span>
              <span className="mini-label">OFFER ACCEPTED</span>
              <h2>Ready to collaborate</h2>
              <p>The commercial terms are locked. Continue in the shared preparation room.</p>
              <button className="button primary full" onClick={openCollaboration}>
                Open collaboration room
              </button>
              <button className="button secondary full" onClick={() => setDealStatus("Negotiating")}>
                Reopen negotiation
              </button>
            </div>
          ) : (
            <div className="response-card">
              <span className="mini-label">RESPOND TO OFFER</span>
              <h2>Choose your next move</h2>
              <p>{partnerRole} is waiting for a response to offer v{revision}.</p>
              {countering ? (
                <form className="counter-form" onSubmit={submitCounter}>
                  <label>
                    Flat rate
                    <span className="money-input">
                      <b>$</b>
                      <input value={counterRate} onChange={(event) => setCounterRate(event.target.value)} />
                    </span>
                  </label>
                  <label>
                    Included revisions
                    <input
                      type="number"
                      min="0"
                      value={counterRevisions}
                      onChange={(event) => setCounterRevisions(event.target.value)}
                    />
                  </label>
                  <label>
                    Payment terms
                    <select value={counterPayment} onChange={(event) => setCounterPayment(event.target.value)}>
                      <option>Net 7</option>
                      <option>Net 15</option>
                      <option>Net 30</option>
                    </select>
                  </label>
                  <button className="button primary full" type="submit">Send counter offer</button>
                  <button className="button secondary full" type="button" onClick={() => setCountering(false)}>
                    Cancel
                  </button>
                </form>
              ) : (
                <div className="response-actions">
                  <button className="button primary full" onClick={acceptOffer}>Accept offer</button>
                  <button className="button secondary full" onClick={() => setCountering(true)}>
                    Counter offer
                  </button>
                  <button
                    className="button ghost-danger full"
                    onClick={() => {
                      setDealStatus("Declined");
                      flash("Offer declined — negotiation remains available");
                    }}
                  >
                    Decline
                  </button>
                </div>
              )}
              {dealStatus === "Declined" && (
                <div className="declined-note">
                  This offer is declined. Send a message or counter offer to reopen the conversation.
                </div>
              )}
            </div>
          )}

          <div className="deal-side-card">
            <span className="mini-label">PROJECT CONTEXT</span>
            <div className="context-row"><span>Campaign</span><strong>Summer Reset Kit</strong></div>
            <div className="context-row"><span>Target live date</span><strong>Aug 3, 2026</strong></div>
            <div className="context-row"><span>Budget remaining</span><strong>$3,150</strong></div>
            <div className="context-row"><span>{partnerRole}</span><strong>Verified ✓</strong></div>
          </div>

          <div className="deal-side-card ai-nudge">
            <span className="ai-dot">AI</span>
            <div>
              <strong>Deal assist</strong>
              <p>
                This rate is within 4% of comparable campaigns. The shorter usage window makes the counter balanced.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </section>
  );
}

function WorkspaceChat({
  messages,
  draft,
  setDraft,
  onSubmit,
  placeholder,
}: {
  messages: Message[];
  draft: string;
  setDraft: (value: string) => void;
  onSubmit: (event: FormEvent) => void;
  placeholder: string;
}) {
  return (
    <div className="workspace-chat">
      <div className="message-list">
        {messages.map((message) =>
          message.system ? (
            <div className="system-message" key={message.id}>
              <span>✦</span>
              <p>{message.body}</p>
            </div>
          ) : (
            <div className={`message-bubble ${message.mine ? "mine" : ""}`} key={message.id}>
              <span className="message-avatar">{message.author.slice(0, 2).toUpperCase()}</span>
              <div>
                <small>{message.author} · {message.time}</small>
                <p>{message.body}</p>
              </div>
            </div>
          ),
        )}
      </div>
      <form className="chat-composer" onSubmit={onSubmit}>
        <button type="button" aria-label="Attach file">＋</button>
        <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={placeholder} />
        <button type="submit" aria-label="Send message">Send</button>
      </form>
    </div>
  );
}
