import AgencyApp from "../AgencyApp";

export default function AgencyTeamPage() {
  return <AgencyApp initialView="team" />;
}
