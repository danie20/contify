import AgencyApp from "../AgencyApp";

export default function AgencyClientsPage() {
  return <AgencyApp initialView="clients" />;
}
