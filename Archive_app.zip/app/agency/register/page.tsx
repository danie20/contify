"use client";

import { useState } from "react";
import Link from "next/link";

export default function AgencyRegisterPage() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return <main className="agency-register"><section className="agency-success"><span>✓</span><small>APPLICATION RECEIVED</small><h1>Northstar Representation is ready for review.</h1><p>We’ll verify the business and agency owner before enabling seller invitations. No seller data is connected until each client approves access.</p><div><strong>Next: business verification</strong><small>Typical review time · 1–2 business days</small></div><Link href="/agency">Open agency preview →</Link></section></main>;
  }

  return (
    <main className="agency-register">
      <header><Link href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong></Link><div>Already registered? <Link href="/signin">Sign in</Link></div></header>
      <section className="agency-register-layout">
        <aside><span>AGENCY PARTNER PROGRAM</span><h1>Manage creator commerce for every seller client.</h1><p>A dedicated workspace for independent agencies—with per-seller consent, client isolation, team permissions, and portfolio intelligence.</p><div className="agency-register-points"><div><span>01</span><p><strong>Separate client workspaces</strong>Keep seller data, budgets, and creator relationships isolated.</p></div><div><span>02</span><p><strong>Seller-controlled permissions</strong>Every client approves exactly what your team can access.</p></div><div><span>03</span><p><strong>Portfolio AI assistant</strong>Find creator and campaign opportunities across authorized clients.</p></div></div></aside>
        <section className="agency-register-card">
          <div className="agency-stepper">{[1, 2, 3].map((number) => <div className={step >= number ? "active" : ""} key={number}><span>{step > number ? "✓" : number}</span><small>{number === 1 ? "Agency" : number === 2 ? "Owner" : "Review"}</small></div>)}</div>
          {step === 1 && <><span className="agency-form-eyebrow">STEP 1 OF 3</span><h2>Tell us about your agency</h2><p>This creates the agency organization. Seller clients are invited after verification.</p><div className="agency-form-grid"><label>Legal business name<input defaultValue="Northstar Representation LLC" /></label><label>Agency website<input defaultValue="https://northstar.example" /></label><label>Country<select defaultValue="United States"><option>United States</option><option>Canada</option><option>United Kingdom</option></select></label><label>Team size<select defaultValue="11–25"><option>1–10</option><option>11–25</option><option>26–100</option></select></label><label className="full">Primary services<textarea defaultValue="Creator sourcing, campaign strategy, live commerce production, and performance reporting." /></label></div></>}
          {step === 2 && <><span className="agency-form-eyebrow">STEP 2 OF 3</span><h2>Verify the agency owner</h2><p>This person controls billing, team access, and seller-client invitations.</p><div className="agency-form-grid"><label>First name<input defaultValue="Jordan" /></label><label>Last name<input defaultValue="Miles" /></label><label className="full">Work email<input type="email" defaultValue="jordan@northstar.example" /></label><label className="full">Role<input defaultValue="Founder & Managing Director" /></label></div><div className="agency-owner-note"><span>⌾</span><p><strong>Identity and business verification</strong>Production onboarding should verify the owner and business before any seller can delegate access.</p></div></>}
          {step === 3 && <><span className="agency-form-eyebrow">STEP 3 OF 3</span><h2>Confirm the operating model</h2><p>Your agency represents seller clients. It is not a marketplace partner and cannot automatically discover or claim sellers.</p><div className="agency-review-box"><div><span>Agency</span><strong>Northstar Representation LLC</strong></div><div><span>Owner</span><strong>Jordan Miles</strong></div><div><span>Client access</span><strong>Invitation + seller consent</strong></div><div><span>Data boundary</span><strong>Isolated per seller</strong></div></div><label className="agency-consent"><input type="checkbox" defaultChecked /> I confirm that our agency will access seller information only with explicit client authorization.</label></>}
          <div className="agency-form-actions"><button disabled={step === 1} onClick={() => setStep(step - 1)}>Back</button><button className="primary" onClick={() => step < 3 ? setStep(step + 1) : setSubmitted(true)}>{step < 3 ? "Continue" : "Submit for verification"} →</button></div>
        </section>
      </section>
    </main>
  );
}
