"use client";

import { useState } from "react";
import Link from "next/link";

type AgencyView = "overview" | "clients" | "campaigns" | "team";

const clients = [
  { name: "Aster Supply", initials: "AS", category: "Wellness", status: "Active", creators: 8, campaigns: 4, revenue: "$184K", access: "Campaigns + analytics" },
  { name: "Luma Home", initials: "LH", category: "Home & design", status: "Active", creators: 5, campaigns: 2, revenue: "$96K", access: "Full delegated access" },
  { name: "Mellow Skin Co.", initials: "MS", category: "Beauty", status: "Consent pending", creators: 0, campaigns: 0, revenue: "—", access: "Invitation sent" },
];

export default function AgencyApp({ initialView = "overview" }: { initialView?: AgencyView }) {
  const [view, setView] = useState<AgencyView>(initialView);
  const [toast, setToast] = useState("");
  const [aiOpen, setAiOpen] = useState(true);
  const [navCollapsed, setNavCollapsed] = useState(false);

  const flash = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  };

  const nav: { id: AgencyView; label: string; icon: string }[] = [
    { id: "overview", label: "Portfolio", icon: "⌂" },
    { id: "clients", label: "Seller clients", icon: "◎" },
    { id: "campaigns", label: "Campaigns", icon: "◇" },
    { id: "team", label: "Team & access", icon: "◫" },
  ];

  return (
    <main className={`agency-shell ${navCollapsed ? "nav-collapsed" : ""}`}>
      <aside className="agency-sidebar">
        <button className="sidebar-collapse agency-collapse" onClick={() => setNavCollapsed(!navCollapsed)} aria-label={navCollapsed ? "Expand agency navigation" : "Collapse agency navigation"} title={navCollapsed ? "Expand navigation" : "Collapse navigation"}>{navCollapsed ? "›" : "‹"}</button>
        <Link className="agency-brand" href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>AGENCY</small></Link>
        <div className="agency-switcher"><span className="agency-avatar">NR</span><div><strong>Northstar Representation</strong><small>12 team members</small></div><button>⌄</button></div>
        <nav>{nav.map((item) => <button key={item.id} className={view === item.id ? "active" : ""} onClick={() => setView(item.id)} title={item.label}><span>{item.icon}</span><span className="agency-nav-label">{item.label}</span>{item.id === "clients" ? <small>3</small> : null}</button>)}</nav>
        <div className="agency-boundary"><span>⌾</span><p><strong>Delegated access</strong>Every seller controls the data and actions your team can use.</p></div>
        <Link className="agency-account" href="/profile"><span className="agency-avatar">JM</span><div><strong>Jordan Miles</strong><small>Agency owner</small></div></Link>
      </aside>

      <section className="agency-workspace">
        <header className="agency-topbar"><div><span className="agency-live" /> Agency workspace</div><label title="Search seller clients, creators and campaigns"><span>⌕</span><input aria-label="Search agency workspace" placeholder="Search clients, creators, campaigns…" /></label><button>?</button><button className="agency-alert">♢<span>3</span></button></header>
        <div className="agency-content">
          {view === "overview" && (
            <>
              <section className="agency-heading"><div><span>PORTFOLIO COMMAND CENTER</span><h1>Good morning, Jordan.</h1><p>Coordinate seller clients, creator relationships, and campaigns without mixing client data.</p></div><button onClick={() => flash("Seller invitation created")}>＋ Invite seller client</button></section>
              <section className="agency-stats">
                <article><span>Managed sellers</span><strong>3</strong><small>2 active · 1 pending</small></article>
                <article><span>Active campaigns</span><strong>6</strong><small className="good">+2 this month</small></article>
                <article><span>Portfolio GMV</span><strong>$280K</strong><small className="good">+18.4%</small></article>
                <article><span>Creator partners</span><strong>13</strong><small>Across 4 categories</small></article>
              </section>
              <section className="agency-grid">
                <article className="agency-card agency-clients-preview">
                  <header><div><span>CLIENT PORTFOLIO</span><h2>Seller performance</h2></div><button onClick={() => setView("clients")}>View clients →</button></header>
                  {clients.map((client) => <div className="agency-client-row" key={client.name}><span className="client-logo">{client.initials}</span><div><strong>{client.name}</strong><small>{client.category} · {client.access}</small></div><div><strong>{client.campaigns}</strong><small>campaigns</small></div><div><strong>{client.revenue}</strong><small>influenced GMV</small></div><span className={`agency-status ${client.status.toLowerCase().replaceAll(" ", "-")}`}>{client.status}</span><button onClick={() => flash(`${client.name} workspace opened`)}>→</button></div>)}
                </article>
                <aside className={`agency-ai ${aiOpen ? "" : "collapsed"}`}>
                  <button className="agency-ai-close" onClick={() => setAiOpen(!aiOpen)}>{aiOpen ? "−" : "✦"}</button>
                  {aiOpen && <><span className="agency-ai-orb">✦</span><span>AI PORTFOLIO COPILOT</span><h2>Shift two creators to Luma Home’s launch.</h2><p>Maya and Noah have audience overlap with the new collection and available inventory next week. Forecasted portfolio lift: <strong>+$18.6K</strong>.</p><div><span>Confidence</span><strong>91%</strong></div><button onClick={() => { setView("campaigns"); flash("AI recommendation added to campaign planning"); }}>Build allocation plan →</button></>}
                </aside>
              </section>
            </>
          )}

          {view === "clients" && (
            <section>
              <section className="agency-heading"><div><span>DELEGATED SELLER ACCESS</span><h1>Seller clients</h1><p>Each seller approves your agency’s permissions and can revoke access at any time.</p></div><button onClick={() => flash("Seller invitation created")}>＋ Invite seller</button></section>
              <div className="agency-consent-note"><span>⌾</span><div><strong>Consent is required per seller.</strong><p>An agency cannot discover or claim marketplace sellers. Invite an existing client, then let the seller approve specific campaign and analytics permissions.</p></div></div>
              <article className="agency-card agency-client-table">
                <div className="agency-client-head"><span>Seller</span><span>Access</span><span>Creators</span><span>Campaigns</span><span>GMV</span><span>Status</span><span>Actions</span></div>
                {clients.map((client) => <div className="agency-client-line" key={client.name}><span><i>{client.initials}</i><span><strong>{client.name}</strong><small>{client.category}</small></span></span><span>{client.access}</span><span>{client.creators}</span><span>{client.campaigns}</span><span>{client.revenue}</span><span className={`agency-status ${client.status.toLowerCase().replaceAll(" ", "-")}`}>{client.status}</span><span><button onClick={() => flash(`${client.name} permissions opened`)}>Permissions</button><button>•••</button></span></div>)}
              </article>
            </section>
          )}

          {view === "campaigns" && (
            <section>
              <section className="agency-heading"><div><span>MULTI-CLIENT DELIVERY</span><h1>Campaign operations</h1><p>Plan and track creator work with clear seller ownership, budgets, and delegated approvals.</p></div><button onClick={() => flash("Campaign brief started")}>＋ New campaign</button></section>
              <div className="agency-campaign-board">
                {[
                  ["PLANNING", ["Soft Spaces Launch", "Night Ritual Bundle"]],
                  ["CREATOR OUTREACH", ["Summer Reset Kit", "Calm Morning Edit"]],
                  ["LIVE / REPORTING", ["City Motion Drop", "Weekend Wellness"]],
                ].map(([stage, items]) => <article className="agency-column" key={stage as string}><header><span>{stage}</span><strong>{(items as string[]).length}</strong></header>{(items as string[]).map((item, index) => <button key={item} onClick={() => flash(`${item} opened`)}><span className="agency-status active">{index ? "Aster Supply" : "Luma Home"}</span><h3>{item}</h3><p>{index ? "Maya Chen · Noah Williams" : "Iris Adeyemi · Alex Jordan"}</p><div><span>{index ? "$28K" : "$42K"} forecast</span><strong>{index ? "Aug 12" : "Aug 05"} →</strong></div></button>)}</article>)}
              </div>
            </section>
          )}

          {view === "team" && (
            <section>
              <section className="agency-heading"><div><span>ROLE-BASED CONTROL</span><h1>Team and access</h1><p>Control which team members can see each client, approve campaigns, or view financial performance.</p></div><button onClick={() => flash("Team invitation ready")}>＋ Invite teammate</button></section>
              <article className="agency-card agency-team">
                {[
                  ["JM", "Jordan Miles", "Owner", "All clients", "Full access"],
                  ["PS", "Priya Shah", "Campaign director", "Aster Supply, Luma Home", "Campaigns + creators"],
                  ["OK", "Owen Kim", "Analyst", "All active clients", "Analytics only"],
                ].map(([initials, name, role, scope, access]) => <div key={name}><span className="agency-avatar">{initials}</span><div><strong>{name}</strong><small>{role}</small></div><div><span>Client scope</span><strong>{scope}</strong></div><div><span>Permission</span><strong>{access}</strong></div><button onClick={() => flash(`${name} access settings opened`)}>Manage</button></div>)}
              </article>
            </section>
          )}
        </div>
      </section>
      {toast && <div className="agency-toast"><span>✓</span>{toast}</div>}
    </main>
  );
}
