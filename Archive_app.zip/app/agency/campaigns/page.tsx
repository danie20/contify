import AgencyApp from "../AgencyApp";

export default function AgencyCampaignsPage() {
  return <AgencyApp initialView="campaigns" />;
}
