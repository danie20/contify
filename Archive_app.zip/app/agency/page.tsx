import AgencyApp from "./AgencyApp";

export default function AgencyPage() {
  return <AgencyApp />;
}
