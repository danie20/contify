"use client";

import Link from "next/link";
import { useState } from "react";

export default function EnterpriseActivatePage() {
  const [accepted, setAccepted] = useState(false);

  return (
    <main className="partner-activation">
      <header><Link href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>ENTERPRISE</small></Link><span>Secure partner invitation</span></header>
      <section className="partner-activation-layout">
        <aside><span>YOU’VE BEEN INVITED</span><h1>Join the eBay Marketplace partner workspace.</h1><p>Dana Okafor from LiveLoop invited you to help administer the US Seller Growth Program.</p><div className="partner-invite-details"><div><span>Organization</span><strong>eBay Marketplace</strong></div><div><span>Program</span><strong>US Seller Growth</strong></div><div><span>Invited role</span><strong>Partner administrator</strong></div><div><span>Invitation expires</span><strong>August 2, 2026</strong></div></div></aside>
        <section className="partner-activation-card">
          <span className="partner-invite-logo">e</span><span>ORGANIZATION-VERIFIED INVITATION</span><h2>Activate your partner account</h2><p>Your account will be limited to this partner organization and its approved LiveLoop program.</p>
          <div className="partner-invite-person"><span>EM</span><div><strong>Elena Martinez</strong><small>elena@marketplace.example</small></div><i>Verified domain</i></div>
          <div className="partner-invite-permissions"><strong>Your initial access</strong><p><span>✓</span> View seller enablement and consent status</p><p><span>✓</span> Monitor approved connectors and scopes</p><p><span>✓</span> Invite and manage partner team members</p><p><span>✓</span> Review aggregate program performance</p><p className="blocked"><span>—</span> No access to seller banking or private creator accounts</p></div>
          <label><input type="checkbox" checked={accepted} onChange={(event) => setAccepted(event.target.checked)} /> I accept the Partner Portal Terms, data-use policy, and role responsibilities.</label>
          <Link className={accepted ? "" : "disabled"} href={accepted ? "/enterprise/onboarding" : "#"} aria-disabled={!accepted}>Activate with enterprise SSO <span>→</span></Link>
          <small>Activation requires your organization’s identity provider.</small>
        </section>
      </section>
    </main>
  );
}
