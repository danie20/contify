import EnterprisePortal from "../EnterprisePortal";

export default function EnterprisePerformancePage() {
  return <EnterprisePortal initialView="performance" />;
}
