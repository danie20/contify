import EnterprisePortal from "./EnterprisePortal";

export default function EnterprisePage() {
  return <EnterprisePortal />;
}
