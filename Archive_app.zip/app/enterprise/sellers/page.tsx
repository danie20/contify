import EnterprisePortal from "../EnterprisePortal";

export default function EnterpriseSellersPage() {
  return <EnterprisePortal initialView="sellers" />;
}
