import EnterprisePortal from "../EnterprisePortal";

export default function EnterpriseConnectorsPage() {
  return <EnterprisePortal initialView="connectors" />;
}
