"use client";

import Link from "next/link";
import { useState } from "react";

export default function EnterpriseSigninPage() {
  const [loading, setLoading] = useState("");

  const continueToPortal = (method: string) => {
    setLoading(method);
    window.setTimeout(() => {
      window.location.href = "/enterprise";
    }, 700);
  };

  return (
    <main className="partner-auth">
      <section className="partner-auth-story">
        <Link className="partner-auth-brand" href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>ENTERPRISE</small></Link>
        <div><span>MARKETPLACE PARTNER NETWORK</span><h1>Bring creator commerce to your seller ecosystem.</h1><p>One secure partner workspace for seller enablement, scoped marketplace connections, creator coverage, and program performance.</p></div>
        <div className="partner-auth-proof"><div><strong>2,480</strong><span>eligible sellers</span></div><div><strong>99.98%</strong><span>connector health</span></div><div><strong>+$612K</strong><span>influenced GMV</span></div></div>
      </section>
      <section className="partner-auth-panel">
        <div className="partner-auth-card">
          <span>ENTERPRISE PARTNER ACCESS</span><h2>Sign in to your partner portal</h2><p>Use your organization’s approved identity provider or your invited work account.</p>
          <button className="partner-sso-button" onClick={() => continueToPortal("sso")}><span>⌾</span><div><strong>{loading === "sso" ? "Connecting to SSO…" : "Continue with enterprise SSO"}</strong><small>Recommended · managed by your organization</small></div><i>→</i></button>
          <div className="partner-auth-divider"><span>or use your invited account</span></div>
          <form onSubmit={(event) => { event.preventDefault(); continueToPortal("email"); }}>
            <label>Work email<input type="email" defaultValue="elena@marketplace.example" required /></label>
            <label>Password<span>Forgot password?</span><input type="password" defaultValue="enterprise123" required /></label>
            <label className="partner-remember"><input type="checkbox" defaultChecked /> Keep this trusted device signed in</label>
            <button type="submit">{loading === "email" ? "Verifying…" : "Sign in to partner portal"} <span>→</span></button>
          </form>
          <div className="partner-invite-help"><span>✦</span><p><strong>First time here?</strong>Use the secure activation link sent by your LiveLoop partner manager.</p></div>
        </div>
        <p className="partner-auth-foot"><Link href="/support">Partner support</Link><span>•</span><Link href="/signin">Seller or creator sign in</Link></p>
      </section>
    </main>
  );
}
