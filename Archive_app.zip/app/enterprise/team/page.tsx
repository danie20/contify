import EnterprisePortal from "../EnterprisePortal";

export default function EnterpriseTeamPage() {
  return <EnterprisePortal initialView="team" />;
}
