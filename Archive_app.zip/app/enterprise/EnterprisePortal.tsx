"use client";

import Link from "next/link";
import { useState } from "react";

type EnterpriseView = "overview" | "sellers" | "connectors" | "team" | "performance";

const sellerRows = [
  { name: "North & Pine", id: "EBY-882104", category: "Home & Garden", stage: "Creator-ready", consent: "Full", creators: 12, gmv: "$84.2K" },
  { name: "Trailform Supply", id: "EBY-774392", category: "Sporting Goods", stage: "Connected", consent: "Catalog + analytics", creators: 7, gmv: "$51.8K" },
  { name: "Kindred Kitchen", id: "EBY-663018", category: "Home", stage: "Verification", consent: "Catalog", creators: 0, gmv: "—" },
  { name: "Everlane Tools", id: "EBY-590147", category: "DIY", stage: "Invited", consent: "Pending", creators: 0, gmv: "—" },
];

const teamRows = [
  { initials: "EM", name: "Elena Martinez", email: "elena@marketplace.example", role: "Partner administrator", scope: "All programs", status: "Active" },
  { initials: "RK", name: "Ravi Kumar", email: "ravi@marketplace.example", role: "Integration engineer", scope: "Connectors", status: "Active" },
  { initials: "SW", name: "Sofia Wright", email: "sofia@marketplace.example", role: "Program manager", scope: "Sellers + performance", status: "Active" },
];

export default function EnterprisePortal({ initialView = "overview" }: { initialView?: EnterpriseView }) {
  const [view, setView] = useState<EnterpriseView>(initialView);
  const [toast, setToast] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [navCollapsed, setNavCollapsed] = useState(false);

  const flash = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  };

  const runSync = () => {
    setSyncing(true);
    window.setTimeout(() => {
      setSyncing(false);
      flash("Seller eligibility sync completed · 24 records updated");
    }, 900);
  };

  const nav: { id: EnterpriseView; label: string; icon: string }[] = [
    { id: "overview", label: "Program overview", icon: "⌂" },
    { id: "sellers", label: "Seller enablement", icon: "◎" },
    { id: "connectors", label: "Connectors & OAuth", icon: "⌁" },
    { id: "team", label: "Team & access", icon: "◫" },
    { id: "performance", label: "Performance", icon: "↗" },
  ];

  return (
    <main className={`partner-shell ${navCollapsed ? "nav-collapsed" : ""}`}>
      <aside className="partner-sidebar">
        <button className="sidebar-collapse partner-collapse" onClick={() => setNavCollapsed(!navCollapsed)} aria-label={navCollapsed ? "Expand enterprise navigation" : "Collapse enterprise navigation"} title={navCollapsed ? "Expand navigation" : "Collapse navigation"}>{navCollapsed ? "›" : "‹"}</button>
        <Link className="partner-brand" href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>ENTERPRISE</small></Link>
        <div className="partner-org"><span className="partner-org-logo">e</span><div><strong>eBay Marketplace</strong><small>US Seller Growth Program</small></div><button>⌄</button></div>
        <div className="partner-context"><span /> Production partner</div>
        <nav>{nav.map((item) => <button key={item.id} className={view === item.id ? "active" : ""} onClick={() => setView(item.id)} title={item.label}><span>{item.icon}</span><span className="partner-nav-label">{item.label}</span>{item.id === "sellers" ? <small>66</small> : null}</button>)}</nav>
        <div className="partner-security"><span>⌾</span><p><strong>Isolated partner tenant</strong>Only eBay-authorized program data is available in this workspace.</p></div>
        <div className="partner-user"><span>EM</span><div><strong>Elena Martinez</strong><small>Partner administrator</small></div><Link href="/enterprise/signin">Sign out</Link></div>
      </aside>

      <section className="partner-workspace">
        <header className="partner-topbar"><div><span className="partner-live" /> Enterprise partner portal</div><label title="Search enabled sellers, connector jobs and partner team members"><span>⌕</span><input aria-label="Search enterprise partner workspace" placeholder="Search sellers, connector jobs, team…" /></label><button>?</button><button className="partner-bell">♢<span>2</span></button></header>
        <div className="partner-content">
          {view === "overview" && (
            <>
              <section className="partner-heading"><div><span>SELLER GROWTH PROGRAM</span><h1>Welcome back, Elena.</h1><p>Enable eligible sellers for creator commerce while preserving seller consent and marketplace data boundaries.</p></div><button onClick={() => { setView("sellers"); flash("Seller invitation workflow opened"); }}>＋ Invite eligible sellers</button></section>
              <section className="partner-stats">
                <article><span>Eligible sellers</span><strong>2,480</strong><small className="partner-good">+184 this month</small></article>
                <article><span>LiveLoop enabled</span><strong>66</strong><small>38 creator-ready</small></article>
                <article><span>Consent conversion</span><strong>34.8%</strong><small className="partner-good">+4.2 pts</small></article>
                <article><span>Program GMV</span><strong>$612K</strong><small className="partner-good">+21.6%</small></article>
              </section>
              <section className="partner-grid">
                <article className="partner-card partner-funnel">
                  <header><div><span>SELLER ENABLEMENT</span><h2>Activation funnel</h2></div><button onClick={() => setView("sellers")}>Manage sellers →</button></header>
                  {[
                    ["Eligible in partner feed", "2,480", 100],
                    ["Invited to LiveLoop", "190", 74],
                    ["Claimed workspace", "104", 56],
                    ["Marketplace authorized", "66", 39],
                    ["Creator-ready", "38", 24],
                  ].map(([label, value, width]) => <div className="partner-funnel-row" key={label as string}><span>{label}</span><strong>{value}</strong><i><b style={{ width: `${width}%` }} /></i></div>)}
                </article>
                <aside className="partner-card partner-ai">
                  <span className="partner-ai-orb">✦</span><span>PROGRAM AI ASSISTANT</span><h2>Beauty sellers are converting fastest.</h2><p>Invite the next 42 eligible sellers with strong creator-category coverage. Estimated activation: <strong>16 new connected sellers</strong>.</p><div><span>Projected 90-day GMV</span><strong>+$148K</strong></div><button onClick={() => { setView("sellers"); flash("AI seller cohort opened for review"); }}>Review recommended cohort →</button>
                </aside>
              </section>
              <section className="partner-card partner-health">
                <header><div><span>PROGRAM HEALTH</span><h2>All critical systems operational</h2></div><span className="partner-health-score">96</span></header>
                <div><span>Seller eligibility feed</span><strong>Healthy</strong><small>Last sync 18m ago</small></div><div><span>Seller OAuth completion</span><strong>91.4%</strong><small>Within target</small></div><div><span>Creator match coverage</span><strong>84.7%</strong><small>Beauty leads</small></div><div><span>Consent revocations</span><strong>0.8%</strong><small>Last 30 days</small></div>
              </section>
            </>
          )}

          {view === "sellers" && (
            <section>
              <section className="partner-heading"><div><span>CONSENTED ENABLEMENT</span><h1>Seller enablement</h1><p>Track eligible sellers from invitation through consent, verification, and creator-ready activation.</p></div><button onClick={() => flash("Invite cohort builder opened")}>＋ Build invitation cohort</button></section>
              <div className="partner-guardrail"><span>⌾</span><div><strong>Partner eligibility does not equal seller authorization.</strong><p>Each seller claims its LiveLoop workspace and approves protected marketplace scopes before private data is synchronized.</p></div></div>
              <div className="partner-filter"><label><span>⌕</span><input placeholder="Search sellers…" /></label><button>All stages ⌄</button><button>All categories ⌄</button><button onClick={runSync}>{syncing ? "Syncing…" : "Sync eligibility"}</button></div>
              <article className="partner-card partner-table">
                <div className="partner-table-head"><span>Seller</span><span>Category</span><span>Stage</span><span>Authorized scope</span><span>Creators</span><span>GMV</span><span>Action</span></div>
                {sellerRows.map((seller) => <div className="partner-table-row" key={seller.id}><span><i>{seller.name.split(" ").map((part) => part[0]).join("").slice(0, 2)}</i><span><strong>{seller.name}</strong><small>{seller.id}</small></span></span><span>{seller.category}</span><span className={`partner-status ${seller.stage.toLowerCase().replaceAll(" ", "-")}`}>{seller.stage}</span><span>{seller.consent}</span><span>{seller.creators}</span><span>{seller.gmv}</span><span><button onClick={() => flash(`${seller.name} record opened`)}>Open</button><button>•••</button></span></div>)}
              </article>
            </section>
          )}

          {view === "connectors" && (
            <section>
              <section className="partner-heading"><div><span>INTEGRATION OPERATIONS</span><h1>Connectors and OAuth</h1><p>Monitor approved API scopes, eligibility feeds, seller authorization, and production connector health.</p></div><button onClick={runSync}>{syncing ? "Running health check…" : "Run health check"}</button></section>
              <section className="partner-connector-grid">
                <article className="partner-card partner-connector">
                  <header><div><span className="partner-connector-logo">⌁</span><div><h2>Seller eligibility feed</h2><p>Partner-managed encrypted batch feed</p></div></div><span className="partner-status active">Healthy</span></header>
                  <div><span>Last successful sync</span><strong>18 minutes ago</strong></div><div><span>Records processed</span><strong>2,480</strong></div><div><span>Schema version</span><strong>v2.4</strong></div><div><span>Next scheduled run</span><strong>11:30 AM PT</strong></div>
                  <button onClick={() => flash("Eligibility feed logs opened")}>View sync history →</button>
                </article>
                <article className="partner-card partner-connector">
                  <header><div><span className="partner-connector-logo oauth">O</span><div><h2>Seller OAuth application</h2><p>Seller-authorized marketplace access</p></div></div><span className="partner-status active">Production</span></header>
                  <div><span>Active authorizations</span><strong>66</strong></div><div><span>Pending consent</span><strong>14</strong></div><div><span>Expired credentials</span><strong>2</strong></div><div><span>Success rate</span><strong>99.98%</strong></div>
                  <button onClick={() => flash("OAuth scope settings opened")}>Review approved scopes →</button>
                </article>
              </section>
              <article className="partner-card partner-scope-card">
                <header><div><span>APPROVED DATA ACCESS</span><h2>Production OAuth scopes</h2></div><button onClick={() => flash("Scope change request started")}>Request scope change</button></header>
                {[
                  ["Catalog and item data", "Read", "Seller-approved", "Active"],
                  ["Performance analytics", "Read", "Seller-approved", "Active"],
                  ["Inventory availability", "Read", "Seller-approved", "Active"],
                  ["Order fulfillment", "None", "Not approved", "Blocked"],
                  ["Payments and banking", "None", "Prohibited", "Blocked"],
                ].map(([scope, access, consent, status]) => <div key={scope}><span><strong>{scope}</strong><small>{consent}</small></span><span>{access}</span><span className={`partner-status ${status.toLowerCase()}`}>{status}</span></div>)}
              </article>
            </section>
          )}

          {view === "team" && (
            <section>
              <section className="partner-heading"><div><span>ENTERPRISE ACCESS CONTROL</span><h1>Team and permissions</h1><p>Manage partner users with program-scoped roles, SSO enforcement, and audited access.</p></div><button onClick={() => flash("Enterprise team invitation created")}>＋ Invite team member</button></section>
              <section className="partner-access-stats"><article><span>Active members</span><strong>12</strong><small>Across 4 roles</small></article><article><span>SSO enforcement</span><strong>100%</strong><small className="partner-good">Required</small></article><article><span>Privileged admins</span><strong>2</strong><small>Quarterly review due Aug 15</small></article></section>
              <article className="partner-card partner-team">
                {teamRows.map((member) => <div key={member.email}><span>{member.initials}</span><div><strong>{member.name}</strong><small>{member.email}</small></div><div><span>Role</span><strong>{member.role}</strong></div><div><span>Scope</span><strong>{member.scope}</strong></div><span className="partner-status active">{member.status}</span><button onClick={() => flash(`${member.name} permissions opened`)}>Manage</button></div>)}
              </article>
              <article className="partner-card partner-sso"><span>⌾</span><div><span>SECURITY POLICY</span><h2>Enterprise SSO is enforced</h2><p>Users authenticate through the partner identity provider. Partner role assignments and LiveLoop program permissions are evaluated separately.</p></div><button onClick={() => flash("SSO configuration opened")}>SSO settings →</button></article>
            </section>
          )}

          {view === "performance" && (
            <section>
              <section className="partner-heading"><div><span>PROGRAM INTELLIGENCE</span><h1>Enterprise performance</h1><p>Measure seller activation, creator coverage, influenced revenue, and program quality.</p></div><button onClick={() => flash("Performance report exported")}>Export report</button></section>
              <section className="partner-stats"><article><span>Program GMV</span><strong>$612K</strong><small className="partner-good">+21.6%</small></article><article><span>Active campaigns</span><strong>142</strong><small className="partner-good">+18 this month</small></article><article><span>Seller activation</span><strong>34.8%</strong><small className="partner-good">+4.2 pts</small></article><article><span>Creator match rate</span><strong>84.7%</strong><small>Target 85%</small></article></section>
              <section className="partner-performance-grid">
                <article className="partner-card partner-bars"><header><div><span>INFLUENCED GMV</span><h2>Program growth</h2></div><strong>$612K <small>+21.6%</small></strong></header><div>{[42, 55, 49, 64, 59, 71, 68, 82, 77, 91, 87, 96].map((height, index) => <i key={index} style={{ height: `${height}%` }}><span>W{index + 1}</span></i>)}</div></article>
                <article className="partner-card partner-category"><header><div><span>CATEGORY PERFORMANCE</span><h2>Creator-commerce fit</h2></div></header>{[["Beauty", "$194K", 92], ["Home & Garden", "$168K", 84], ["Sporting Goods", "$126K", 72], ["Fashion", "$78K", 58]].map(([name, value, width]) => <div key={name as string}><span>{name}</span><strong>{value}</strong><i><b style={{ width: `${width}%` }} /></i></div>)}</article>
              </section>
            </section>
          )}
        </div>
      </section>
      {toast && <div className="partner-toast"><span>✓</span>{toast}</div>}
    </main>
  );
}
