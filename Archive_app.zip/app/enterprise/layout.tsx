import type { Metadata } from "next";
import { headers } from "next/headers";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;

  return {
    title: "LiveLoop Enterprise — Seller growth protected by consent",
    description: "Secure marketplace partner access for seller enablement, scoped OAuth, creator matching, and aggregate performance.",
    openGraph: {
      title: "LiveLoop Enterprise",
      description: "Seller growth. Protected by consent.",
      type: "website",
      images: [{ url: `${origin}/og-liveloop.png`, width: 1731, height: 909, alt: "LiveLoop Enterprise protected partner workspace" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "LiveLoop Enterprise",
      description: "Seller growth. Protected by consent.",
      images: [`${origin}/og-liveloop.png`],
    },
  };
}

export default function EnterpriseLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
