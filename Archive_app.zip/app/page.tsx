import LiveLoopApp from "./LiveLoopApp";

export default function Home() {
  return <LiveLoopApp />;
}
