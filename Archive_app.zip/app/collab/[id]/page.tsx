import LiveLoopApp from "../../LiveLoopApp";

export default function CollaborationPage() {
  return <LiveLoopApp initialRole="influencer" initialView="collaboration" />;
}
