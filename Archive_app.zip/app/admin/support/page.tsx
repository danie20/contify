import AdminApp from "../AdminApp";

export default function AdminSupportPage() {
  return <AdminApp initialTab="support" />;
}
