"use client";

import { useMemo, useState } from "react";

type AdminTab = "overview" | "discovery" | "enterprise" | "proposals" | "accounts" | "reviews" | "support" | "performance" | "audit";
type AdminAction = {
  kind: string;
  target: string;
  id: string;
  severity: "standard" | "high";
  note: string;
};

const proposalSeed = [
  { id: "RFLS-02911", seller: "Aster Supply", creator: "Maya Chen", value: "$18,400", risk: "Low", age: "18 min", status: "Pending", flags: "Rate 14% above norm" },
  { id: "RFLS-02908", seller: "Nova Beauty", creator: "Iris Adeyemi", value: "$9,750", risk: "Medium", age: "42 min", status: "Escalated", flags: "Disclosure language missing" },
  { id: "RFLS-02897", seller: "Forme Studio", creator: "Noah Williams", value: "$22,100", risk: "High", age: "1h 14m", status: "Pending", flags: "Unverified performance claim" },
  { id: "RFLS-02886", seller: "Luma Home", creator: "Alex Jordan", value: "$7,900", risk: "Low", age: "2h 06m", status: "Pending", flags: "No automated flags" },
];

const accountSeed = [
  { id: "USR-10482", name: "Aster Supply", type: "Seller", status: "Active", trust: 94, campaigns: 28, revenue: "$184K", reports: 0 },
  { id: "USR-09211", name: "Maya Chen", type: "Creator", status: "Active", trust: 97, campaigns: 41, revenue: "$326K", reports: 1 },
  { id: "USR-11704", name: "Nova Beauty", type: "Seller", status: "Review", trust: 61, campaigns: 7, revenue: "$42K", reports: 4 },
  { id: "USR-10837", name: "Flash Finds", type: "Creator", status: "Limited", trust: 48, campaigns: 12, revenue: "$18K", reports: 6 },
];

const reviewSeed = [
  { id: "REV-8821", author: "Maya Chen", subject: "Aster Supply", rating: 5, comment: "Clear brief, fast sample delivery, and transparent sales reporting.", flags: 0, status: "Published" },
  { id: "REV-8818", author: "Nova Beauty", subject: "Iris Adeyemi", rating: 2, comment: "Creator did not follow the agreed script and the campaign underperformed.", flags: 3, status: "Flagged" },
  { id: "REV-8807", author: "Noah Williams", subject: "Forme Studio", rating: 4, comment: "Good collaboration overall. Payment arrived two days later than expected.", flags: 1, status: "Published" },
];

const auditSeed = [
  { time: "10:42 AM", admin: "Priya Shah", action: "Proposal approved", target: "RFLS-02882", reason: "Required disclosures confirmed", level: "standard" },
  { time: "10:18 AM", admin: "Marcus Lee", action: "Creator limited", target: "USR-10837", reason: "Repeated misleading product claims", level: "high" },
  { time: "9:51 AM", admin: "System", action: "Payout hold created", target: "PAY-44910", reason: "Chargeback threshold exceeded", level: "high" },
  { time: "9:27 AM", admin: "Elena Torres", action: "Review restored", target: "REV-8792", reason: "Appeal confirmed review was authentic", level: "standard" },
];

const supportSeed = [
  { id: "TKT-1048", subject: "Creator payout still pending", customer: "Maya Chen", role: "Creator", priority: "Urgent", status: "Open", channel: "Email", age: "34 min", sla: "42 min", owner: "Lena Park", category: "Payments", campaign: "RFLS-02841" },
  { id: "TKT-1044", subject: "Seller changed product after approval", customer: "Alex Jordan", role: "Creator", priority: "High", status: "Investigating", channel: "Chat", age: "1h 12m", sla: "1h 48m", owner: "Omar Reed", category: "Campaign", campaign: "RFLS-02803" },
  { id: "TKT-1039", subject: "Need to update business verification", customer: "Nova Beauty", role: "Seller", priority: "Normal", status: "Waiting", channel: "Web", age: "3h 08m", sla: "20h", owner: "Unassigned", category: "Account", campaign: "—" },
  { id: "TKT-1036", subject: "Dispute over final commission amount", customer: "Noah Williams", role: "Creator", priority: "High", status: "Open", channel: "Web", age: "4h 21m", sla: "2h 39m", owner: "Lena Park", category: "Dispute", campaign: "RFLS-02775" },
];

const sellerLeadSeed = [
  { id: "LEAD-2048", name: "North & Pine", marketplace: "eBay", category: "Home & Garden", fit: 94, volume: "$82K/mo", status: "Admin review", provenance: "Browse API", owner: "A. Kim" },
  { id: "LEAD-2043", name: "Mellow Skin Co.", marketplace: "Walmart", category: "Beauty", fit: 91, volume: "$64K/mo", status: "Ready to invite", provenance: "Partner feed", owner: "J. Moss" },
  { id: "LEAD-2039", name: "Trailform Supply", marketplace: "eBay", category: "Sporting Goods", fit: 87, volume: "$48K/mo", status: "Invited", provenance: "Browse API", owner: "A. Kim" },
  { id: "LEAD-2031", name: "Kindred Kitchen", marketplace: "Walmart", category: "Home", fit: 84, volume: "$36K/mo", status: "Claimed", provenance: "Seller OAuth", owner: "S. Patel" },
];

function AdminMark() {
  return <span className="admin-mark live-loop-mark">L</span>;
}

function RiskBadge({ value }: { value: string }) {
  return <span className={`admin-badge ${value.toLowerCase()}`}>{value}</span>;
}

export default function AdminApp({ initialTab = "overview" }: { initialTab?: AdminTab }) {
  const [tab, setTab] = useState<AdminTab>(initialTab);
  const [proposals, setProposals] = useState(proposalSeed);
  const [accounts, setAccounts] = useState(accountSeed);
  const [reviews, setReviews] = useState(reviewSeed);
  const [audit, setAudit] = useState(auditSeed);
  const [action, setAction] = useState<AdminAction | null>(null);
  const [reason, setReason] = useState("");
  const [toast, setToast] = useState("");
  const [query, setQuery] = useState("");
  const [supportTickets, setSupportTickets] = useState(supportSeed);
  const [selectedTicket, setSelectedTicket] = useState(0);
  const [internalNote, setInternalNote] = useState("");
  const [sellerLeads, setSellerLeads] = useState(sellerLeadSeed);
  const [connectorSyncing, setConnectorSyncing] = useState("");
  const [navCollapsed, setNavCollapsed] = useState(false);

  const nav: { id: AdminTab; label: string; icon: string; count?: number }[] = [
    { id: "overview", label: "Command center", icon: "⌂" },
    { id: "discovery", label: "Seller discovery", icon: "⌕", count: sellerLeads.filter((lead) => lead.status === "Admin review").length },
    { id: "enterprise", label: "Enterprise partners", icon: "▦" },
    { id: "proposals", label: "Proposal queue", icon: "◇", count: proposals.filter((p) => p.status === "Pending" || p.status === "Escalated").length },
    { id: "accounts", label: "Users & listings", icon: "◎", count: accounts.filter((a) => a.status !== "Active").length },
    { id: "reviews", label: "Reviews & comments", icon: "☷", count: reviews.filter((r) => r.status === "Flagged").length },
    { id: "support", label: "Customer support", icon: "◌", count: supportTickets.filter((ticket) => ticket.status === "Open").length },
    { id: "performance", label: "Platform performance", icon: "↗" },
    { id: "audit", label: "Audit trail", icon: "◫" },
  ];

  const filteredAccounts = useMemo(
    () => accounts.filter((account) => `${account.name} ${account.type} ${account.id}`.toLowerCase().includes(query.toLowerCase())),
    [accounts, query]
  );

  const requestAction = (next: AdminAction) => {
    setAction(next);
    setReason("");
  };

  const runConnector = (marketplace: string) => {
    setConnectorSyncing(marketplace);
    window.setTimeout(() => {
      setConnectorSyncing("");
      setToast(`${marketplace} discovery completed · 18 qualified leads found`);
      window.setTimeout(() => setToast(""), 3000);
    }, 900);
  };

  const advanceLead = (id: string, nextStatus: string) => {
    setSellerLeads((items) => items.map((lead) => lead.id === id ? { ...lead, status: nextStatus } : lead));
    setToast(`${id} moved to ${nextStatus.toLowerCase()}`);
    window.setTimeout(() => setToast(""), 3000);
  };

  const confirmAction = () => {
    if (!action || reason.trim().length < 8) return;
    if (action.id.startsWith("RFLS")) {
      const nextStatus = action.kind.includes("Approve") ? "Approved" : action.kind.includes("Deny") ? "Denied" : "Overridden";
      setProposals((items) => items.map((item) => item.id === action.id ? { ...item, status: nextStatus } : item));
    }
    if (action.id.startsWith("USR")) {
      const nextStatus = action.kind.includes("Restore") ? "Active" : action.kind.includes("Delist") ? "Delisted" : "Suspended";
      setAccounts((items) => items.map((item) => item.id === action.id ? { ...item, status: nextStatus } : item));
    }
    if (action.id.startsWith("REV")) {
      const nextStatus = action.kind.includes("Restore") ? "Published" : action.kind.includes("Override") ? "Overridden" : "Hidden";
      setReviews((items) => items.map((item) => item.id === action.id ? { ...item, status: nextStatus } : item));
    }
    setAudit((items) => [{
      time: "Just now",
      admin: "Dana Okafor",
      action: action.kind,
      target: action.id,
      reason: reason.trim(),
      level: action.severity,
    }, ...items]);
    setToast(`${action.kind} recorded for ${action.target}`);
    setAction(null);
    setReason("");
    window.setTimeout(() => setToast(""), 3000);
  };

  return (
    <main className={`admin-shell ${navCollapsed ? "nav-collapsed" : ""}`}>
      <aside className="admin-sidebar">
        <button className="sidebar-collapse admin-collapse" onClick={() => setNavCollapsed(!navCollapsed)} aria-label={navCollapsed ? "Expand admin navigation" : "Collapse admin navigation"} title={navCollapsed ? "Expand navigation" : "Collapse navigation"}>{navCollapsed ? "›" : "‹"}</button>
        <button className="admin-brand" onClick={() => setTab("overview")}><AdminMark /><span>live<span>loop</span></span><small>ADMIN</small></button>
        <div className="admin-environment"><span /> Production controls</div>
        <nav>
          {nav.map((item) => (
            <button className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)} key={item.id}>
              <span className="admin-nav-icon">{item.icon}</span><span>{item.label}</span>
              {item.count ? <strong>{item.count}</strong> : null}
            </button>
          ))}
        </nav>
        <div className="admin-sidebar-bottom">
          <div className="admin-security-note"><span>⌾</span><div><strong>Privileged session</strong><small>Step-up verified · 26m left</small></div></div>
          <button className="admin-account"><span className="admin-avatar">DO</span><div><strong>Dana Okafor</strong><small>Trust & Safety Lead</small></div><span>•••</span></button>
        </div>
      </aside>

      <section className="admin-workspace">
        <header className="admin-topbar">
          <div><span className="admin-live" /> LiveLoop operations</div>
          <label title="Search users, proposals, reviews, tickets, payouts and seller leads"><span>⌕</span><input aria-label="Search LiveLoop operations" placeholder="Search user, RFLS, review, ticket or seller lead…" /></label>
          <button className="admin-alert">♢<span>5</span></button>
          <button className="admin-help">?</button>
        </header>

        <div className="admin-content">
          {tab === "overview" && (
            <>
              <section className="admin-heading">
                <div><span className="admin-eyebrow">COMMAND CENTER</span><h1>Good morning, Dana.</h1><p>Here is what needs a decision across the marketplace today.</p></div>
                <div className="admin-heading-actions"><button>Export report</button><button className="primary" onClick={() => setTab("proposals")}>Review priority queue <span>→</span></button></div>
              </section>
              <section className="admin-stats">
                <article><div><span>Open review queue</span><strong>17</strong><small className="warn">6 near SLA</small></div><i>◇</i></article>
                <article><div><span>Active marketplace users</span><strong>12,842</strong><small className="good">+8.4% this month</small></div><i>◎</i></article>
                <article><div><span>GMV under management</span><strong>$2.84M</strong><small className="good">+16.2% vs last month</small></div><i>↗</i></article>
                <article><div><span>Trust incidents</span><strong>8</strong><small className="bad">3 high severity</small></div><i>!</i></article>
              </section>
              <section className="admin-overview-grid">
                <article className="admin-card admin-priority">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">PRIORITY QUEUE</span><h2>Decisions requiring attention</h2></div><button onClick={() => setTab("proposals")}>View all →</button></div>
                  <div className="admin-priority-list">
                    {proposals.slice(0, 3).map((proposal) => (
                      <div key={proposal.id}>
                        <RiskBadge value={proposal.risk} />
                        <div><strong>{proposal.seller} × {proposal.creator}</strong><span>{proposal.id} · {proposal.flags}</span></div>
                        <div className="admin-sla"><strong>{proposal.age}</strong><span>in queue</span></div>
                        <button onClick={() => { setTab("proposals"); }}>Review →</button>
                      </div>
                    ))}
                  </div>
                </article>
                <article className="admin-card admin-health">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">MARKETPLACE HEALTH</span><h2>Healthy, with 2 watch areas</h2></div><span className="admin-health-score">92</span></div>
                  <div className="admin-health-items">
                    <div><span>Proposal approval SLA</span><strong>96.8%</strong><i className="good">On target</i></div>
                    <div><span>Successful campaign rate</span><strong>89.4%</strong><i className="good">+2.1%</i></div>
                    <div><span>Creator payout on time</span><strong>97.1%</strong><i className="warn">Below 98% goal</i></div>
                    <div><span>Review appeal reversal</span><strong>6.2%</strong><i className="warn">Watch</i></div>
                  </div>
                </article>
              </section>
              <section className="admin-overview-grid lower">
                <article className="admin-card">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">RISK SIGNALS</span><h2>Emerging patterns</h2></div><button>Open risk center →</button></div>
                  <div className="risk-signal-list">
                    <div><span className="risk-symbol high">!</span><div><strong>Unverified revenue claims</strong><p>14 creator campaign briefs flagged in Beauty.</p></div><small>+38% WoW</small></div>
                    <div><span className="risk-symbol medium">◇</span><div><strong>Late creator payouts</strong><p>11 seller payouts are beyond the 3-day target.</p></div><small>$18.2K held</small></div>
                    <div><span className="risk-symbol low">◎</span><div><strong>Coordinated review activity</strong><p>One account cluster requires identity review.</p></div><small>8 accounts</small></div>
                  </div>
                </article>
                <article className="admin-card">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">ADMIN COVERAGE</span><h2>Team workload</h2></div><button>Manage assignments →</button></div>
                  <div className="coverage-list">
                    {[["Trust & Safety", 72, "9 open"], ["Commerce Ops", 54, "5 open"], ["Payments", 38, "3 open"]].map(([label, load, open]) => <div key={label as string}><span>{label}</span><div><i style={{ width: `${load}%` }} /></div><strong>{open}</strong></div>)}
                  </div>
                  <div className="admin-ai-note"><span>✦</span><div><strong>AI triage saved an estimated 6.4 hours today</strong><p>42 low-risk items were auto-prioritized, not auto-decided.</p></div></div>
                </article>
              </section>
            </>
          )}

          {tab === "discovery" && (
            <section>
              <div className="admin-heading">
                <div><span className="admin-eyebrow">SELLER ACQUISITION</span><h1>Marketplace seller discovery</h1><p>Find qualified seller leads, review provenance, and invite them to claim a verified LiveLoop workspace.</p></div>
                <div className="admin-heading-actions"><button>Discovery rules</button><button className="primary" onClick={() => runConnector("All connectors")}>{connectorSyncing ? "Syncing…" : "Run all connectors"} <span>↻</span></button></div>
              </div>
              <div className="discovery-guardrail"><span>⌾</span><div><strong>Discovery creates internal leads—not marketplace listings.</strong><p>Sellers become visible to creators only after they claim the profile, complete verification, and authorize protected marketplace data.</p></div></div>
              <section className="connector-grid">
                <article className="admin-card connector-card">
                  <div className="connector-title"><span className="connector-logo ebay">e</span><div><h2>eBay seller discovery</h2><p>Public catalog and seller signals via Browse API</p></div><RiskBadge value="Active" /></div>
                  <div className="connector-metrics"><div><span>Last sync</span><strong>24 min ago</strong></div><div><span>Qualified leads</span><strong>148</strong></div><div><span>Claim rate</span><strong>21.4%</strong></div></div>
                  <div className="connector-scope"><span>Public scope</span><strong>Items · categories · seller identity</strong><small>Private account data requires seller OAuth</small></div>
                  <button onClick={() => runConnector("eBay")}>{connectorSyncing === "eBay" ? "Syncing eBay…" : "Run discovery"} <span>→</span></button>
                </article>
                <article className="admin-card connector-card">
                  <div className="connector-title"><span className="connector-logo walmart">✦</span><div><h2>Walmart Marketplace</h2><p>Approved partner feed with seller authorization</p></div><RiskBadge value="Review" /></div>
                  <div className="connector-metrics"><div><span>Environment</span><strong>Sandbox</strong></div><div><span>Qualified leads</span><strong>62</strong></div><div><span>Consent rate</span><strong>34.8%</strong></div></div>
                  <div className="connector-scope"><span>Partner scope</span><strong>Eligible sellers · items · analytics</strong><small>Seller OAuth required before protected data sync</small></div>
                  <button onClick={() => runConnector("Walmart")}>{connectorSyncing === "Walmart" ? "Testing connection…" : "Test partner connector"} <span>→</span></button>
                </article>
              </section>
              <section className="admin-card discovery-ai">
                <span>✦</span><div><span className="admin-eyebrow">AI ACQUISITION COPILOT</span><h2>Prioritize 23 sellers in Home, Beauty, and Fitness</h2><p>These sellers show strong product-market fit for the current creator network, sufficient catalog depth, and no duplicate LiveLoop account.</p></div><button onClick={() => setToast("AI shortlist opened for review")}>Review shortlist →</button>
              </section>
              <div className="admin-searchbar"><span>⌕</span><input placeholder="Search lead, category or marketplace…" /><button>All connectors ⌄</button><button>All stages ⌄</button></div>
              <article className="admin-table-card">
                <div className="admin-table discovery-table admin-table-head"><span>Seller lead</span><span>Source</span><span>Category</span><span>AI fit</span><span>Sales signal</span><span>Stage</span><span>Owner</span><span>Next action</span></div>
                {sellerLeads.map((lead) => (
                  <div className="admin-table discovery-table" key={lead.id}>
                    <span><strong>{lead.name}</strong><small>{lead.id}</small></span>
                    <span><strong>{lead.marketplace}</strong><small>{lead.provenance}</small></span>
                    <span>{lead.category}</span><span><strong className="score-high">{lead.fit}%</strong></span><span>{lead.volume}</span>
                    <span><RiskBadge value={lead.status} /></span><span>{lead.owner}</span>
                    <span className="admin-row-actions">
                      {lead.status === "Admin review" && <button className="approve" onClick={() => advanceLead(lead.id, "Ready to invite")}>Qualify</button>}
                      {lead.status === "Ready to invite" && <button className="approve" onClick={() => advanceLead(lead.id, "Invited")}>Invite</button>}
                      {lead.status === "Invited" && <button onClick={() => advanceLead(lead.id, "Claimed")}>Mark claimed</button>}
                      {lead.status === "Claimed" && <button onClick={() => setToast("Opening seller verification record")}>Verify</button>}
                      <button>Details</button>
                    </span>
                  </div>
                ))}
              </article>
            </section>
          )}

          {tab === "enterprise" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">PARTNER ECOSYSTEM</span><h1>Enterprise marketplace partners</h1><p>Operate marketplace agreements, seller enablement, consent, and connector health separately from independent agencies.</p></div><div className="admin-heading-actions"><button onClick={() => { window.location.href = "/enterprise/signin"; }}>Partner login preview</button><button className="primary" onClick={() => { window.location.href = "/enterprise/activate/EBAY-2026-DEMO"; }}>＋ Invite partner admin</button></div></div>
              <section className="enterprise-flow admin-card">
                <div className="admin-card-head"><div><span className="admin-eyebrow">CONTROLLED ENABLEMENT FLOW</span><h2>From partnership to influencer-ready sellers</h2></div><RiskBadge value="Active" /></div>
                <div className="enterprise-steps">
                  {[
                    ["01", "Partner agreement", "Commercial terms and approved use cases"],
                    ["02", "Connector approval", "API app, scopes, security and sandbox"],
                    ["03", "Seller eligibility", "Partner feed or permitted discovery"],
                    ["04", "Seller consent", "Claim, terms and OAuth authorization"],
                    ["05", "Creator-ready", "Verified workspace and campaign access"],
                  ].map(([number, title, detail]) => <div key={number}><span>{number}</span><strong>{title}</strong><small>{detail}</small></div>)}
                </div>
              </section>
              <div className="enterprise-partner-grid">
                <article className="admin-card enterprise-partner-card">
                  <div><span className="connector-logo ebay">e</span><div><h2>eBay</h2><p>Discovery + seller-authorized connection</p></div><RiskBadge value="Active" /></div>
                  <dl><div><dt>Integration</dt><dd>Browse API + OAuth</dd></div><div><dt>Enabled sellers</dt><dd>38</dd></div><div><dt>Pending consent</dt><dd>14</dd></div><div><dt>Connector health</dt><dd className="good">99.98%</dd></div></dl>
                  <div className="enterprise-progress"><span>Partner rollout</span><strong>Phase 2 of 3</strong><i><b style={{ width: "72%" }} /></i></div>
                  <button onClick={() => { window.location.href = "/enterprise"; }}>Open partner workspace →</button>
                </article>
                <article className="admin-card enterprise-partner-card">
                  <div><span className="connector-logo walmart">✦</span><div><h2>Walmart Marketplace</h2><p>Solution Provider approval in progress</p></div><RiskBadge value="Review" /></div>
                  <dl><div><dt>Integration</dt><dd>Partner API + OAuth</dd></div><div><dt>Sandbox sellers</dt><dd>12</dd></div><div><dt>Security checks</dt><dd>8 / 10</dd></div><div><dt>Connector health</dt><dd className="good">Sandbox healthy</dd></div></dl>
                  <div className="enterprise-progress"><span>Partner approval</span><strong>Technical validation</strong><i><b style={{ width: "58%" }} /></i></div>
                  <button onClick={() => { window.location.href = "/enterprise/onboarding"; }}>Continue approval →</button>
                </article>
              </div>
              <section className="admin-card permission-matrix">
                <div className="admin-card-head"><div><span className="admin-eyebrow">DATA GOVERNANCE</span><h2>Access boundaries by operating model</h2></div></div>
                <div className="permission-row head"><span>Capability</span><span>LiveLoop admin</span><span>Agency</span><span>Enterprise partner</span></div>
                <div className="permission-row"><span>Discover permitted public seller leads</span><strong>✓</strong><strong>—</strong><strong>Own ecosystem</strong></div>
                <div className="permission-row"><span>Access protected seller data</span><strong>With seller OAuth</strong><strong>Delegated only</strong><strong>Consented scopes</strong></div>
                <div className="permission-row"><span>Manage multiple seller campaigns</span><strong>Oversight</strong><strong>✓ Client portfolio</strong><strong>Program controls</strong></div>
              </section>
            </section>
          )}

          {tab === "proposals" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">GOVERNANCE</span><h1>Proposal review queue</h1><p>Approve, deny, or override RFLS decisions with a recorded reason.</p></div><div className="admin-heading-actions"><button>Rules</button><button>Queue settings</button></div></div>
              <div className="admin-filterbar"><button className="active">All open <span>4</span></button><button>Escalated <span>1</span></button><button>High risk <span>1</span></button><button>Appeals</button><select><option>Oldest first</option><option>Highest risk</option></select></div>
              <article className="admin-table-card">
                <div className="admin-table proposal-table admin-table-head"><span>Proposal</span><span>Parties</span><span>Value</span><span>Risk</span><span>Queue age</span><span>Status</span><span>Decision</span></div>
                {proposals.map((proposal) => (
                  <div className="admin-table proposal-table" key={proposal.id}>
                    <span><strong>{proposal.id}</strong><small>{proposal.flags}</small></span>
                    <span><strong>{proposal.seller}</strong><small>with {proposal.creator}</small></span>
                    <span><strong>{proposal.value}</strong><small>projected GMV</small></span>
                    <span><RiskBadge value={proposal.risk} /></span>
                    <span>{proposal.age}</span>
                    <span><RiskBadge value={proposal.status} /></span>
                    <span className="admin-row-actions">
                      <button className="approve" onClick={() => requestAction({ kind: "Approve proposal", target: proposal.id, id: proposal.id, severity: "standard", note: "Approval will move the proposal to the parties’ active campaign pipeline." })}>Approve</button>
                      <button className="deny" onClick={() => requestAction({ kind: "Deny proposal", target: proposal.id, id: proposal.id, severity: "standard", note: "Denial will notify both parties and record the policy basis." })}>Deny</button>
                      <button onClick={() => requestAction({ kind: "Override proposal decision", target: proposal.id, id: proposal.id, severity: "high", note: "Overrides bypass the normal policy outcome and require a detailed justification." })}>Override</button>
                    </span>
                  </div>
                ))}
              </article>
            </section>
          )}

          {tab === "accounts" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">MARKETPLACE ACCESS</span><h1>Users and listings</h1><p>Investigate, limit, suspend, delist, or restore sellers and creators.</p></div><div className="admin-heading-actions"><button>Bulk review</button><button className="primary">Invite reviewer</button></div></div>
              <div className="admin-searchbar"><span>⌕</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by name, user ID, role or risk…" /><button>All roles ⌄</button><button>All statuses ⌄</button></div>
              <article className="admin-table-card">
                <div className="admin-table account-table admin-table-head"><span>Account</span><span>Role</span><span>Trust score</span><span>Campaigns</span><span>GMV influenced</span><span>Reports</span><span>Status</span><span>Actions</span></div>
                {filteredAccounts.map((account) => (
                  <div className="admin-table account-table" key={account.id}>
                    <span><strong>{account.name}</strong><small>{account.id}</small></span><span>{account.type}</span>
                    <span><strong className={account.trust < 65 ? "score-low" : "score-high"}>{account.trust}</strong><small>/ 100</small></span>
                    <span>{account.campaigns}</span><span>{account.revenue}</span><span>{account.reports}</span>
                    <span><RiskBadge value={account.status} /></span>
                    <span className="admin-row-actions">
                      <button onClick={() => requestAction({ kind: account.status === "Active" ? "Suspend account" : "Restore account", target: account.name, id: account.id, severity: "high", note: "This changes the account’s ability to join or operate campaigns." })}>{account.status === "Active" ? "Suspend" : "Restore"}</button>
                      <button className="deny" onClick={() => requestAction({ kind: "Delist account", target: account.name, id: account.id, severity: "high", note: "Delisting removes the profile and opportunities from marketplace discovery." })}>Delist</button>
                    </span>
                  </div>
                ))}
              </article>
            </section>
          )}

          {tab === "reviews" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">CONTENT INTEGRITY</span><h1>Reviews and comments</h1><p>Moderate reported feedback while preserving a transparent appeal history.</p></div><div className="admin-heading-actions"><button>Moderation policy</button><button>Appeals queue</button></div></div>
              <div className="review-list">
                {reviews.map((review) => (
                  <article className="admin-card review-card" key={review.id}>
                    <div className="review-meta"><div><strong>{review.author}</strong><span>reviewed {review.subject} · {review.id}</span></div><div className="review-stars">{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</div><RiskBadge value={review.status} /></div>
                    <blockquote>“{review.comment}”</blockquote>
                    <div className="review-signals"><span>{review.flags} community flags</span><span>Authenticity score: {review.flags > 2 ? "63%" : "96%"}</span><span>Posted 2 days ago</span></div>
                    <div className="review-actions"><button onClick={() => requestAction({ kind: review.status === "Published" ? "Hide review" : "Restore review", target: review.id, id: review.id, severity: "standard", note: "The review author and subject will be notified of this moderation decision." })}>{review.status === "Published" ? "Hide review" : "Restore review"}</button><button onClick={() => requestAction({ kind: "Override review decision", target: review.id, id: review.id, severity: "high", note: "This overrides the current moderation result and must cite a policy or appeal outcome." })}>Override decision</button><button>Open evidence</button></div>
                  </article>
                ))}
              </div>
            </section>
          )}

          {tab === "support" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">CUSTOMER OPERATIONS</span><h1>Support desk</h1><p>Triage seller and creator requests with full account, campaign, and payment context.</p></div><div className="admin-heading-actions"><button>Saved views</button><button className="primary">＋ New ticket</button></div></div>
              <section className="support-admin-stats">
                <article><span>Open tickets</span><strong>34</strong><small className="warn">7 nearing SLA</small></article>
                <article><span>First response</span><strong>18m</strong><small className="good">6m faster</small></article>
                <article><span>Resolution time</span><strong>4h 12m</strong><small className="good">Within 6h goal</small></article>
                <article><span>Customer satisfaction</span><strong>94.6%</strong><small className="good">+1.8 pts</small></article>
              </section>
              <div className="support-desk">
                <aside className="support-ticket-list admin-card">
                  <div className="support-list-tools"><label><span>⌕</span><input placeholder="Search tickets…" /></label><button>≡</button></div>
                  <div className="support-view-tabs"><button className="active">My queue <span>3</span></button><button>Unassigned <span>8</span></button><button>All</button></div>
                  {supportTickets.map((ticket, index) => (
                    <button className={`support-ticket-row ${selectedTicket === index ? "active" : ""}`} key={ticket.id} onClick={() => setSelectedTicket(index)}>
                      <div><RiskBadge value={ticket.priority} /><span>{ticket.age}</span></div>
                      <strong>{ticket.subject}</strong><p>{ticket.customer} · {ticket.role}</p>
                      <div><span>{ticket.id} · {ticket.category}</span><RiskBadge value={ticket.status} /></div>
                    </button>
                  ))}
                </aside>
                <article className="support-ticket-detail admin-card">
                  <div className="support-detail-head">
                    <div><span className="admin-eyebrow">{supportTickets[selectedTicket].id} · {supportTickets[selectedTicket].channel}</span><h2>{supportTickets[selectedTicket].subject}</h2><p>Opened by {supportTickets[selectedTicket].customer} · {supportTickets[selectedTicket].age} ago</p></div>
                    <div><RiskBadge value={supportTickets[selectedTicket].priority} /><RiskBadge value={supportTickets[selectedTicket].status} /></div>
                  </div>
                  <div className="support-context-strip">
                    <div><span>Customer</span><strong>{supportTickets[selectedTicket].customer}</strong><small>{supportTickets[selectedTicket].role}</small></div>
                    <div><span>Related campaign</span><strong>{supportTickets[selectedTicket].campaign}</strong><small>{supportTickets[selectedTicket].category}</small></div>
                    <div><span>Owner</span><strong>{supportTickets[selectedTicket].owner}</strong><small>Customer Operations</small></div>
                    <div><span>SLA remaining</span><strong className="warn">{supportTickets[selectedTicket].sla}</strong><small>Priority target</small></div>
                  </div>
                  <div className="support-conversation">
                    <div className="support-message customer"><span className="support-person">MC</span><div><header><strong>{supportTickets[selectedTicket].customer}</strong><span>Today · 10:18 AM</span></header><p>Hi, I completed the live campaign and the dashboard says the payout was released, but it has not reached my bank account yet. Can you check what happened?</p></div></div>
                    <div className="support-message agent"><span className="support-person">LP</span><div><header><strong>Lena Park · Support</strong><span>Today · 10:29 AM</span></header><p>Thanks for flagging this. I found the payout and I’m checking the transfer status with our payment processor. I’ll update you within the hour.</p></div></div>
                    <div className="support-event"><span>⌾</span><p><strong>Payment context attached</strong> PAY-44910 · $1,840.00 · Processor review</p></div>
                  </div>
                  <div className="support-composer">
                    <div className="support-compose-tabs"><button className="active">Reply to customer</button><button>Internal note</button></div>
                    <textarea value={internalNote} onChange={(e) => setInternalNote(e.target.value)} placeholder="Write a reply, ask for evidence, or leave an internal note…" />
                    <div><button>＋ Attach</button><button>Use template ⌄</button><button className="send" onClick={() => { setInternalNote(""); setToast("Support reply added to the ticket"); window.setTimeout(() => setToast(""), 3000); }}>Send reply</button></div>
                  </div>
                </article>
                <aside className="support-ticket-sidebar admin-card">
                  <div><span className="admin-eyebrow">TICKET CONTROLS</span><label>Status<select value={supportTickets[selectedTicket].status} onChange={(e) => setSupportTickets((items) => items.map((item, index) => index === selectedTicket ? { ...item, status: e.target.value } : item))}><option>Open</option><option>Investigating</option><option>Waiting</option><option>Resolved</option></select></label><label>Priority<select><option>{supportTickets[selectedTicket].priority}</option><option>Urgent</option><option>High</option><option>Normal</option></select></label><label>Assignee<select><option>{supportTickets[selectedTicket].owner}</option><option>Lena Park</option><option>Omar Reed</option><option>Unassigned</option></select></label></div>
                  <div className="support-admin-actions"><span className="admin-eyebrow">ESCALATION</span><button>Escalate to Payments <span>→</span></button><button>Open dispute case <span>→</span></button><button>Place payout hold <span>→</span></button></div>
                  <div className="support-customer-health"><span className="admin-eyebrow">CUSTOMER HEALTH</span><div><span>Trust score</span><strong>97</strong></div><div><span>Open tickets</span><strong>1</strong></div><div><span>Lifetime campaigns</span><strong>41</strong></div><div><span>Previous CSAT</span><strong>96%</strong></div></div>
                </aside>
              </div>
            </section>
          )}

          {tab === "performance" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">PLATFORM INTELLIGENCE</span><h1>Marketplace performance</h1><p>Commercial health, operational quality, trust, and AI effectiveness.</p></div><div className="admin-heading-actions"><button>Last 30 days ⌄</button><button>Export</button></div></div>
              <section className="admin-stats">
                <article><div><span>Gross marketplace value</span><strong>$2.84M</strong><small className="good">+16.2%</small></div><i>↗</i></article>
                <article><div><span>Completed campaigns</span><strong>1,284</strong><small className="good">+11.8%</small></div><i>✓</i></article>
                <article><div><span>Dispute rate</span><strong>1.7%</strong><small className="good">-0.4 pts</small></div><i>◇</i></article>
                <article><div><span>AI recommendation lift</span><strong>+14.6%</strong><small className="good">vs control</small></div><i>✦</i></article>
              </section>
              <div className="admin-performance-grid">
                <article className="admin-card admin-chart-card">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">GMV & CAMPAIGNS</span><h2>Marketplace growth</h2></div><span className="admin-chart-total">$2.84M <small>+16.2%</small></span></div>
                  <div className="admin-chart">
                    {[42, 55, 49, 64, 59, 73, 68, 82, 76, 91, 87, 96].map((h, i) => <div key={i}><i style={{ height: `${h}%` }} /><span>W{i + 1}</span></div>)}
                  </div>
                </article>
                <article className="admin-card">
                  <div className="admin-card-head"><div><span className="admin-eyebrow">FUNNEL QUALITY</span><h2>Campaign outcomes</h2></div></div>
                  <div className="funnel-list">
                    {[["Proposals created", "3,842", 100], ["Approved", "3,517", 91], ["Accepted by both", "2,946", 77], ["Went live", "2,602", 68], ["Completed & paid", "2,488", 65]].map(([name, val, width]) => <div key={name as string}><span>{name}</span><strong>{val}</strong><i><b style={{ width: `${width}%` }} /></i></div>)}
                  </div>
                </article>
              </div>
              <div className="admin-performance-grid tri">
                <article className="admin-card metric-panel"><span className="admin-eyebrow">TRUST & SAFETY</span><h2>Resolution quality</h2><div><span>Median resolution</span><strong>3h 18m</strong></div><div><span>Appeal reversal</span><strong>6.2%</strong></div><div><span>Repeat offender rate</span><strong>2.8%</strong></div></article>
                <article className="admin-card metric-panel"><span className="admin-eyebrow">PAYMENTS</span><h2>Money movement</h2><div><span>On-time payout</span><strong>97.1%</strong></div><div><span>Funds on hold</span><strong>$41.8K</strong></div><div><span>Chargeback rate</span><strong>0.7%</strong></div></article>
                <article className="admin-card metric-panel"><span className="admin-eyebrow">AI GOVERNANCE</span><h2>Recommendation health</h2><div><span>Acceptance rate</span><strong>38.4%</strong></div><div><span>Measured positive lift</span><strong>72.1%</strong></div><div><span>Safety fallback rate</span><strong>0.9%</strong></div></article>
              </div>
            </section>
          )}

          {tab === "audit" && (
            <section>
              <div className="admin-heading"><div><span className="admin-eyebrow">ACCOUNTABILITY</span><h1>Administrative audit trail</h1><p>Every privileged decision, override, and access change is recorded.</p></div><div className="admin-heading-actions"><button>Filter</button><button>Export signed log</button></div></div>
              <article className="admin-table-card">
                <div className="audit-summary"><div><strong>{audit.length}</strong><span>events shown</span></div><div><strong>100%</strong><span>reason coverage</span></div><div><strong>0</strong><span>unattributed actions</span></div><div><strong>7 years</strong><span>retention policy</span></div></div>
                <div className="admin-table audit-table admin-table-head"><span>Time</span><span>Administrator</span><span>Action</span><span>Target</span><span>Reason</span><span>Severity</span></div>
                {audit.map((item, index) => <div className="admin-table audit-table" key={`${item.target}-${index}`}><span>{item.time}</span><span><strong>{item.admin}</strong></span><span>{item.action}</span><span><code>{item.target}</code></span><span>{item.reason}</span><span><RiskBadge value={item.level === "high" ? "High" : "Standard"} /></span></div>)}
              </article>
            </section>
          )}
        </div>
      </section>

      {action && (
        <div className="admin-modal-backdrop" role="presentation">
          <section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="admin-action-title">
            <div className={`admin-modal-icon ${action.severity}`}>{action.severity === "high" ? "!" : "✓"}</div>
            <span className="admin-eyebrow">{action.severity === "high" ? "HIGH-IMPACT ADMIN ACTION" : "ADMIN DECISION"}</span>
            <h2 id="admin-action-title">{action.kind}</h2>
            <p>{action.note}</p>
            <div className="admin-action-target"><span>Target</span><strong>{action.target}</strong><code>{action.id}</code></div>
            <label>Required decision reason<textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reference evidence, policy, appeal outcome, or operational reason…" autoFocus /></label>
            <small>{reason.trim().length}/8 minimum characters · This reason will be written to the audit trail.</small>
            {action.severity === "high" && <div className="admin-dual-note"><span>⌾</span><div><strong>Dual-control policy</strong><p>This prototype records the action immediately. Production should require a second administrator for high-impact overrides.</p></div></div>}
            <div className="admin-modal-actions"><button onClick={() => setAction(null)}>Cancel</button><button className="confirm" disabled={reason.trim().length < 8} onClick={confirmAction}>Confirm and record</button></div>
          </section>
        </div>
      )}
      {toast && <div className="admin-toast" role="status"><span>✓</span>{toast}</div>}
    </main>
  );
}
