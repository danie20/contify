import AdminApp from "../AdminApp";

export default function AdminEnterprisePage() {
  return <AdminApp initialTab="enterprise" />;
}
