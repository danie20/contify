import AdminApp from "../AdminApp";

export default function AdminSellerDiscoveryPage() {
  return <AdminApp initialTab="discovery" />;
}
