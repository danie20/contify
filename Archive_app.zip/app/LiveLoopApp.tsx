"use client";

import { useEffect, useMemo, useState } from "react";
import DealWorkspace from "./DealWorkspace";

type Role = "seller" | "influencer";
type View =
  | "overview"
  | "discover"
  | "campaigns"
  | "negotiation"
  | "collaboration"
  | "performance"
  | "profile"
  | "subscription"
  | "onboarding"
  | "login";

type Partner = {
  id: number;
  name: string;
  handle: string;
  initials: string;
  category: string;
  accent: string;
  fit: number;
  audience: string;
  stat: string;
  statLabel: string;
  tags: string[];
  why: string;
};

const sellerMatches: Partner[] = [
  {
    id: 1,
    name: "Maya Chen",
    handle: "@mayamoves",
    initials: "MC",
    category: "Lifestyle · Fitness",
    accent: "#f58bb7",
    fit: 96,
    audience: "428K",
    stat: "6.8%",
    statLabel: "avg. conversion",
    tags: ["Women 18–34", "Wellness", "TikTok"],
    why: "Her audience over-indexes on premium wellness and converts 1.7× above your category average.",
  },
  {
    id: 2,
    name: "Noah Williams",
    handle: "@noahdaily",
    initials: "NW",
    category: "Streetwear · Culture",
    accent: "#8f91ff",
    fit: 91,
    audience: "812K",
    stat: "4.9%",
    statLabel: "avg. conversion",
    tags: ["Gen Z", "Streetwear", "Instagram"],
    why: "Strong repeat-viewer rate and a high-affinity audience for your new commuter collection.",
  },
  {
    id: 3,
    name: "Iris Adeyemi",
    handle: "@irisselects",
    initials: "IA",
    category: "Beauty · Style",
    accent: "#ffb868",
    fit: 88,
    audience: "265K",
    stat: "$4.12",
    statLabel: "revenue / viewer",
    tags: ["Premium", "Beauty", "YouTube"],
    why: "Smaller but high-intent audience with the strongest revenue per viewer in this shortlist.",
  },
];

const influencerMatches: Partner[] = [
  {
    id: 1,
    name: "Aster & Vale",
    handle: "Premium wellness",
    initials: "AV",
    category: "Health · Lifestyle",
    accent: "#3ed0a1",
    fit: 97,
    audience: "$1.2K–$1.8K",
    stat: "15%",
    statLabel: "commission",
    tags: ["Recurring", "Creator-led", "Ships US"],
    why: "Your wellness audience matches their top customers and your format performs best at their price point.",
  },
  {
    id: 2,
    name: "Luma Home",
    handle: "Design-forward living",
    initials: "LH",
    category: "Home · Design",
    accent: "#7aa9ff",
    fit: 92,
    audience: "$900–$1.4K",
    stat: "12%",
    statLabel: "commission",
    tags: ["Launch", "Home", "TikTok Shop"],
    why: "A launch campaign with strong visual storytelling potential and a low-friction product bundle.",
  },
  {
    id: 3,
    name: "Forme Studio",
    handle: "Movement essentials",
    initials: "FS",
    category: "Fitness · Apparel",
    accent: "#c093ff",
    fit: 89,
    audience: "$1.5K–$2.2K",
    stat: "10%",
    statLabel: "commission",
    tags: ["Performance", "Apparel", "Instagram"],
    why: "High earning potential and a proven fit with your active-lifestyle content pillars.",
  },
];

const sellerCampaigns = [
  { id: "RFLS-02841", partner: "Maya Chen", title: "Summer Reset Kit", status: "Preparing", date: "Jul 29", value: "$18.4K", progress: 72 },
  { id: "RFLS-02816", partner: "Noah Williams", title: "City Motion Drop", status: "Negotiating", date: "Aug 03", value: "$11.2K", progress: 44 },
  { id: "RFLS-02792", partner: "Iris Adeyemi", title: "Night Ritual Bundle", status: "Proposed", date: "Aug 08", value: "$8.7K", progress: 22 },
];

const influencerCampaigns = [
  { id: "RFLS-02841", partner: "Aster & Vale", title: "Summer Reset Kit", status: "Preparing", date: "Jul 29", value: "$1,840", progress: 72 },
  { id: "RFLS-02803", partner: "Luma Home", title: "Soft Spaces Launch", status: "Accepted", date: "Aug 02", value: "$1,420", progress: 58 },
  { id: "RFLS-02775", partner: "Forme Studio", title: "Everyday Motion", status: "Negotiating", date: "Aug 06", value: "$2,050", progress: 40 },
];

const navItems: { id: View; label: string; glyph: string }[] = [
  { id: "overview", label: "Home", glyph: "⌂" },
  { id: "discover", label: "Discover", glyph: "⌕" },
  { id: "campaigns", label: "Campaigns", glyph: "◇" },
  { id: "performance", label: "Performance", glyph: "↗" },
];

const authStories = [
  {
    audience: "FOR SELLERS",
    title: "Find creators who",
    accent: "actually convert.",
    body: "LiveLoop AI ranks creator fit, forecasts the offer, and turns campaign performance into your next sales move.",
    metric: "4.8×",
    metricLabel: "campaign ROAS",
    insight: "Pair the Summer Reset Kit with Maya Chen.",
    confidence: "92% confidence",
    glyph: "↗",
  },
  {
    audience: "FOR CREATORS",
    title: "Turn your audience into",
    accent: "lasting partnerships.",
    body: "Discover aligned sellers, prepare every live with an AI copilot, and see exactly what grows your earnings.",
    metric: "+22%",
    metricLabel: "earning lift",
    insight: "Lead with the 7-day reset challenge.",
    confidence: "89% confidence",
    glyph: "✦",
  },
  {
    audience: "FOR AGENCIES",
    title: "Run every seller relationship",
    accent: "from one loop.",
    body: "Coordinate creator discovery, approvals, campaigns, and client reporting without losing seller-controlled permissions.",
    metric: "12",
    metricLabel: "client workspaces",
    insight: "Three clients are ready for creator outreach.",
    confidence: "Portfolio insight",
    glyph: "◇",
  },
  {
    audience: "FOR ENTERPRISE",
    title: "Enable seller growth with",
    accent: "consent built in.",
    body: "Connect marketplace sellers to creators through scoped access, clear governance, and aggregate performance intelligence.",
    metric: "99.98%",
    metricLabel: "connector health",
    insight: "Fourteen sellers are ready to claim access.",
    confidence: "Consent protected",
    glyph: "◎",
  },
];

function Sparkles({ small = false }: { small?: boolean }) {
  return <span className={small ? "sparkles small" : "sparkles"} aria-hidden="true">✦</span>;
}

function MiniChart({ color = "var(--accent)" }: { color?: string }) {
  return (
    <svg className="mini-chart" viewBox="0 0 110 36" aria-hidden="true">
      <defs>
        <linearGradient id={`fade-${color.replace(/[^a-zA-Z]/g, "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d="M2 31 C14 30, 16 23, 27 25 S43 17, 53 20 S68 8, 78 13 S95 4, 108 6 L108 36 L2 36Z" fill={`url(#fade-${color.replace(/[^a-zA-Z]/g, "")})`} />
      <path d="M2 31 C14 30, 16 23, 27 25 S43 17, 53 20 S68 8, 78 13 S95 4, 108 6" fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

function StatCard({ label, value, change, color }: { label: string; value: string; change: string; color?: string }) {
  return (
    <article className="stat-card glass-card">
      <div className="stat-top">
        <span>{label}</span>
        <span className="trend">{change}</span>
      </div>
      <strong>{value}</strong>
      <MiniChart color={color} />
    </article>
  );
}

function PartnerCard({ partner, role, onConnect }: { partner: Partner; role: Role; onConnect: (partner: Partner) => void }) {
  return (
    <article className="partner-card glass-card">
      <div className="partner-head">
        <div className="avatar lg" style={{ "--avatar": partner.accent } as React.CSSProperties}>{partner.initials}</div>
        <div className="partner-title">
          <div className="name-line">
            <h3>{partner.name}</h3>
            <span className="verified" aria-label="Verified">✓</span>
          </div>
          <p>{partner.handle}</p>
        </div>
        <span className="fit-ring">{partner.fit}<small>%</small></span>
      </div>
      <p className="partner-category">{partner.category}</p>
      <div className="partner-metrics">
        <div><strong>{partner.audience}</strong><span>{role === "seller" ? "audience" : "est. fee"}</span></div>
        <div><strong>{partner.stat}</strong><span>{partner.statLabel}</span></div>
      </div>
      <div className="chip-row">
        {partner.tags.map((tag) => <span className="chip" key={tag}>{tag}</span>)}
      </div>
      <div className="why-fit"><Sparkles small /><p><strong>Why this fits</strong>{partner.why}</p></div>
      <button className="primary-button compact" onClick={() => onConnect(partner)}>
        {role === "seller" ? "Invite to campaign" : "View opportunity"} <span>→</span>
      </button>
    </article>
  );
}

function EmptyGlyph({ children }: { children: React.ReactNode }) {
  return <span className="glyph" aria-hidden="true">{children}</span>;
}

export default function LiveLoopApp({ initialView = "overview", initialRole = "seller" }: { initialView?: View; initialRole?: Role }) {
  const [role, setRole] = useState<Role>(initialRole);
  const [view, setView] = useState<View>(initialView);
  const [toast, setToast] = useState("");
  const [selectedCampaign, setSelectedCampaign] = useState(0);
  const [search, setSearch] = useState("");
  const [aiExpanded, setAiExpanded] = useState(false);
  const [acceptedAction, setAcceptedAction] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [navCollapsed, setNavCollapsed] = useState(false);
  const [authStory, setAuthStory] = useState(initialRole === "seller" ? 0 : 1);
  const [authStoryPaused, setAuthStoryPaused] = useState(false);

  const isSeller = role === "seller";
  const partners = isSeller ? sellerMatches : influencerMatches;
  const campaigns = isSeller ? sellerCampaigns : influencerCampaigns;
  const currentCampaign = campaigns[selectedCampaign] ?? campaigns[0];
  const filteredPartners = useMemo(
    () => partners.filter((p) => `${p.name} ${p.category} ${p.tags.join(" ")}`.toLowerCase().includes(search.toLowerCase())),
    [partners, search]
  );
  const activeAuthStory = authStories[authStory];

  useEffect(() => {
    if (view !== "login" || authStoryPaused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setAuthStory((current) => (current + 1) % authStories.length), 5600);
    return () => window.clearInterval(timer);
  }, [view, authStoryPaused]);

  const flash = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  };

  const switchRole = (next: Role) => {
    setRole(next);
    setAuthStory(next === "seller" ? 0 : 1);
    setSelectedCampaign(0);
    setAcceptedAction(false);
    if (view === "negotiation" || view === "collaboration") setView("campaigns");
  };

  const openPartner = (partner: Partner) => {
    if (isSeller) {
      flash(`Campaign invite drafted for ${partner.name}`);
      setView("negotiation");
    } else {
      flash(`${partner.name} opportunity opened`);
      setView("negotiation");
    }
  };

  if (view === "login") {
    return (
      <main className={`auth-shell ${role}`}>
        <div className="ambient ambient-one" />
        <div className="ambient ambient-two" />
        <section className="auth-story" onMouseEnter={() => setAuthStoryPaused(true)} onMouseLeave={() => setAuthStoryPaused(false)}>
          <button className="brand auth-brand" onClick={() => setView("overview")} aria-label="LiveLoop home">
            <span className="brand-mark live-loop-mark">L</span>
            <span>live<span>loop</span></span>
          </button>
          <div className="auth-story-stage" aria-live="polite">
            <div className="auth-story-kicker"><span className="eyebrow">{activeAuthStory.audience}</span><span>0{authStory + 1} / 04</span></div>
            <div className="auth-copy" key={activeAuthStory.audience}>
              <h1>{activeAuthStory.title} <em>{activeAuthStory.accent}</em></h1>
              <p>{activeAuthStory.body}</p>
            </div>
            <div className="auth-story-visual">
              <div className="auth-orbit" aria-hidden="true"><span>{activeAuthStory.glyph}</span><i /><i /><i /></div>
              <article className="auth-ai-card">
                <div><span>✦ LIVELOOP AI</span><small>{activeAuthStory.confidence}</small></div>
                <strong>{activeAuthStory.insight}</strong>
                <p>Recommended from authorized workspace signals and recent performance.</p>
              </article>
              <div className="auth-live-metric"><strong>{activeAuthStory.metric}</strong><span>{activeAuthStory.metricLabel}</span></div>
            </div>
            <div className="auth-story-controls" aria-label="Choose a LiveLoop story">
              {authStories.map((story, index) => (
                <button key={story.audience} className={authStory === index ? "active" : ""} onClick={() => setAuthStory(index)} aria-label={`Show ${story.audience.toLowerCase()} story`}><span /></button>
              ))}
            </div>
          </div>
          <div className="auth-loop-ribbon" aria-hidden="true">
            <div><span>DISCOVER</span><i>→</i><span>CONNECT</span><i>→</i><span>STREAM</span><i>→</i><span>LEARN</span><i>→</i><span>REPEAT</span><i>↻</i></div>
            <div><span>DISCOVER</span><i>→</i><span>CONNECT</span><i>→</i><span>STREAM</span><i>→</i><span>LEARN</span><i>→</i><span>REPEAT</span><i>↻</i></div>
          </div>
        </section>
        <section className="auth-panel">
          <div className="auth-card glass-card">
            <div className="auth-role-switch">
              <button className={role === "seller" ? "active" : ""} onClick={() => switchRole("seller")}>I’m a seller</button>
              <button className={role === "influencer" ? "active" : ""} onClick={() => switchRole("influencer")}>I’m a creator</button>
            </div>
            <span className="eyebrow">WELCOME BACK</span>
            <h2>Sign in to LiveLoop</h2>
            <p>Continue to your {role === "seller" ? "seller workspace" : "creator studio"}.</p>
            <button className="social-login" onClick={() => setView("overview")}><span>G</span> Continue with Google</button>
            <div className="auth-divider"><span>or continue with email</span></div>
            <form onSubmit={(event) => { event.preventDefault(); setView("overview"); flash("Welcome back to LiveLoop"); }}>
              <label>Email address<input type="email" defaultValue={role === "seller" ? "hello@astersupply.co" : "alex@creator.co"} required /></label>
              <label>Password<span className="label-link">Forgot password?</span><input type="password" defaultValue="liveloop123" required /></label>
              <label className="remember"><input type="checkbox" defaultChecked /> Keep me signed in</label>
              <button className="primary-button full" type="submit">Sign in <span>→</span></button>
            </form>
            <p className="auth-foot">New to LiveLoop? <button onClick={() => setView("onboarding")}>Create your account</button></p>
            <div className="auth-public-links"><a className="auth-help-link" href="/ai">Explore LiveLoop AI <span>→</span></a><a className="auth-help-link" href="/help">AI Help Center <span>→</span></a></div>
          </div>
          <p className="legal-copy">By continuing, you agree to the LiveLoop Terms and Privacy Policy.</p>
        </section>
      </main>
    );
  }

  return (
    <main className={`app-shell ${role} ${navCollapsed ? "nav-collapsed" : ""}`}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <aside className="sidebar" aria-label="Main navigation">
        <button className="sidebar-collapse" onClick={() => setNavCollapsed(!navCollapsed)} aria-label={navCollapsed ? "Expand navigation" : "Collapse navigation"} title={navCollapsed ? "Expand navigation" : "Collapse navigation"}>{navCollapsed ? "›" : "‹"}</button>
        <button className="brand" onClick={() => setView("overview")} aria-label="LiveLoop home">
          <span className="brand-mark live-loop-mark">L</span>
          <span>live<span>loop</span></span>
        </button>
        <div className="role-switch" aria-label="Choose workspace">
          <button className={isSeller ? "active" : ""} onClick={() => switchRole("seller")}>Seller</button>
          <button className={!isSeller ? "active" : ""} onClick={() => switchRole("influencer")}>Creator</button>
        </div>
        <nav>
          {navItems.map((item) => (
            <button
              key={item.id}
              className={
                view === item.id ||
                (item.id === "campaigns" && (view === "negotiation" || view === "collaboration"))
                  ? "active"
                  : ""
              }
              onClick={() => setView(item.id)}
            >
              <EmptyGlyph>{item.glyph}</EmptyGlyph>
              <span>{item.label}</span>
              {item.id === "campaigns" && <span className="nav-count">3</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button onClick={() => { window.location.href = "/ai"; }}><EmptyGlyph>✦</EmptyGlyph><span>LiveLoop AI</span></button>
          <button onClick={() => { window.location.href = "/support"; }}><EmptyGlyph>?</EmptyGlyph><span>Help & support</span></button>
          <button className={view === "profile" ? "active" : ""} onClick={() => setView("profile")}><EmptyGlyph>⚙</EmptyGlyph><span>Profile & settings</span></button>
          <button className="account" onClick={() => setView("profile")} aria-label="Open profile">
            <div className="avatar">{isSeller ? "AS" : "AJ"}</div>
            <div><strong>{isSeller ? "Aster Supply" : "Alex Jordan"}</strong><span>{isSeller ? "Seller · Pro" : "Creator · Elite"}</span></div>
            <span>•••</span>
          </button>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div className="mobile-brand">
            <span className="brand-mark live-loop-mark">L</span>
            <strong>live<span>loop</span></strong>
          </div>
          <div className="context-label"><span className="live-dot" /> {isSeller ? "Seller workspace" : "Creator studio"}</div>
          <div className="top-actions">
            <button className="plan-chip" onClick={() => setView("subscription")}>{isSeller ? "Pro plan" : "Elite plan"}</button>
            <button className="search-trigger" onClick={() => { setView("discover"); flash(`Search ${isSeller ? "creators, campaigns and audiences" : "sellers, opportunities and campaigns"}`); }} title={`Search across your ${isSeller ? "seller" : "creator"} workspace`}><span>⌕</span> Search <kbd>⌘ K</kbd></button>
            <button className="icon-button" aria-label="Notifications">♢<span className="notification-dot" /></button>
            <button className="avatar mobile-avatar" onClick={() => setView("profile")} aria-label="Open profile">{isSeller ? "AS" : "AJ"}</button>
          </div>
        </header>

        <div className="content">
          {(view === "negotiation" || view === "collaboration") && (
            <DealWorkspace mode={view} role={role} onNavigate={setView} flash={flash} />
          )}

          {view === "overview" && (
            <>
              <section className="page-heading">
                <div>
                  <span className="eyebrow">{isSeller ? "GROWTH OVERVIEW" : "CREATOR OVERVIEW"}</span>
                  <h1>{isSeller ? <>Turn attention into <em>revenue.</em></> : <>Create with clarity. <em>Earn more.</em></>}</h1>
                  <p>{isSeller ? "Your AI growth team found three ways to lift this week’s live sales." : "Your AI copilot has your next collaboration and live plan ready."}</p>
                </div>
                <button className="secondary-button" onClick={() => setView("performance")}><span>↗</span> View full report</button>
              </section>

              <section className="stat-grid">
                {isSeller ? (
                  <>
                    <StatCard label="Attributed revenue" value="$48,620" change="+18.2%" color="#48d7a5" />
                    <StatCard label="Live conversion" value="5.84%" change="+0.9%" color="#8f91ff" />
                    <StatCard label="Active campaigns" value="6" change="2 this week" color="#ffb868" />
                    <StatCard label="Orders from live" value="1,284" change="+14.7%" color="#f58bb7" />
                  </>
                ) : (
                  <>
                    <StatCard label="Earnings this month" value="$7,480" change="+22.4%" color="#8f91ff" />
                    <StatCard label="Live conversion" value="6.42%" change="+1.1%" color="#48d7a5" />
                    <StatCard label="Active collabs" value="4" change="1 new" color="#ffb868" />
                    <StatCard label="Returning viewers" value="38.6%" change="+4.2%" color="#f58bb7" />
                  </>
                )}
              </section>

              <section className="overview-grid">
                <article className="ai-hero glass-card">
                  <div className="ai-header">
                    <div className="ai-orb"><Sparkles /></div>
                    <div>
                      <span className="eyebrow">LIVELOOP AI · {isSeller ? "SALES BOOST" : "COPILOT"}</span>
                      <h2>{isSeller ? "Your highest-impact move" : "Your next live is ready to win"}</h2>
                    </div>
                    <span className="confidence">92% confidence</span>
                  </div>
                  <div className="ai-main">
                    <div>
                      <span className="recommend-label">{isSeller ? "RECOMMENDED ACTION" : "PRE-LIVE BRIEF"}</span>
                      <h3>{isSeller ? <>Pair the <strong>Summer Reset Kit</strong> with Maya Chen.</> : <>Lead with the <strong>7-day reset challenge</strong> for Aster & Vale.</>}</h3>
                      <p>{isSeller ? "Maya’s audience has the strongest category affinity and has responded well to premium bundles between $65–$90." : "Your audience saves challenge-based content 2.1× more often. Open with the outcome, then demo the ritual in three simple steps."}</p>
                    </div>
                    <div className="lift-card">
                      <span>{isSeller ? "Expected revenue lift" : "Projected live earnings"}</span>
                      <strong>{isSeller ? "+$8.4K" : "$1.6K–$2.1K"}</strong>
                      <small>{isSeller ? "+17–23% vs. baseline" : "based on 5.9–7.1% CVR"}</small>
                    </div>
                  </div>
                  <div className="evidence-row">
                    <div><span>01</span><p><strong>{isSeller ? "Audience fit" : "Opening hook"}</strong>{isSeller ? "94% category overlap" : "“Your 7-day reset starts here.”"}</p></div>
                    <div><span>02</span><p><strong>{isSeller ? "Offer" : "Hero proof"}</strong>{isSeller ? "Bundle at $78 + free ship" : "Show texture + 3-step routine"}</p></div>
                    <div><span>03</span><p><strong>{isSeller ? "Best window" : "Close"}</strong>{isSeller ? "Tue · 6:30 PM PT" : "Challenge CTA + pinned code"}</p></div>
                  </div>
                  {aiExpanded && (
                    <div className="expanded-ai">
                      <div><span>Why now</span><p>{isSeller ? "Inventory is healthy, margin can support a 15% creator commission, and Tuesday is Maya’s strongest buyer-intent window." : "Returning viewers are up 12% and this campaign aligns with your strongest wellness content cluster."}</p></div>
                      <div><span>Watch-out</span><p>{isSeller ? "Keep the discount below 12% to protect contribution margin." : "Avoid leading with ingredient detail; viewers dropped when product education ran longer than 80 seconds."}</p></div>
                    </div>
                  )}
                  <div className="ai-actions">
                    <button className="primary-button" onClick={() => { setAcceptedAction(true); flash(isSeller ? "Growth play added to your campaign" : "Brief added to your live room"); }}>
                      {acceptedAction ? "✓ Added to campaign" : isSeller ? "Build this campaign" : "Add to live room"}
                    </button>
                    <button className="text-button" onClick={() => setAiExpanded(!aiExpanded)}>{aiExpanded ? "Hide rationale" : "See AI rationale"} <span>↗</span></button>
                    <span className="ai-disclaimer">Uses your authorized campaign data</span>
                  </div>
                </article>

                <aside className="next-live glass-card">
                  <div className="card-title">
                    <div><span className="eyebrow">UP NEXT</span><h2>{isSeller ? "Summer Reset Kit" : "Aster & Vale"}</h2></div>
                    <span className="status preparing">Preparing</span>
                  </div>
                  <div className="date-block"><strong>29</strong><span>JUL<br />6:30 PM PT</span></div>
                  <div className="partner-inline">
                    <div className="avatar" style={{ "--avatar": isSeller ? "#f58bb7" : "#3ed0a1" } as React.CSSProperties}>{isSeller ? "MC" : "AV"}</div>
                    <div><span>{isSeller ? "Creator partner" : "Seller partner"}</span><strong>{isSeller ? "Maya Chen" : "Aster & Vale"}</strong></div>
                  </div>
                  <div className="readiness">
                    <div><span>Campaign readiness</span><strong>72%</strong></div>
                    <div className="progress"><span style={{ width: "72%" }} /></div>
                  </div>
                  <ul className="task-list">
                    <li className="done"><span>✓</span> Terms accepted</li>
                    <li className="done"><span>✓</span> Samples delivered</li>
                    <li><span>3</span> Approve talking points</li>
                    <li><span>4</span> Run tech check</li>
                  </ul>
                  <button className="secondary-button full" onClick={() => setView("campaigns")}>Open collaboration room <span>→</span></button>
                </aside>
              </section>

              <section className="section-block">
                <div className="section-heading">
                  <div><span className="eyebrow">{isSeller ? "SMART MATCHING" : "OPPORTUNITIES FOR YOU"}</span><h2>{isSeller ? "Creators most likely to convert" : "Seller campaigns worth your time"}</h2></div>
                  <button className="text-button" onClick={() => setView("discover")}>View all matches <span>→</span></button>
                </div>
                <div className="partner-grid">
                  {partners.map((partner) => <PartnerCard partner={partner} role={role} onConnect={openPartner} key={partner.id} />)}
                </div>
              </section>
            </>
          )}

          {view === "discover" && (
            <section className="inner-page">
              <div className="page-heading compact-heading">
                <div>
                  <span className="eyebrow">{isSeller ? "CREATOR MARKETPLACE" : "SELLER MARKETPLACE"}</span>
                  <h1>{isSeller ? <>Find your next <em>sales partner.</em></> : <>Find work that <em>fits you.</em></>}</h1>
                  <p>AI-ranked recommendations based on audience fit, performance, and campaign goals.</p>
                </div>
              </div>
              <div className="filter-bar glass-card">
                <label className="search-field"><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`Search ${isSeller ? "creators, categories, audiences" : "sellers, categories, campaigns"}`} /></label>
                <button className="filter-button">Category <span>⌄</span></button>
                <button className="filter-button">Platform <span>⌄</span></button>
                <button className="filter-button">Location <span>⌄</span></button>
                <button className="ai-filter"><Sparkles small /> AI best fit</button>
              </div>
              <div className="results-meta"><span><strong>{filteredPartners.length}</strong> recommended matches</span><span>Sorted by AI fit score</span></div>
              <div className="partner-grid discover-grid">
                {filteredPartners.map((partner) => <PartnerCard partner={partner} role={role} onConnect={openPartner} key={partner.id} />)}
              </div>
            </section>
          )}

          {view === "campaigns" && (
            <section className="inner-page">
              <div className="page-heading compact-heading">
                <div>
                  <span className="eyebrow">CAMPAIGN PIPELINE</span>
                  <h1>From first hello to <em>going live.</em></h1>
                  <p>One shared workspace for RFLS requests, terms, preparation, and results.</p>
                </div>
                <button className="primary-button" onClick={() => flash("New RFLS draft created")}>＋ New campaign</button>
              </div>
              <div className="campaign-layout">
                <div className="campaign-list glass-card">
                  <div className="list-tabs"><button className="active">Active <span>3</span></button><button>Completed</button><button>Drafts</button></div>
                  {campaigns.map((campaign, index) => (
                    <button key={campaign.id} className={`campaign-row ${selectedCampaign === index ? "selected" : ""}`} onClick={() => setSelectedCampaign(index)}>
                      <div className="campaign-row-top"><span className={`status ${campaign.status.toLowerCase()}`}>{campaign.status}</span><span>{campaign.date}</span></div>
                      <h3>{campaign.title}</h3>
                      <p>{campaign.partner} · {campaign.id}</p>
                      <div className="row-progress"><span style={{ width: `${campaign.progress}%` }} /></div>
                      <div className="campaign-row-bottom"><span>{campaign.progress}% ready</span><strong>{campaign.value}</strong></div>
                    </button>
                  ))}
                </div>
                <article className="campaign-detail glass-card">
                  <div className="detail-head">
                    <div><span className="eyebrow">{currentCampaign.id}</span><h2>{currentCampaign.title}</h2><p>with {currentCampaign.partner}</p></div>
                    <div className="campaign-head-actions">
                      <button className="secondary-button compact" onClick={() => setView("negotiation")}>
                        Review negotiation
                      </button>
                      <button className="icon-button">•••</button>
                    </div>
                  </div>
                  <div className="milestone-track">
                    {["Proposed", "Terms", "Preparing", "Live", "Results"].map((step, idx) => <div className={idx < 3 ? "complete" : idx === 3 ? "current" : ""} key={step}><span>{idx < 3 ? "✓" : idx + 1}</span><small>{step}</small></div>)}
                  </div>
                  <div className="detail-grid">
                    <div><span>Live date</span><strong>{currentCampaign.date} · 6:30 PM PT</strong></div>
                    <div><span>{isSeller ? "Projected revenue" : "Projected earnings"}</span><strong>{currentCampaign.value}</strong></div>
                    <div><span>Platform</span><strong>TikTok Shop</strong></div>
                    <div><span>Commission</span><strong>15% of net sales</strong></div>
                  </div>
                  <div className="brief-card">
                    <div className="brief-icon"><Sparkles /></div>
                    <div><span className="eyebrow">AI CAMPAIGN BRIEF</span><h3>{isSeller ? "Position the bundle as a simple reset, not a product haul." : "Make the outcome tangible within the first 20 seconds."}</h3><p>Three talking points, offer framing, audience objections, and a timed run-of-show are ready.</p></div>
                    <button onClick={() => flash("AI campaign brief opened")}>Open brief →</button>
                  </div>
                  <div className="collab-sections">
                    <div className="collab-section"><div><strong>Commercial terms</strong><span>Accepted by both parties</span></div><span className="check">✓</span></div>
                    <div className="collab-section"><div><strong>Samples & assets</strong><span>4 files · delivery confirmed</span></div><span className="check">✓</span></div>
                    <div className="collab-section"><div><strong>Talking points</strong><span>Waiting for {isSeller ? "seller" : "your"} approval</span></div><span className="action-needed">Action needed</span></div>
                    <div className="collab-section"><div><strong>Live room & tech check</strong><span>Scheduled for Jul 28 · 4:00 PM</span></div><span>→</span></div>
                  </div>
                  <button className="primary-button full" onClick={() => setView("collaboration")}>Enter collaboration room <span>→</span></button>
                </article>
              </div>
            </section>
          )}

          {view === "performance" && (
            <section className="inner-page">
              <div className="page-heading compact-heading">
                <div>
                  <span className="eyebrow">PERFORMANCE INTELLIGENCE</span>
                  <h1>Know what worked. <em>Do it again.</em></h1>
                  <p>{isSeller ? "Revenue and conversion insights across every creator campaign." : "A clear story behind your content, audience, and earnings."}</p>
                </div>
                <button className="secondary-button">Last 30 days <span>⌄</span></button>
              </div>
              <section className="stat-grid">
                {isSeller ? (
                  <>
                    <StatCard label="Live commerce revenue" value="$48.6K" change="+18.2%" color="#48d7a5" />
                    <StatCard label="Return on spend" value="4.8×" change="+0.7×" color="#8f91ff" />
                    <StatCard label="Average order value" value="$76.40" change="+8.1%" color="#ffb868" />
                    <StatCard label="Creator repeat rate" value="64%" change="+12%" color="#f58bb7" />
                  </>
                ) : (
                  <>
                    <StatCard label="Total earnings" value="$7.48K" change="+22.4%" color="#8f91ff" />
                    <StatCard label="Revenue influenced" value="$31.2K" change="+19.1%" color="#48d7a5" />
                    <StatCard label="Avg. watch time" value="8m 42s" change="+1m 08s" color="#ffb868" />
                    <StatCard label="Offer acceptance" value="71%" change="+9%" color="#f58bb7" />
                  </>
                )}
              </section>
              <div className="performance-grid">
                <article className="big-chart glass-card">
                  <div className="card-title"><div><span className="eyebrow">{isSeller ? "ATTRIBUTED REVENUE" : "EARNINGS TREND"}</span><h2>{isSeller ? "$48,620" : "$7,480"}</h2></div><span className="trend big">+18.2%</span></div>
                  <div className="chart-area">
                    <div className="y-labels"><span>$16K</span><span>$12K</span><span>$8K</span><span>$4K</span><span>$0</span></div>
                    <div className="bars">
                      {[38, 51, 47, 68, 58, 79, 92, 76].map((height, i) => <div key={i} className="bar-wrap"><div className="bar" style={{ height: `${height}%` }}><span>{i === 6 ? (isSeller ? "$14.8K" : "$2.1K") : ""}</span></div><small>W{i + 1}</small></div>)}
                    </div>
                  </div>
                </article>
                <article className="ai-analysis glass-card">
                  <div className="ai-orb small-orb"><Sparkles /></div>
                  <span className="eyebrow">AI PERFORMANCE STORY</span>
                  <h2>{isSeller ? "Bundles are driving the lift." : "Your demonstrations convert."}</h2>
                  <p>{isSeller ? "Campaigns with a 3-product bundle generated 31% more revenue without reducing margin. Maya Chen’s audience responded most strongly when the offer appeared before minute 8." : "Your best streams show the product in use within the first 45 seconds. Those sessions kept 24% more viewers and converted 1.6× better."}</p>
                  <div className="analysis-proof"><span>Biggest driver</span><strong>{isSeller ? "Early bundle reveal" : "Product-in-use demo"}</strong><small>{isSeller ? "+$6.2K incremental revenue" : "+1.9 pts conversion"}</small></div>
                  <button className="primary-button full" onClick={() => flash("Next campaign playbook generated")}>Generate next playbook</button>
                </article>
              </div>
              <section className="section-block">
                <div className="section-heading"><div><span className="eyebrow">CAMPAIGN BREAKDOWN</span><h2>Performance by collaboration</h2></div></div>
                <div className="performance-table glass-card" role="table" aria-label="Campaign performance">
                  <div className="table-row table-head" role="row"><span>Campaign</span><span>Partner</span><span>Views</span><span>Conversion</span><span>{isSeller ? "Revenue" : "Earnings"}</span><span>Trend</span></div>
                  {campaigns.map((campaign, i) => (
                    <div className="table-row" role="row" key={campaign.id}>
                      <span><strong>{campaign.title}</strong><small>{campaign.id}</small></span>
                      <span>{campaign.partner}</span><span>{[84, 62, 47][i]}K</span><span>{[7.2, 5.9, 4.8][i]}%</span><span><strong>{campaign.value}</strong></span><span className="trend">+{[24, 15, 8][i]}%</span>
                    </div>
                  ))}
                </div>
              </section>
            </section>
          )}

          {view === "profile" && (
            <section className="inner-page">
              <div className="page-heading compact-heading">
                <div>
                  <span className="eyebrow">PROFILE & SETTINGS</span>
                  <h1>Your LiveLoop <em>identity.</em></h1>
                  <p>Keep the information used for matching, campaigns, and AI recommendations accurate.</p>
                </div>
                <button className="secondary-button" onClick={() => setView("login")}>Sign out</button>
              </div>
              <div className="settings-layout">
                <aside className="settings-nav glass-card">
                  <button className="active"><span>◎</span> Profile</button>
                  <button onClick={() => setView("subscription")}><span>◇</span> Plan & billing</button>
                  <button onClick={() => setView("onboarding")}><span>✓</span> Onboarding</button>
                  <button onClick={() => flash("Notification preferences opened")}><span>♢</span> Notifications</button>
                  <button onClick={() => flash("Security settings opened")}><span>⌾</span> Security</button>
                </aside>
                <div className="settings-main">
                  <article className="profile-hero glass-card">
                    <div className="avatar profile-avatar">{isSeller ? "AS" : "AJ"}</div>
                    <div><span className="eyebrow">{isSeller ? "SELLER PROFILE" : "CREATOR PROFILE"}</span><h2>{isSeller ? "Aster Supply Co." : "Alex Jordan"}</h2><p>{isSeller ? "Premium wellness essentials · Los Angeles, CA" : "@alexcreates · Wellness, lifestyle & movement"}</p></div>
                    <button className="secondary-button" onClick={() => flash("Profile image picker opened")}>Change image</button>
                    <div className="profile-complete"><span>Profile strength</span><strong>92%</strong><div className="progress"><span style={{ width: "92%" }} /></div></div>
                  </article>
                  <article className="settings-card glass-card">
                    <div className="settings-card-head"><div><h2>Basic information</h2><p>This information appears to potential partners.</p></div><span className="verified-badge">✓ Verified</span></div>
                    <div className="form-grid">
                      <label>{isSeller ? "Business name" : "Display name"}<input defaultValue={isSeller ? "Aster Supply Co." : "Alex Jordan"} /></label>
                      <label>{isSeller ? "Business email" : "Creator email"}<input type="email" defaultValue={isSeller ? "hello@astersupply.co" : "alex@creator.co"} /></label>
                      <label>Location<input defaultValue="Los Angeles, California" /></label>
                      <label>Primary category<select defaultValue="wellness"><option value="wellness">Wellness & lifestyle</option><option>Fashion</option><option>Beauty</option><option>Home</option></select></label>
                      <label className="full-field">About<textarea defaultValue={isSeller ? "We make premium, practical wellness essentials for everyday routines." : "I create honest wellness and lifestyle content that turns routines into approachable stories."} /></label>
                    </div>
                  </article>
                  <article className="settings-card glass-card">
                    <div className="settings-card-head"><div><h2>{isSeller ? "Commerce & matching" : "Audience & channels"}</h2><p>These signals improve your AI match quality.</p></div><span className="ai-connected"><Sparkles small /> AI connected</span></div>
                    <div className="connection-list">
                      {(isSeller ? [["Shopify", "Catalog, orders and conversion", "Connected"], ["TikTok Shop", "Live sales performance", "Connected"], ["Inventory feed", "Stock and product margin", "Needs review"]] : [["TikTok", "428K followers · 6.8% live CVR", "Connected"], ["Instagram", "182K followers · 4.2% engagement", "Connected"], ["YouTube", "96K subscribers · 8m avg. watch", "Connected"]]).map(([name, detail, status]) => (
                        <div className="connection-row" key={name}><div className="connection-icon">{name.slice(0, 1)}</div><div><strong>{name}</strong><span>{detail}</span></div><button className={status === "Needs review" ? "review" : ""}>{status}</button></div>
                      ))}
                    </div>
                  </article>
                  <div className="settings-actions"><button className="text-button" onClick={() => setView("overview")}>Cancel</button><button className="primary-button" onClick={() => flash("Profile changes saved")}>Save changes</button></div>
                </div>
              </div>
            </section>
          )}

          {view === "subscription" && (
            <section className="inner-page">
              <div className="page-heading compact-heading">
                <div>
                  <span className="eyebrow">MEMBERSHIP & BILLING</span>
                  <h1>A plan that grows <em>with you.</em></h1>
                  <p>{isSeller ? "Choose the workspace capacity and AI intelligence your commerce team needs." : "Choose the collaboration tools and intelligence that support your creator business."}</p>
                </div>
                <button className="secondary-button" onClick={() => setView("profile")}>← Back to profile</button>
              </div>
              <article className="current-plan glass-card">
                <div className="plan-orb"><Sparkles /></div>
                <div><span className="eyebrow">CURRENT PLAN</span><h2>{isSeller ? "LiveLoop Pro" : "Creator Elite"}</h2><p>{isSeller ? "For growing commerce teams running recurring creator campaigns." : "For established creators managing multiple brand collaborations."}</p></div>
                <div className="plan-price"><strong>{isSeller ? "$99" : "$39"}</strong><span>/ month</span><small>Renews August 25, 2026</small></div>
                <span className="status accepted">Active</span>
              </article>
              <div className="pricing-grid">
                {(isSeller ? [
                  { name: "Solo", price: "$29", copy: "Start matching and run your first live campaigns.", features: ["3 active campaigns", "Basic AI matching", "Campaign performance"] },
                  { name: "Pro", price: "$99", copy: "Scale creator partnerships with full AI sales intelligence.", features: ["Unlimited campaigns", "AI Sales Boost", "Advanced attribution", "Team workspace"], featured: true },
                  { name: "Elite", price: "$249", copy: "Operate live commerce across brands and regions.", features: ["Everything in Pro", "Multi-brand workspace", "Custom reporting", "Priority support"] },
                ] : [
                  { name: "Creator", price: "$0", copy: "Discover opportunities and build your profile.", features: ["Seller discovery", "3 active proposals", "Basic performance"] },
                  { name: "Elite", price: "$39", copy: "Run your creator business with an always-on AI copilot.", features: ["Unlimited proposals", "AI Live Copilot", "Advanced insights", "Rate guidance"], featured: true },
                  { name: "Studio", price: "$89", copy: "Manage a team of creators from one workspace.", features: ["Everything in Elite", "5 creator seats", "Shared pipeline", "Studio reporting"] },
                ]).map((plan) => (
                  <article className={`pricing-card glass-card ${plan.featured ? "featured" : ""}`} key={plan.name}>
                    {plan.featured && <span className="popular">YOUR PLAN</span>}
                    <h2>{plan.name}</h2><div className="price"><strong>{plan.price}</strong><span>/mo</span></div><p>{plan.copy}</p>
                    <ul>{plan.features.map((feature) => <li key={feature}><span>✓</span>{feature}</li>)}</ul>
                    <button className={plan.featured ? "secondary-button full" : "primary-button full"} onClick={() => flash(plan.featured ? "You’re already on this plan" : `${plan.name} plan selected`)}>{plan.featured ? "Current plan" : "Choose plan"}</button>
                  </article>
                ))}
              </div>
              <div className="billing-grid">
                <article className="settings-card glass-card"><div className="settings-card-head"><div><h2>Payment method</h2><p>Used for your monthly LiveLoop membership.</p></div><button className="text-button" onClick={() => flash("Payment method editor opened")}>Edit</button></div><div className="payment-method"><span>VISA</span><div><strong>Visa ending in 4242</strong><small>Expires 09/29</small></div></div></article>
                <article className="settings-card glass-card"><div className="settings-card-head"><div><h2>Billing history</h2><p>Your recent membership invoices.</p></div><button className="text-button" onClick={() => flash("Invoice download prepared")}>View all</button></div><div className="invoice-row"><span>Jul 25, 2026</span><strong>{isSeller ? "$99.00" : "$39.00"}</strong><span className="status accepted">Paid</span><button>↓</button></div></article>
              </div>
            </section>
          )}

          {view === "onboarding" && (
            <section className="inner-page onboarding-page">
              <div className="onboarding-progress">
                {[1, 2, 3].map((step) => <div className={step <= onboardingStep ? "active" : ""} key={step}><span>{step < onboardingStep ? "✓" : step}</span><small>{["Your profile", isSeller ? "Business goals" : "Audience & rates", "Connect data"][step - 1]}</small></div>)}
              </div>
              <article className="onboarding-card glass-card">
                <div className="onboarding-copy">
                  <span className="eyebrow">STEP {onboardingStep} OF 3</span>
                  <h1>{onboardingStep === 1 ? (isSeller ? "Tell creators what you stand for." : "Show sellers what makes you different.") : onboardingStep === 2 ? (isSeller ? "What should LiveLoop help you grow?" : "Set your audience and collaboration preferences.") : "Connect the data that powers your AI."}</h1>
                  <p>{onboardingStep === 1 ? "A complete profile creates better matches and helps the right partners say yes." : onboardingStep === 2 ? "We use these preferences to rank opportunities, suggest terms, and personalize your workspace." : "You control every connection. LiveLoop only uses authorized data to improve matching and performance guidance."}</p>
                </div>
                {onboardingStep === 1 && <div className="form-grid onboarding-form"><label>{isSeller ? "Business name" : "Creator name"}<input defaultValue={isSeller ? "Aster Supply Co." : "Alex Jordan"} /></label><label>Primary category<select defaultValue="wellness"><option value="wellness">Wellness & lifestyle</option><option>Fashion</option><option>Beauty</option></select></label><label className="full-field">Short introduction<textarea placeholder="Tell potential partners what you make and who it is for..." /></label></div>}
                {onboardingStep === 2 && <div className="goal-grid">{(isSeller ? [["↗", "Increase live revenue"], ["◎", "Launch new products"], ["◇", "Find repeat creators"], ["◫", "Reach new audiences"]] : [["↗", "Grow collaboration income"], ["◎", "Find aligned brands"], ["◇", "Improve live performance"], ["◫", "Build repeat partnerships"]]).map(([icon, label], i) => <button className={i < 2 ? "selected" : ""} key={label}><span>{icon}</span><strong>{label}</strong><small>{i < 2 ? "Selected" : "Select goal"}</small></button>)}</div>}
                {onboardingStep === 3 && <div className="connect-grid">{(isSeller ? [["S", "Shopify", "Products, orders and conversion"], ["T", "TikTok Shop", "Live sales and audience"], ["G", "Google Analytics", "Traffic and attribution"]] : [["T", "TikTok", "Audience and live performance"], ["I", "Instagram", "Content and engagement"], ["Y", "YouTube", "Watch time and audience"]]).map(([icon, name, detail], i) => <div key={name}><span>{icon}</span><div><strong>{name}</strong><small>{detail}</small></div><button className={i === 0 ? "connected" : ""} onClick={() => flash(`${name} connection updated`)}>{i === 0 ? "✓ Connected" : "Connect"}</button></div>)}</div>}
                <div className="onboarding-actions"><button className="text-button" onClick={() => onboardingStep === 1 ? setView("profile") : setOnboardingStep(onboardingStep - 1)}>← {onboardingStep === 1 ? "Exit" : "Back"}</button><button className="primary-button" onClick={() => onboardingStep === 3 ? (setView("overview"), flash("Onboarding complete")) : setOnboardingStep(onboardingStep + 1)}>{onboardingStep === 3 ? "Finish setup" : "Continue"} <span>→</span></button></div>
              </article>
            </section>
          )}
        </div>
      </section>

      <nav className="mobile-nav" aria-label="Mobile navigation">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={
              view === item.id ||
              (item.id === "campaigns" && (view === "negotiation" || view === "collaboration"))
                ? "active"
                : ""
            }
            onClick={() => setView(item.id)}
          >
            <span>{item.glyph}</span><small>{item.label}</small>
          </button>
        ))}
      </nav>

      {toast && <div className="toast" role="status"><span>✓</span>{toast}</div>}
    </main>
  );
}
