import LiveLoopApp from "../LiveLoopApp";

export default function ProfilePage() {
  return <LiveLoopApp initialView="profile" />;
}
