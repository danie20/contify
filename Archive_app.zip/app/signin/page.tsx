import LiveLoopApp from "../LiveLoopApp";

export default function SignInPage() {
  return <LiveLoopApp initialView="login" initialRole="influencer" />;
}
