import LiveLoopApp from "../LiveLoopApp";

export default function NegotiationsPage() {
  return <LiveLoopApp initialRole="influencer" initialView="negotiation" />;
}
