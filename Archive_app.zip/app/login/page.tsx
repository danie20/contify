import LiveLoopApp from "../LiveLoopApp";

export default function LoginPage() {
  return <LiveLoopApp initialView="login" />;
}
