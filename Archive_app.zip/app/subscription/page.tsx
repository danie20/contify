import LiveLoopApp from "../LiveLoopApp";

export default function SubscriptionPage() {
  return <LiveLoopApp initialView="subscription" />;
}
