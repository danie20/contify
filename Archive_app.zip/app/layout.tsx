import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";
import ThemeToggle from "./ThemeToggle";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;

  return {
    title: "LiveLoop — AI-powered live commerce",
    description: "Match sellers and influencers, run better live campaigns, and turn performance into the next growth move.",
    icons: {
      icon: "/favicon.svg",
      shortcut: "/favicon.svg",
    },
    openGraph: {
      title: "LiveLoop — AI-powered live commerce",
      description: "The AI growth workspace for sellers and influencers.",
      type: "website",
      images: [{ url: `${origin}/og-liveloop.png`, width: 1731, height: 909, alt: "LiveLoop connects sellers, creators, agencies, and enterprise marketplaces" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "LiveLoop — AI-powered live commerce",
      description: "The AI growth workspace for sellers and influencers.",
      images: [`${origin}/og-liveloop.png`],
    },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: `(() => { try { const saved = localStorage.getItem("liveloop-theme"); const theme = saved || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"); document.documentElement.dataset.theme = theme; } catch { document.documentElement.dataset.theme = "dark"; } })();` }} />
      </head>
      <body><ThemeToggle />{children}</body>
    </html>
  );
}
