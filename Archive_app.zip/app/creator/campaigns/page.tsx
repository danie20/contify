import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorCampaignsPage() {
  return <LiveLoopApp initialRole="influencer" initialView="campaigns" />;
}
