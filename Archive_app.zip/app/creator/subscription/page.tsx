import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorSubscriptionPage() {
  return <LiveLoopApp initialRole="influencer" initialView="subscription" />;
}
