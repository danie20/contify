import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorProfilePage() {
  return <LiveLoopApp initialRole="influencer" initialView="profile" />;
}
