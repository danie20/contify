import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorNegotiationsPage() {
  return <LiveLoopApp initialRole="influencer" initialView="negotiation" />;
}
