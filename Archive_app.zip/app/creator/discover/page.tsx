import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorDiscoverPage() {
  return <LiveLoopApp initialRole="influencer" initialView="discover" />;
}
