import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorOnboardingPage() {
  return <LiveLoopApp initialRole="influencer" initialView="onboarding" />;
}
