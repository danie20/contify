import LiveLoopApp from "../LiveLoopApp";

export default function CreatorHomePage() {
  return <LiveLoopApp initialRole="influencer" initialView="overview" />;
}
