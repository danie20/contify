import LiveLoopApp from "../../../LiveLoopApp";

export default function CreatorCollaborationPage() {
  return <LiveLoopApp initialRole="influencer" initialView="collaboration" />;
}
