import LiveLoopApp from "../../LiveLoopApp";

export default function CreatorPerformancePage() {
  return <LiveLoopApp initialRole="influencer" initialView="performance" />;
}
