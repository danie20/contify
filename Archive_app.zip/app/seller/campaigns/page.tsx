import LiveLoopApp from "../../LiveLoopApp";

export default function SellerCampaignsPage() {
  return <LiveLoopApp initialRole="seller" initialView="campaigns" />;
}
