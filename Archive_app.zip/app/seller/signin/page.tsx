import LiveLoopApp from "../../LiveLoopApp";

export default function SellerSignInPage() {
  return <LiveLoopApp initialView="login" initialRole="seller" />;
}
