import LiveLoopApp from "../../LiveLoopApp";

export default function SellerOnboardingPage() {
  return <LiveLoopApp initialRole="seller" initialView="onboarding" />;
}
