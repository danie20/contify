import LiveLoopApp from "../../LiveLoopApp";

export default function SellerSubscriptionPage() {
  return <LiveLoopApp initialRole="seller" initialView="subscription" />;
}
