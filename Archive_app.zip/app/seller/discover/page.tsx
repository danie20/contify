import LiveLoopApp from "../../LiveLoopApp";

export default function SellerDiscoverPage() {
  return <LiveLoopApp initialRole="seller" initialView="discover" />;
}
