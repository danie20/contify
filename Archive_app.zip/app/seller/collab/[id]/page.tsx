import LiveLoopApp from "../../../LiveLoopApp";

export default function SellerCollaborationPage() {
  return <LiveLoopApp initialRole="seller" initialView="collaboration" />;
}
