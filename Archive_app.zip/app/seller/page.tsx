import LiveLoopApp from "../LiveLoopApp";

export default function SellerHomePage() {
  return <LiveLoopApp initialRole="seller" initialView="overview" />;
}
