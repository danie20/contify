import LiveLoopApp from "../../LiveLoopApp";

export default function SellerProfilePage() {
  return <LiveLoopApp initialRole="seller" initialView="profile" />;
}
