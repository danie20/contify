import LiveLoopApp from "../../LiveLoopApp";

export default function SellerPerformancePage() {
  return <LiveLoopApp initialRole="seller" initialView="performance" />;
}
