import LiveLoopApp from "../../LiveLoopApp";

export default function SellerNegotiationsPage() {
  return <LiveLoopApp initialRole="seller" initialView="negotiation" />;
}
