import type { Metadata } from "next";
import HelpCenter from "./HelpCenter";

export const metadata: Metadata = {
  title: "LiveLoop Help Center — AI-assisted product guidance",
  description: "Role-aware guidance for LiveLoop sellers, creators, agencies, and enterprise marketplace partners.",
};

export default function HelpPage() {
  return <HelpCenter />;
}
