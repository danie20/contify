"use client";

import Link from "next/link";
import { useState } from "react";

type HelpRole = "seller" | "creator" | "agency" | "enterprise";

const roleContent: Record<HelpRole, {
  label: string;
  headline: string;
  description: string;
  workspace: string;
  features: { icon: string; title: string; body: string }[];
  prompts: string[];
}> = {
  seller: {
    label: "Seller",
    headline: "Turn creator partnerships into a repeatable growth channel.",
    description: "Find high-fit creators, build stronger offers, and use LiveLoop AI to identify the next sales move.",
    workspace: "/seller",
    features: [
      { icon: "⌕", title: "Creator discovery", body: "Rank creators by audience fit, category affinity, and conversion potential." },
      { icon: "✦", title: "AI Sales Boost", body: "Translate campaign signals into offer, timing, and creator recommendations." },
      { icon: "↗", title: "Performance intelligence", body: "Understand attributed revenue, conversion, and the actions driving lift." },
    ],
    prompts: ["How do I find the right creator?", "How does Sales Boost use my data?", "Where can I review campaign ROI?"],
  },
  creator: {
    label: "Creator",
    headline: "Choose better partnerships and prepare every live with confidence.",
    description: "Discover aligned sellers, build your live plan with an AI copilot, and see what improves your earnings.",
    workspace: "/creator",
    features: [
      { icon: "◇", title: "Seller opportunities", body: "Compare brand fit, estimated fees, commission, and campaign expectations." },
      { icon: "✦", title: "AI live copilot", body: "Get an opening hook, demo sequence, close, and watch-outs before going live." },
      { icon: "$", title: "Earnings clarity", body: "Track conversion, commission, payouts, and returning viewer performance." },
    ],
    prompts: ["How do creator payouts work?", "How does LiveLoop match me with sellers?", "Help me prepare for my next live"],
  },
  agency: {
    label: "Agency",
    headline: "Operate every seller relationship without losing control.",
    description: "Manage clients, creator outreach, approvals, campaigns, and reporting through seller-controlled permissions.",
    workspace: "/agency",
    features: [
      { icon: "▦", title: "Client portfolio", body: "Switch between seller workspaces while preserving clear operating boundaries." },
      { icon: "◎", title: "Permission controls", body: "Request only the campaign, catalog, and reporting access each client approves." },
      { icon: "↗", title: "Portfolio reporting", body: "See client readiness, creator pipeline health, and campaign performance together." },
    ],
    prompts: ["How does an agency add a seller client?", "What can agency team members access?", "How do seller approvals work?"],
  },
  enterprise: {
    label: "Enterprise",
    headline: "Enable marketplace seller growth with consent built in.",
    description: "Operate connector approval, seller eligibility, scoped authorization, creator enablement, and aggregate reporting.",
    workspace: "/enterprise/signin",
    features: [
      { icon: "⇄", title: "Marketplace connectors", body: "Monitor API health, approved scopes, sync activity, and seller authorization." },
      { icon: "✓", title: "Seller consent", body: "Keep protected seller data unavailable until claim and OAuth are complete." },
      { icon: "▥", title: "Program intelligence", body: "Measure enabled sellers, creator readiness, and aggregate program performance." },
    ],
    prompts: ["How does seller consent work?", "What data can an enterprise partner access?", "How do marketplace connectors get approved?"],
  },
};

const answers = [
  {
    terms: ["payout", "payment", "commission", "bank"],
    title: "Creator payouts and payment timing",
    body: "LiveLoop shows the campaign payout status from approval through transfer. A released payout can still take time to reach the connected bank, depending on the payment processor and bank settlement window.",
    steps: ["Open Creator Performance", "Select the campaign payout", "Review transfer status and expected arrival", "Create a payment ticket if the expected date has passed"],
    href: "/creator/performance",
    link: "Open creator performance",
  },
  {
    terms: ["creator", "match", "discovery", "right creator"],
    title: "Finding the right creator",
    body: "Creator discovery considers category affinity, audience composition, prior conversion patterns, format fit, and campaign constraints. Match scores are recommendations—not automatic approval decisions.",
    steps: ["Open Seller Discover", "Review the match rationale", "Compare audience and conversion evidence", "Invite the creator to a campaign"],
    href: "/seller/discover",
    link: "Open creator discovery",
  },
  {
    terms: ["sales boost", "data", "authorized", "ai"],
    title: "How AI Sales Boost uses data",
    body: "Sales Boost works from authorized catalog, campaign, audience, and performance signals. It explains the evidence behind each recommendation and keeps the seller responsible for the final campaign decision.",
    steps: ["Review the recommended action", "Open AI rationale", "Check expected lift and watch-outs", "Add the approved play to a campaign"],
    href: "/seller",
    link: "Open Sales Boost",
  },
  {
    terms: ["prepare", "next live", "copilot", "hook"],
    title: "Preparing for a live campaign",
    body: "The creator copilot turns campaign terms and past audience behavior into a practical brief: opening hook, product proof, demo sequence, close, and performance watch-outs.",
    steps: ["Open your creator workspace", "Review the pre-live brief", "Add the brief to the collaboration room", "Confirm talking points with the seller"],
    href: "/creator",
    link: "Open creator copilot",
  },
  {
    terms: ["agency", "seller client", "permission", "approval", "team"],
    title: "Agency access and seller control",
    body: "An agency operates as a separate organization. Each seller client explicitly authorizes the agency, chooses access boundaries, and can revoke access without affecting its LiveLoop account.",
    steps: ["Register and verify the agency", "Invite or connect a seller client", "Request scoped permissions", "Wait for seller approval before operating campaigns"],
    href: "/agency/register",
    link: "Review agency registration",
  },
  {
    terms: ["enterprise", "consent", "connector", "marketplace", "oauth", "data access"],
    title: "Enterprise seller consent and connectors",
    body: "Marketplace discovery can identify eligible sellers, but protected data remains unavailable until a seller claims its account, accepts the program terms, and completes scoped OAuth authorization.",
    steps: ["Approve the marketplace connector", "Import eligible seller leads", "Invite the seller to claim access", "Activate only the approved scopes after consent"],
    href: "/enterprise/signin",
    link: "Open enterprise access",
  },
];

export default function HelpCenter() {
  const [role, setRole] = useState<HelpRole>("seller");
  const [query, setQuery] = useState("");
  const [asked, setAsked] = useState("How do I find the right creator?");
  const content = roleContent[role];
  const normalizedQuestion = asked.toLowerCase();
  const answer = answers.find((item) => item.terms.some((term) => normalizedQuestion.includes(term))) ?? {
    title: `${content.label} help is ready`,
    body: `I can help with ${content.label.toLowerCase()} onboarding, discovery, campaigns, performance, account access, and support. Try one of the suggested questions or create a ticket for an account-specific investigation.`,
    steps: ["Choose a suggested question", "Include the feature or campaign involved", "Open the recommended workspace", "Create a support ticket if the issue remains"],
    href: content.workspace,
    link: `Open the ${content.label.toLowerCase()} workspace`,
  };

  const ask = (question: string) => {
    const cleaned = question.trim();
    if (!cleaned) return;
    setAsked(cleaned);
    setQuery("");
  };

  return (
    <main className={`help-shell ${role}`}>
      <header className="help-header">
        <Link className="help-brand" href="/"><span className="live-loop-mark">L</span><strong>live<i>loop</i></strong><small>HELP</small></Link>
        <nav aria-label="Help navigation"><Link href="/ai">LiveLoop AI</Link><Link className="active" href="/help">Help center</Link><Link href="/support">My tickets</Link><Link href="/signin">Sign in</Link></nav>
        <Link className="help-header-cta" href="/support">Contact support <span>→</span></Link>
      </header>

      <section className="help-hero">
        <div className="help-hero-copy">
          <span className="help-eyebrow">✦ AI-ASSISTED HELP CENTER</span>
          <h1>Answers that understand your <em>LiveLoop role.</em></h1>
          <p>Explore the product, get a guided answer, and move directly to the right workspace when you are ready.</p>
        </div>
        <div className="help-role-tabs" aria-label="Choose your role">
          {(Object.keys(roleContent) as HelpRole[]).map((item) => <button key={item} className={role === item ? "active" : ""} onClick={() => { setRole(item); setAsked(roleContent[item].prompts[0]); }}>{roleContent[item].label}</button>)}
        </div>
      </section>

      <section className="help-ai-grid">
        <article className="help-ask-card">
          <div className="help-ai-heading"><span>✦</span><div><small>LIVELOOP AI · GUIDED PREVIEW</small><h2>What can I help you accomplish?</h2></div><i>Answers from product guides</i></div>
          <form onSubmit={(event) => { event.preventDefault(); ask(query); }}>
            <label><span>⌕</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Ask a ${content.label.toLowerCase()} question…`} aria-label="Ask LiveLoop AI" /><button type="submit">Ask AI <span>→</span></button></label>
          </form>
          <div className="help-prompt-list">
            <span>TRY ASKING</span>
            {content.prompts.map((prompt) => <button key={prompt} onClick={() => ask(prompt)}>{prompt}<span>↗</span></button>)}
          </div>
        </article>

        <article className="help-answer-card" aria-live="polite">
          <div className="help-answer-meta"><span>ANSWER FOR {content.label.toUpperCase()}S</span><small>Based on LiveLoop product guidance</small></div>
          <h2>{answer.title}</h2>
          <p>{answer.body}</p>
          <ol>{answer.steps.map((step, index) => <li key={step}><span>0{index + 1}</span>{step}</li>)}</ol>
          <div className="help-answer-actions"><Link href={answer.href}>{answer.link} <span>→</span></Link><Link href="/support">Still need help? Create a ticket</Link></div>
        </article>
      </section>

      <section className="help-role-story">
        <div><span className="help-eyebrow">{content.label.toUpperCase()} EXPERIENCE</span><h2>{content.headline}</h2><p>{content.description}</p><Link href={content.workspace}>Explore the {content.label.toLowerCase()} workspace <span>→</span></Link></div>
        <div className="help-feature-grid">
          {content.features.map((feature) => <article key={feature.title}><span>{feature.icon}</span><h3>{feature.title}</h3><p>{feature.body}</p></article>)}
        </div>
      </section>

      <section className="help-workflow">
        <span className="help-eyebrow">THE LIVELOOP METHOD</span>
        <h2>One learning loop, from discovery to growth.</h2>
        <div>{["Discover the right fit", "Connect with clear terms", "Stream with an AI brief", "Learn from performance", "Repeat what converts"].map((step, index) => <article key={step}><span>0{index + 1}</span><strong>{step}</strong>{index < 4 && <i>→</i>}</article>)}</div>
      </section>

      <footer className="help-footer"><div><span className="live-loop-mark">L</span><strong>LiveLoop Help</strong></div><p>AI answers are guidance. Account-specific payment, safety, and access decisions are handled by a support specialist.</p><Link href="/support">Open support portal →</Link></footer>
    </main>
  );
}
