"use client";

import { useSyncExternalStore } from "react";

type Theme = "dark" | "light";

function subscribe(callback: () => void) {
  window.addEventListener("liveloop-theme-change", callback);
  window.addEventListener("storage", callback);
  return () => {
    window.removeEventListener("liveloop-theme-change", callback);
    window.removeEventListener("storage", callback);
  };
}

function getTheme(): Theme {
  return document.documentElement.dataset.theme === "light" ? "light" : "dark";
}

export default function ThemeToggle() {
  const theme = useSyncExternalStore(subscribe, getTheme, () => "dark");

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    window.localStorage.setItem("liveloop-theme", next);
    window.dispatchEvent(new Event("liveloop-theme-change"));
  };

  return (
    <button className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}>
      <span aria-hidden="true">{theme === "dark" ? "☀" : "☾"}</span>
      <strong>{theme === "dark" ? "Light" : "Dark"}</strong>
    </button>
  );
}
