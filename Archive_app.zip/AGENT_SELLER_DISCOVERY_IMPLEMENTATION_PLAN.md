# Agent and Marketplace Seller Discovery Implementation Plan

> Superseded operating-model note (July 2026): seller acquisition is now split
> into LiveLoop Admin Discovery, Independent Agency, and Enterprise Marketplace
> Partner flows. See
> [Seller Acquisition, Agency, and Enterprise Flow](SELLER_ACQUISITION_AGENCY_ENTERPRISE_FLOW.md).
> Agencies no longer discover or claim marketplace seller leads by default.

## 1. Objective

Add an Agency/Agent operating model to LiveLoop so approved agents can:

1. Discover prospective sellers from permitted marketplace and public-web data.
2. Qualify and invite those sellers to LiveLoop.
3. Connect verified seller marketplace accounts with explicit authorization.
4. Manage influencer discovery and campaigns for multiple seller clients.
5. Preserve client-level data isolation, seller control, and an auditable
   delegation history.

This initiative must keep two concepts separate:

```text
Seller lead
= public or permitted discovery record

Connected seller
= verified LiveLoop account with explicit authorization
```

A discovered seller must never appear to influencers as an onboarded or
verified LiveLoop seller until the seller claims and authorizes the profile.

## 2. Personas

### Seller Owner

- Owns the seller organization and its marketplace connections.
- Invites internal team members or an external agency.
- Controls agent permissions.
- Approves sensitive commercial actions.
- Can revoke agent access immediately.

### Seller Team Member

- Works inside one seller organization.
- Receives permissions from the Seller Owner.
- May manage products, campaigns, reporting, or billing.

### Agency Owner

- Owns an agency organization.
- Invites agency employees.
- Connects and manages multiple seller-client relationships.
- Controls which agent can access each client.

### Agency Agent

- Discovers seller leads.
- Qualifies and invites sellers.
- Works inside authorized client workspaces.
- Finds influencers and prepares campaigns on behalf of clients.
- Cannot exceed seller-granted permissions.

### Influencer

- Sees the seller as the contracting party.
- Sees which agency and agent are acting for the seller.
- Communicates and negotiates through the campaign workspace.

### LiveLoop Administrator

- Verifies agency organizations.
- Reviews seller-claim conflicts and suspicious discovery activity.
- Investigates permission misuse.
- Suspends integrations or agency access.
- Audits invitations, overrides, crawling, and delegated actions.

## 3. Product flows

## Flow A — Agency onboarding

Entry route: `/agency/onboarding`

1. Create an Agency organization.
2. Enter business name, website, location, and service categories.
3. Verify business email and identity.
4. Add agency team members.
5. Choose default roles.
6. Accept marketplace-data and outreach policies.
7. Submit for LiveLoop verification.
8. Admin approves, requests more information, or denies the agency.
9. Exit: Agency Portfolio.

Agency status:

```text
Draft → Submitted → Under Review → Verified
                           └──────→ Denied
Verified → Limited → Suspended
```

## Flow B — Seller discovery

Entry route: `/agency/discover-sellers`

1. Select source:
   - eBay.
   - Walmart/public web when permitted.
   - Company website.
   - Manual lead.
2. Enter product keywords, category, brand, price range, or location.
3. Retrieve permitted public listings and seller/store information.
4. Normalize seller and product records.
5. Deduplicate sellers across listings and sources.
6. Calculate a discovery confidence and LiveLoop opportunity score.
7. Show the evidence supporting each inferred attribute.
8. Agent saves, dismisses, or adds the seller to an outreach list.
9. Exit: Seller Lead Detail or Agent Lead Pipeline.

The discovery screen must label every seller as:

- **Discovered** — public lead, not a LiveLoop member.
- **Claimed** — seller has claimed the business identity.
- **Verified** — LiveLoop verification completed.
- **Connected** — marketplace authorization completed.

## Flow C — Seller lead review

Entry route: `/agency/leads/:leadId`

The agent reviews:

- Marketplace and store identifier.
- Public storefront URL.
- Product categories.
- Representative products.
- Price distribution.
- Listing volume observed.
- Shipping regions.
- Public company website.
- Potential influencer categories.
- Data sources, retrieval timestamps, and confidence.
- Duplicate or existing LiveLoop organization matches.

Agent actions:

- Save lead.
- Assign lead owner.
- Add internal note.
- Request further enrichment.
- Mark not relevant.
- Start seller invitation.
- Flag a duplicate or ownership conflict.

## Flow D — Seller invitation and profile claim

Entry route: `/agency/leads/:leadId/invite`

1. Agent chooses an eligible public business-contact channel.
2. LiveLoop creates a single-use seller claim link.
3. Invitation clearly identifies:
   - LiveLoop.
   - Agency organization.
   - Individual agent.
   - Public source used to discover the seller.
   - Why the seller may be a fit.
4. Seller opens the claim link.
5. Seller creates or signs into a LiveLoop account.
6. Seller proves control of the business identity.
7. LiveLoop checks for duplicate organizations.
8. Seller reviews and corrects imported public information.
9. Seller chooses whether to connect a marketplace account.
10. Seller accepts, limits, or declines agency access.

Invitation status:

```text
Draft → Sent → Viewed → Claim Started → Claimed → Connected
                 └────→ Declined
Sent → Expired
```

## Flow E — Marketplace connection

Entry route: `/seller/connections`

### eBay

1. Seller selects **Connect eBay**.
2. LiveLoop starts the approved eBay authorization flow.
3. Seller signs in to eBay and reviews requested access.
4. LiveLoop exchanges the authorization response for seller-scoped tokens.
5. Tokens are encrypted and stored outside application records.
6. Initial catalog sync runs.
7. Seller reviews imported products.
8. Seller chooses which products are eligible for influencer campaigns.

Public discovery can use the
[eBay Browse API](https://developer.ebay.com/api-docs/buy/api-browse.html).
Seller-authorized inventory and offers use the
[eBay Inventory API](https://developer.ebay.com/api-docs/sell/inventory/static/overview.html)
and other approved seller-scoped APIs.

### Walmart Marketplace

1. Seller selects **Connect Walmart Marketplace**.
2. LiveLoop verifies that the integration is eligible for Walmart’s approved
   Solution Provider/App Store model.
3. Seller authorizes LiveLoop using OAuth 2.0.
4. LiveLoop requests only the required scopes.
5. Initial item, inventory, and permitted analytics sync runs.
6. Seller chooses campaign-eligible products.

Official references:

- [Walmart seller integration](https://developer.walmart.com/us-marketplace/docs/get-started-as-a-seller)
- [Walmart OAuth 2.0 authorization](https://developer.walmart.com/us-marketplace/docs/oauth-20-authorization)
- [Walmart Marketplace API scopes](https://developer.walmart.com/us-marketplace/docs/api-scope-walmart-marketplace)

## Flow F — Agency/client delegation

Entry route: `/seller/agency-access`

1. Seller selects an agency or accepts the agency from the claim flow.
2. Seller grants explicit permissions.
3. Seller chooses products, regions, budget limits, and approval thresholds.
4. Agency Owner assigns specific agents.
5. Agent receives access to the client workspace.
6. Every agent action displays **Acting for [Seller]**.
7. Seller may change or revoke access.

Recommended permissions:

| Permission | Description |
| --- | --- |
| `seller.profile.read` | View seller profile |
| `catalog.read` | View authorized products |
| `catalog.campaign_select` | Select products for campaign drafts |
| `influencer.discover` | Search and shortlist influencers |
| `campaign.draft` | Create RFLS drafts |
| `campaign.invite` | Send invitations |
| `offer.propose` | Propose fees and commission |
| `offer.approve` | Accept commercial terms |
| `content.approve` | Approve public campaign content |
| `performance.read` | View campaign analytics |
| `payment.read` | View payment state |
| `payment.manage` | Create or release financial actions |

Default agency permission must exclude:

- Final commercial approval.
- Payment release.
- Refund approval.
- Seller profile ownership changes.
- Marketplace connection management.
- Permission delegation to another agency.

## Flow G — Agent portfolio

Entry route: `/agency`

Agent Portfolio contains:

- Seller leads.
- Invited sellers.
- Connected clients.
- Pending client approvals.
- Campaigns across clients.
- Upcoming live sessions.
- Revenue influenced.
- Agency fee/commission.
- SLA and client-health alerts.

Every cross-client view must support filtering and must prevent data leakage.

## Flow H — Agent discovers influencers for a seller

Entry route: `/agency/clients/:sellerId/discover-influencers`

1. Agent selects a connected seller client.
2. Agent selects eligible products and campaign goal.
3. LiveLoop loads only that seller’s authorized data.
4. AI ranks influencer matches.
5. Agent reviews match explanations.
6. Agent creates an RFLS draft.
7. If within delegated authority, the agent sends the invitation.
8. Otherwise the draft goes to the Seller Owner for approval.
9. Influencer sees:
   - Seller identity.
   - Agency identity.
   - Acting agent.
   - Approval state.

## Flow I — AI seller-opportunity scoring

AI may use:

- Product categories and price distribution.
- Public listing activity.
- Product imagery and descriptions.
- Geographic and shipping availability.
- Connected catalog and inventory after authorization.
- Historical LiveLoop category performance.
- Influencer audience demand signals.

AI outputs:

- Opportunity score.
- Confidence.
- Recommended creator categories.
- Representative products.
- Suggested seller invitation angle.
- Missing-data warning.
- Evidence and source links.

AI restrictions:

- Do not invent revenue, orders, margin, or inventory.
- Clearly distinguish observations from inferences.
- Do not infer protected personal attributes.
- Do not automatically contact sellers.
- Do not automatically claim or verify businesses.
- Do not train on seller-authorized private data without separate consent.

## 4. Technical architecture

```text
Marketplace adapters
├── eBay public discovery adapter
├── eBay seller-authorized adapter
├── Walmart seller-authorized adapter
└── Public-web enrichment adapter
        ↓
Ingestion queue
        ↓
Normalization and provenance
        ↓
Seller identity resolution / deduplication
        ↓
Lead database and search index
        ↓
AI qualification and matching
        ↓
Agency lead pipeline
        ↓
Seller claim and authorization
        ↓
Connected seller workspace
```

### Connector boundary

Every marketplace connector should implement:

```ts
interface MarketplaceConnector {
  discover?(query: DiscoveryQuery): Promise<DiscoveryPage>;
  authorize?(input: AuthorizationRequest): Promise<AuthorizationResult>;
  refreshAuthorization?(connectionId: string): Promise<void>;
  syncCatalog(connectionId: string, cursor?: string): Promise<SyncPage>;
  syncInventory?(connectionId: string, cursor?: string): Promise<SyncPage>;
  syncOrders?(connectionId: string, cursor?: string): Promise<SyncPage>;
  syncAnalytics?(connectionId: string, cursor?: string): Promise<SyncPage>;
  revoke(connectionId: string): Promise<void>;
}
```

Public discovery and seller-authorized operations must use different
credentials, rate limits, jobs, and storage policies.

### Web-enrichment boundary

Crawler behavior:

- Read only explicitly public pages allowed by applicable terms and robots
  controls.
- Use a documented LiveLoop user agent.
- Respect rate limits and retry guidance.
- Do not bypass authentication, CAPTCHA, paywalls, or anti-bot controls.
- Do not collect sensitive personal information.
- Prefer company contact information over individual contact information.
- Retain URL, timestamp, parser version, and field-level provenance.
- Honor deletion, correction, and suppression requests.
- Maintain domain-level allow, deny, and pause controls.

## 5. Data model

### Organization and access

```text
organizations
- id
- type: seller | agency
- name
- verification_status
- trust_status
- created_at

organization_memberships
- organization_id
- user_id
- role
- status

agency_client_relationships
- agency_organization_id
- seller_organization_id
- status
- starts_at
- ends_at
- created_by

permission_grants
- relationship_id
- permission
- scope_json
- approval_threshold_json
- granted_by
- granted_at
- revoked_at
```

### Discovery and identity

```text
marketplace_sources
- id
- provider
- marketplace
- source_type: public_api | authorized_api | public_web | manual

seller_leads
- id
- display_name
- lead_status
- assigned_agency_id
- assigned_agent_id
- opportunity_score
- score_confidence
- first_discovered_at
- last_enriched_at

seller_external_identities
- lead_id
- source_id
- external_seller_id
- storefront_url
- normalized_domain
- claim_status

seller_lead_evidence
- lead_id
- field_name
- observed_value_json
- source_url
- retrieved_at
- parser_version
- confidence

seller_identity_matches
- lead_id
- candidate_organization_id
- match_score
- match_reason_json
- resolution_status
```

### Invitations and claims

```text
seller_invitations
- id
- seller_lead_id
- agency_id
- agent_user_id
- channel
- recipient_business_contact
- status
- claim_token_hash
- expires_at
- sent_at
- viewed_at
- claimed_at

seller_claims
- invitation_id
- claimed_by_user_id
- claimed_organization_id
- verification_method
- status
- reviewed_by_admin_id
- reviewed_at
```

### Connections and synchronization

```text
marketplace_connections
- id
- seller_organization_id
- provider
- external_account_id
- connection_status
- granted_scopes_json
- token_secret_reference
- authorized_at
- revoked_at
- last_successful_sync_at
- last_error_code

sync_jobs
- id
- connection_id
- resource_type
- status
- cursor
- started_at
- finished_at
- records_seen
- records_changed
- error_summary

product_source_records
- connection_id
- external_product_id
- raw_record_reference
- source_updated_at

products
- id
- seller_organization_id
- normalized_title
- category
- status

product_source_mappings
- product_id
- connection_id
- external_product_id
```

## 6. API outline

### Agency

```text
POST   /api/agencies
GET    /api/agency/portfolio
GET    /api/agency/clients
POST   /api/agency/clients/:sellerId/assign-agent
GET    /api/agency/leads
POST   /api/agency/leads
GET    /api/agency/leads/:leadId
POST   /api/agency/leads/:leadId/enrich
POST   /api/agency/leads/:leadId/invite
POST   /api/agency/leads/:leadId/dismiss
```

### Discovery

```text
POST   /api/discovery/search
GET    /api/discovery/jobs/:jobId
GET    /api/discovery/sources
POST   /api/discovery/identity/resolve
POST   /api/discovery/duplicates/:id/resolve
```

### Seller claim and authorization

```text
GET    /api/seller-claims/:token
POST   /api/seller-claims/:token/accept
POST   /api/seller-claims/:token/decline
GET    /api/connections
POST   /api/connections/:provider/authorize
GET    /api/connections/:provider/callback
POST   /api/connections/:id/sync
DELETE /api/connections/:id
```

### Delegation

```text
GET    /api/seller/agency-access
POST   /api/seller/agency-access
PATCH  /api/seller/agency-access/:relationshipId
DELETE /api/seller/agency-access/:relationshipId
POST   /api/seller/agency-access/:relationshipId/grants
DELETE /api/seller/agency-access/:relationshipId/grants/:grantId
```

### Admin

```text
GET    /api/admin/agencies/review
POST   /api/admin/agencies/:id/decision
GET    /api/admin/seller-claims/conflicts
POST   /api/admin/seller-claims/:id/resolve
GET    /api/admin/connectors/health
POST   /api/admin/connectors/:provider/pause
GET    /api/admin/discovery/audit
POST   /api/admin/leads/:id/suppress
```

## 7. Security and privacy

### Authorization

- Enforce permissions in server-side code on every request.
- Never trust a client-provided organization or seller ID.
- Resolve access from authenticated membership and active grants.
- Require seller approval for actions outside an agent’s grant.
- Use idempotency keys for invitation, offer, and sync mutations.
- Record the acting user, agency, client seller, permission, and request ID.

### Token security

- Store OAuth secrets in a dedicated secret store.
- Store only opaque secret references in D1/application records.
- Encrypt refresh tokens at rest.
- Rotate encryption keys.
- Request minimum scopes.
- Support immediate revocation.
- Never expose marketplace tokens to browsers.

### Client data isolation

- Partition every seller-owned record by `seller_organization_id`.
- Include seller scope in cache keys and background jobs.
- Prevent agency-wide analytics from exposing client product or customer data.
- Add automated cross-tenant access tests.
- Mask sensitive order/customer information unless explicitly required.

### Outreach controls

- Use business contact information only when outreach is legally and
  contractually eligible.
- Apply suppression lists and frequency limits.
- Include agency and LiveLoop identity.
- Store outreach basis, source, timestamp, and opt-out state.
- Stop outreach immediately after decline or opt-out.

## 8. Background jobs

Recommended queues:

```text
discovery-search
public-record-normalization
seller-identity-resolution
web-enrichment
lead-scoring
seller-invitation-delivery
marketplace-token-refresh
catalog-sync
inventory-sync
order-sync
analytics-sync
connector-webhook-processing
data-retention-cleanup
```

Every job needs:

- Idempotency key.
- Retry policy.
- Dead-letter handling.
- Rate-limit awareness.
- Provider correlation ID.
- Tenant scope.
- Structured error code.
- Metrics and trace logging.

## 9. Admin and support operations

Admin pages:

- `/admin/agencies`
- `/admin/seller-claims`
- `/admin/discovery`
- `/admin/connectors`
- `/admin/outreach`
- `/admin/audit`

Admin capabilities:

- Verify or suspend an agency.
- Resolve duplicate seller claims.
- Inspect field-level data provenance.
- Suppress a seller lead or domain.
- Pause a provider connector.
- Revoke compromised connections.
- Review agent actions across clients.
- Investigate unauthorized access.
- Export a signed audit report.

Support capabilities:

- Link a ticket to seller lead, claim, agency relationship, or connection.
- Re-run a failed safe sync.
- Request seller reauthorization.
- Escalate ownership disputes.
- See sanitized connector errors.
- Never view raw OAuth credentials.

## 10. Observability

Connector metrics:

- Requests and errors by provider/endpoint.
- Rate-limit usage.
- OAuth success and failure.
- Token refresh failure.
- Sync duration and freshness.
- Records created, updated, skipped, or rejected.
- Webhook delay.
- Data-quality failure.

Discovery metrics:

- Leads discovered.
- Deduplication rate.
- Evidence completeness.
- Agent save/dismiss rate.
- Invitation rate.
- Claim rate.
- Connection rate.
- Time from discovery to verified connection.
- Suppression and complaint rate.

Agency metrics:

- Connected seller clients.
- Active agents.
- Campaigns per client.
- Approval turnaround.
- Seller revocation rate.
- Cross-client access violations.

## 11. Delivery plan

## Phase 0 — Policy and provider validation

Duration: 1–2 weeks

Deliverables:

- Confirm eBay API production eligibility and permitted fields.
- Confirm Walmart Solution Provider path and required scopes.
- Define approved public-web sources.
- Define outreach and suppression policy.
- Define seller-claim verification methods.
- Complete data-protection and threat-model review.

Exit criteria:

- Written provider/data policy.
- Approved minimum scopes.
- Approved retention schedule.
- Go/no-go for each discovery source.

## Phase 1 — Agency organization and delegation foundation

Duration: 2–3 weeks

Deliverables:

- Organization and membership schema.
- Agency onboarding.
- Agency verification admin queue.
- Agency/client relationship.
- Permission grants and seller approval thresholds.
- Client switcher and **Acting for** indicator.
- Authorization middleware and cross-tenant tests.

Exit criteria:

- One verified agency can securely manage two test sellers.
- Seller can revoke access.
- Agent cannot access an unassigned client.
- Sensitive actions require seller approval.

## Phase 2 — eBay discovery MVP

Duration: 2–3 weeks

Deliverables:

- eBay public discovery adapter.
- Search jobs and rate-limit handling.
- Seller lead and evidence storage.
- Identity normalization and duplicate detection.
- Agency seller-discovery UI.
- Lead detail and internal notes.
- Manual save/dismiss workflow.

Exit criteria:

- Agent can search a permitted category.
- Results show source evidence and retrieval dates.
- Repeated listings resolve to one seller lead where appropriate.
- No seller is labeled connected or verified.

## Phase 3 — Invitation, claim, and seller verification

Duration: 2–3 weeks

Deliverables:

- Seller invitation workflow.
- Single-use claim tokens.
- Seller claim landing page.
- Business verification.
- Duplicate organization conflict handling.
- Outreach suppression and opt-out.
- Admin claim-resolution queue.

Exit criteria:

- Seller can claim a discovered lead.
- Seller can correct imported public data.
- Duplicate claims cannot create duplicate seller organizations.
- Decline and opt-out stop future outreach.

## Phase 4 — Seller-authorized eBay connection

Duration: 3–4 weeks

Deliverables:

- eBay seller OAuth.
- Encrypted token storage.
- Catalog and inventory synchronization.
- Connection settings.
- Sync health and retry.
- Product review and campaign eligibility.
- Disconnect and deletion behavior.

Exit criteria:

- Seller explicitly authorizes required scopes.
- Catalog data is scoped to the seller.
- Revocation stops sync and agent visibility as required.
- Failed syncs are observable and recoverable.

## Phase 5 — Agent campaign workspace

Duration: 2–3 weeks

Deliverables:

- Agent Portfolio.
- Client switcher.
- Cross-client campaign queue without data leakage.
- Client-specific influencer discovery.
- RFLS drafts on behalf of sellers.
- Seller approval inbox.
- Influencer-facing agency disclosure.
- Agency performance reporting.

Exit criteria:

- Agent can prepare campaigns for multiple clients.
- Each seller sees only its own data.
- Influencer sees seller, agency, and acting agent.
- Approval thresholds are enforced.

## Phase 6 — Walmart seller-authorized connector

Duration: dependent on provider approval; estimate 3–5 weeks after access

Deliverables:

- Walmart approved-provider onboarding.
- OAuth 2.0 flow.
- Required item, inventory, and analytics scopes.
- Catalog synchronization.
- Provider health dashboard.
- Sandbox certification and production canary.

Exit criteria:

- Sandbox flows pass.
- Minimum scopes are used.
- Production canary is limited to approved test sellers.
- Revocation and token refresh are verified.

## Phase 7 — Controlled web enrichment and AI qualification

Duration: 3–4 weeks

Deliverables:

- Approved-domain web enrichment.
- Robots/terms controls and domain pause list.
- Field-level provenance.
- Seller lead opportunity score.
- Creator-category suggestions.
- Evidence-backed invitation brief.
- AI evaluation and hallucination checks.

Exit criteria:

- Every enriched field links to source and timestamp.
- Unsupported revenue/inventory claims are blocked.
- AI outputs distinguish facts from inferences.
- Agents review outreach before sending.

## 12. Suggested team

- Product manager.
- Product designer.
- Two full-stack engineers.
- Integration/backend engineer.
- Data/ML engineer.
- QA automation engineer.
- Security/privacy reviewer.
- Marketplace partnership or business-development owner.
- Trust and Safety/Customer Operations representative.

Provider approval work can run in parallel with the platform foundation.

## 13. Testing strategy

### Unit tests

- Connector response mapping.
- Permission evaluation.
- Evidence normalization.
- Identity matching.
- Score input validation.
- Claim-token validation.

### Integration tests

- OAuth success, denial, expiry, refresh, and revocation.
- Catalog pagination.
- Rate limits and retry.
- Partial sync failure.
- Duplicate seller claim.
- Seller permission change during an active campaign.

### Security tests

- Cross-client record access.
- Agent privilege escalation.
- Forged organization ID.
- Token replay.
- Claim-link reuse.
- Webhook signature validation.
- Sensitive log leakage.

### End-to-end tests

```text
Discover lead
→ Save lead
→ Invite seller
→ Claim seller
→ Verify seller
→ Authorize marketplace
→ Import products
→ Grant agency permission
→ Find influencer
→ Draft RFLS
→ Seller approval
→ Send invitation
```

## 14. Launch strategy

### Internal alpha

- One internal agency.
- Two test sellers.
- eBay sandbox/test data.
- Manual admin review for every lead and claim.

### Private beta

- Three to five verified agencies.
- Up to twenty seller clients.
- eBay production discovery within approved limits.
- Manual review for first outreach per agency.
- Weekly connector and complaint review.

### Controlled expansion

- Expand categories and regions gradually.
- Add Walmart only after provider approval and canary success.
- Add web enrichment by approved-domain cohort.
- Increase automation only after quality and complaint thresholds are met.

## 15. Success metrics

North-star metric:

**Verified connected sellers that launch a completed influencer campaign within
30 days of discovery.**

Supporting metrics:

- Discovery → saved lead.
- Saved lead → invitation.
- Invitation → claim.
- Claim → marketplace connection.
- Connection → first RFLS.
- RFLS → completed campaign.
- Time from discovery to first campaign.
- Seller invitation complaint/opt-out rate.
- Duplicate-resolution accuracy.
- AI lead-score precision.
- Agent productivity per active client.
- Seller access-revocation rate.
- Cross-tenant security incidents.

## 16. Definition of done for MVP

- Agency role and multi-client workspace exist.
- Seller controls all delegated access.
- eBay discovery results include provenance and clear lead labeling.
- Agent can save, qualify, and invite a seller.
- Seller can claim and verify the business.
- Seller can explicitly authorize an eBay connection.
- Imported products remain seller-scoped.
- Agent can draft an influencer RFLS for an authorized client.
- Approval thresholds are enforced server-side.
- Influencer sees agency representation disclosure.
- Admin can investigate agencies, claims, connectors, and access history.
- All privileged and delegated actions are auditable.
- No crawler bypasses authentication, robots controls, or provider restrictions.
