# LiveLoop

LiveLoop is an AI-powered live-commerce workspace for sellers and influencers.
This first version turns the original Google Stitch screen archive into one
coherent, responsive product demonstration.

## Included experience

- Seller and influencer workspace switcher
- Seller AI Sales Boost with explainable growth recommendations
- Influencer AI Copilot with pre-live briefs and performance coaching
- AI-ranked partner marketplace
- Role-aware RFLS commercial negotiation with offer history, countering,
  acceptance, decline, and private seller–creator messages
- Shared collaboration room with checklist, run of show, assets, deadlines,
  chat, locked terms, and AI readiness guidance
- Shared campaign milestone and readiness tracking
- Seller and influencer performance intelligence
- Responsive desktop, tablet, and mobile layouts
- Keyboard focus states and reduced-motion support
- Admin command center for governance, moderation, marketplace performance,
  and audited override workflows
- Seller/creator support portal and an admin ticketing desk with SLA,
  assignment, conversation, escalation, and customer-context views
- Animated role-based sign-in stories for sellers, creators, agencies, and
  enterprise partners
- Public AI Help Center with role-aware guidance and support-ticket handoff
- Public LiveLoop AI marketing page with role-specific capabilities,
  responsible-AI principles, and links into every interactive demo

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Validate

```bash
npm run build
```

## Product plan

The full product audit, domain model, AI guardrails, technical architecture,
API outline, roadmap, and success metrics are documented in
[`LIVELOOP_FULL_STACK_PLAN.md`](LIVELOOP_FULL_STACK_PLAN.md).

The complete seller and creator navigation reference, including direct local
links and end-to-end demonstration scripts, is documented in
[`LIVELOOP_FLOW_GUIDE.md`](LIVELOOP_FLOW_GUIDE.md).

The product-facing inventory of AI capabilities, value, guardrails,
implementation status, and success measures is documented in
[`LIVELOOP_AI_FEATURES.md`](LIVELOOP_AI_FEATURES.md).

## Current scope

This is the Phase 1 demonstrable product described in the plan. Transactional
authentication, persistent campaign records, connected commerce/social data,
payments, and production AI model calls are intentionally assigned to the
subsequent phases rather than simulated as if they were production-ready.
